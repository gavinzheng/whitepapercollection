# 1 预备知识 Preliminary

## 1.1不对称加密


现在来介绍能够满足上述要求的一种计算方式，也是网络早期共享秘钥Diffie Hellman算法所采用的计算方式：模运算+幂运算

**模运算(mod)**

这对于熟识计算机常识的人并不是一个陌生的数学知识，我们假定一个模数A，那么任何一个数字B对A取模的结果就是B / A的余数。

以模数A = 11为例子：

```
13 mod 11 = 2
(3 + 6) mod 11 = 9
(2^4) mod 11 = 5 
```


有了模运算的概念后，我们就可以开始着手构建可用的共享秘钥算法了，下面依旧基于A,B,C三个人的场景进行说明。

1. A和B各自选择一个私人数字
为了方便阅读，我们假设A和B选择的都是一个非常小的数字：比如A选择8，B选择9。注意在实际的应用中，这个数字要大得多。

2. A和B选择两个公开的数字
每个人的公开部分需要包含两个数字，其中一个是模数，另一个是基数。
假设A的公开数字分别是11(模数)和2(基数)。

3. A和B构建自己的公开-私人数字（PPN）
这是关键的一步，我们要解释一个等同于颜料混合的算数过程，这个过程构建出的结果将会是不可逆的。

现在，A和B都将使用A的两个公开数字，和自己的私有数字，利用下面的公式计算自己的公开-私有数字（我们称其为PPN）:
PPN = 基数^私人数字 mod 模数

于是：
A的PPN = 2^8 mod 11 = 3
B的PPN = 2^9 mod 11 = 6

可以看到这个计算PPN的过程是不可逆的，这主要归功于取模操作。

4. A和B向彼此的PPN中混合自己的私人数字

混合的计算方式和上面类似，只是公开基数被替换成了对方的PPN：

```
A计算共享秘钥 = B的PPN^8 mod 11 = 6^8 mod 11 = 4
B计算共享秘钥 = A的PPN^9 mod 11 = 3^9 mod 11 = 4
```


之所以能够得到同样的结果，是因为幂运算满足交换律，即：

```
(a^b)^c = (a^c)^b =  a^(bc)
```


A和B成功混合得到了同样的共享秘钥！现在只需要使用这个共享秘钥进行数字的加密/解密就可以实现私密通信了。而窃听者C无论拿到谁的PPN，都会因为无法混入另一个人的私钥而不能得到最终的共享秘钥。

## 1.2私钥/公钥 



### 加密功能


### 签名验证功能



## 1.3地址

## 1.4PassPhrase




## 1.5Key Derivation
sec
pkdbf

## 1.6HD





# 2 Keystore
## 2.1目录结构

# 3 Application Binary Interface 
## 3.1 目录结构


# 4 资源链接(Resource)
ABI

[ABI eth Guide](http://eth.guide/#resources-abi)

[Ethereum Contract ABI](https://github.com/ethereum/wiki/wiki/Ethereum-Contract-ABI#functions)


Solidity

[ABI Spec](https://solidity.readthedocs.io/en/develop/abi-spec.html#abi-json)


