




## 以太坊源码编译




```
wget https://storage.googleapis.com/golang/go1.9.4.linux-amd64.tar.gz 
sudo tar zxvf go1.9.4.linux-amd64.tar.gz
```
![image](https://note.youdao.com/yws/api/group/74287723/file/193421297?method=getImage&WLP=true&width=640&height=640&version=1&cstk=COoeNYiD)


```
mkdir dev
mv go1.9.4.linux-amd64.tar.gz  dev
mv go /usr/local
sudo mv go /usr/local
```



```
sudo vi .bashrc
```

```
export GOROOT=/usr/local/go
export GOPATH=/opt/goworkspace
export PATH=$PATH:$GOROOT/bin:$GOPATH/bin
```


```
source .bashrc
go version
```
![image](https://note.youdao.com/yws/api/group/74287723/file/193421296?method=getImage&WLP=true&width=640&height=640&version=1&cstk=COoeNYiD)



```
sudo apt install -y build-essential
```
![image](https://note.youdao.com/yws/api/group/74287723/file/193421294?method=getImage&WLP=true&width=640&height=640&version=1&cstk=COoeNYiD)




```
mkdir geth
cd geth
sudo apt install git
```
![image](https://note.youdao.com/yws/api/group/74287723/file/193421293?method=getImage&WLP=true&width=640&height=640&version=1&cstk=COoeNYiD)

```
git init 
git remote add origin https://github.com/ethereum/go-ethereum.git
git fetch --all
git pull origin master
```
![image](https://note.youdao.com/yws/api/group/74287723/file/193421295?method=getImage&WLP=true&width=640&height=640&version=1&cstk=COoeNYiD)


```
make geth
```

![image](https://note.youdao.com/yws/api/group/74287723/file/193421315?method=getImage&WLP=true&width=640&height=640&version=1&cstk=COoeNYiD)


## 以太坊的启动


## 以太坊的Console


```
$ geth attach ipc:/some/custom/path
$ geth attach http://191.168.1.1:8545
$ geth attach ws://191.168.1.1:8546
```




