package org.ethereum.core;

public enum ImportResult {
    SUCCESS,
    EXIST,
    NO_PARENT
}
