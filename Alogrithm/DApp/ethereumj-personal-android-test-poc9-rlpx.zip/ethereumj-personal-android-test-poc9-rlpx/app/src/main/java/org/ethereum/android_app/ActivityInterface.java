package org.ethereum.android_app;


public interface ActivityInterface {

    void registerFragment(FragmentInterface fragment);
}
