package org.ethereum.android_app;

public interface FragmentInterface {

    void onMessage(String message);
}
