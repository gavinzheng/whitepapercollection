package org.ethereum.android_app;


public class EthereumRemoteService extends org.ethereum.android.service.EthereumRemoteService {

    public EthereumRemoteService() {

        super();
    }
}
