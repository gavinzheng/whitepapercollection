// Package cmd contains Go implementations of the tools shipped with
// libschannel.
package cmd
