// var cb = function(res){console.log(res);}
// Pudding.defaults({gas: 2000000});
// web3.eth.defaultAccount = this.defaultAccount;
import $ from './lib/jquery.min'
import mouseTracker from './mouseTracker'

$(() => {
  mouseTracker.init()
})
