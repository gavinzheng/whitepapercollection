# 1.02 (2016.11.2)

* Added shaCommit function (2016.8.26)
* Update to solidity 0.4x (2016.11.2)

------

# 1.01 (2016.7.27)
* Fixed checkSecret modifier
* Remove min bounty
* Upgrade truffle to 2.0

* TEST-NET: 0x525E3562EfaBF4A28392d4CcE0DE9aE3F02D180A
* Production net: 0xb2A1ac7F7253B0EBF6410920ED1342c974bcA67A

------

# 1.0 (2016.7.27)
* Initial public release.

* TEST-NET: 0x0a25BCAC5b5A90e3F2dd7Fdf907A6c071b1296Ce
* Production net: 0x6C8060507273A0ff175361C6bf9F86e97f8Cf2C8
