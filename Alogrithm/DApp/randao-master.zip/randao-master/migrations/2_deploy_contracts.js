module.exports = function(deployer) {
  deployer.deploy(Randao);
  deployer.deploy(Counter);
};
