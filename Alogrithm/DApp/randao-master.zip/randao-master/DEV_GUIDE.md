#requirements

truffle ~> 2.0.0

solidity

#development

`truffle test`

check contracts in directory `contracts/`
