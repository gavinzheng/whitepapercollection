// @flow

import { AppRegistry } from 'react-native';
import App from './src/App';

AppRegistry.registerComponent('RNI18nExample', () => App);
