To cite re-frame in publications, please use:

[![DOI](https://zenodo.org/badge/DOI/10.5281/zenodo.801613.svg)](https://doi.org/10.5281/zenodo.801613)

Thompson, M. (2015, March). Re-Frame: A Reagent Framework For Writing SPAs, in Clojurescript.
Zenodo. http://doi.org/10.5281/zenodo.801613

@misc{thompson_2015,
  author       = {Thompson, Michael},
  title        = {Re-Frame: A Reagent Framework For Writing SPAs, in Clojurescript.},
  month        = mar,
  year         = 2015,
  doi          = {10.5281/zenodo.801613},
  url          = {https://doi.org/10.5281/zenodo.801613}
}
