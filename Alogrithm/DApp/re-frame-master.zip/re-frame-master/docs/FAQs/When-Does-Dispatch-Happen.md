### Question

How long after I call `dispatch` will the event be processed?

### Answer

The answer is "it depends", but [this comment in the code](https://github.com/Day8/re-frame/blob/master/src/re_frame/router.cljc#L8-L60)
might provide you the answers you seek.  


Up:  [FAQ Index](README.md)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;


<!-- START doctoc generated TOC please keep comment here to allow auto update -->
<!-- DON'T EDIT THIS SECTION, INSTEAD RE-RUN doctoc TO UPDATE -->
<!-- END doctoc generated TOC please keep comment here to allow auto update -->
