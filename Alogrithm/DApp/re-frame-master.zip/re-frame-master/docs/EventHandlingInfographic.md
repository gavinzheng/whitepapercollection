
## Event Handling Infographics

Three diagrams are provided below:
  - a beginner's romp
  - an intermediate schematic depiction
  - an advanced, full detail rendering

They should be reviewed in conjunction with the written tutorials. 

<img src="/images/event-handlers.png?raw=true">

*** 

Previous:   [The API](API.md)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
Up:  [Index](README.md)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
Next:  [Effectful Handlers](EffectfulHandlers.md)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;


<!-- START doctoc generated TOC please keep comment here to allow auto update -->
<!-- DON'T EDIT THIS SECTION, INSTEAD RE-RUN doctoc TO UPDATE -->
<!-- END doctoc generated TOC please keep comment here to allow auto update -->
