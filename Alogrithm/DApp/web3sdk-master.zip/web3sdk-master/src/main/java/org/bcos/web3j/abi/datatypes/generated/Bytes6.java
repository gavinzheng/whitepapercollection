package org.bcos.web3j.abi.datatypes.generated;

import org.bcos.web3j.abi.datatypes.Bytes;

/**
 * <p>Auto generated code.<br>
 * <strong>Do not modifiy!</strong><br>
 * Please use {@link org.bcos.web3j.codegen.AbiTypesGenerator} to update.</p>
 */
public class Bytes6 extends Bytes {
    public static final Bytes6 DEFAULT = new Bytes6(new byte[6]);

    public Bytes6(byte[] value) {
        super(6, value);
    }
}
