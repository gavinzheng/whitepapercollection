package org.bcos.web3j.abi.datatypes.generated;

import org.bcos.web3j.abi.datatypes.Bytes;

/**
 * <p>Auto generated code.<br>
 * <strong>Do not modifiy!</strong><br>
 * Please use {@link org.bcos.web3j.codegen.AbiTypesGenerator} to update.</p>
 */
public class Bytes29 extends Bytes {
    public static final Bytes29 DEFAULT = new Bytes29(new byte[29]);

    public Bytes29(byte[] value) {
        super(29, value);
    }
}
