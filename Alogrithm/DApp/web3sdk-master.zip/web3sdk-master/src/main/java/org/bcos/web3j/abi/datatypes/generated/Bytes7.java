package org.bcos.web3j.abi.datatypes.generated;

import org.bcos.web3j.abi.datatypes.Bytes;

/**
 * <p>Auto generated code.<br>
 * <strong>Do not modifiy!</strong><br>
 * Please use {@link org.bcos.web3j.codegen.AbiTypesGenerator} to update.</p>
 */
public class Bytes7 extends Bytes {
    public static final Bytes7 DEFAULT = new Bytes7(new byte[7]);

    public Bytes7(byte[] value) {
        super(7, value);
    }
}
