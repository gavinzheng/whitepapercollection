package org.bcos.web3j.abi.datatypes.generated;

import org.bcos.web3j.abi.datatypes.Bytes;

/**
 * <p>Auto generated code.<br>
 * <strong>Do not modifiy!</strong><br>
 * Please use {@link org.bcos.web3j.codegen.AbiTypesGenerator} to update.</p>
 */
public class Bytes16 extends Bytes {
    public static final Bytes16 DEFAULT = new Bytes16(new byte[16]);

    public Bytes16(byte[] value) {
        super(16, value);
    }
}
