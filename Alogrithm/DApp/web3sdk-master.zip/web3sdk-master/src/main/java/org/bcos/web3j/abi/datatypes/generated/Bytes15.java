package org.bcos.web3j.abi.datatypes.generated;

import org.bcos.web3j.abi.datatypes.Bytes;

/**
 * <p>Auto generated code.<br>
 * <strong>Do not modifiy!</strong><br>
 * Please use {@link org.bcos.web3j.codegen.AbiTypesGenerator} to update.</p>
 */
public class Bytes15 extends Bytes {
    public static final Bytes15 DEFAULT = new Bytes15(new byte[15]);

    public Bytes15(byte[] value) {
        super(15, value);
    }
}
