package org.bcos.web3j.abi.datatypes.generated;

import org.bcos.web3j.abi.datatypes.Bytes;

/**
 * <p>Auto generated code.<br>
 * <strong>Do not modifiy!</strong><br>
 * Please use {@link org.bcos.web3j.codegen.AbiTypesGenerator} to update.</p>
 */
public class Bytes3 extends Bytes {
    public static final Bytes3 DEFAULT = new Bytes3(new byte[3]);

    public Bytes3(byte[] value) {
        super(3, value);
    }
}
