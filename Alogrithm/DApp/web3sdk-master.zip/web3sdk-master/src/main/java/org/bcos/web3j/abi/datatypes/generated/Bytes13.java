package org.bcos.web3j.abi.datatypes.generated;

import org.bcos.web3j.abi.datatypes.Bytes;

/**
 * <p>Auto generated code.<br>
 * <strong>Do not modifiy!</strong><br>
 * Please use {@link org.bcos.web3j.codegen.AbiTypesGenerator} to update.</p>
 */
public class Bytes13 extends Bytes {
    public static final Bytes13 DEFAULT = new Bytes13(new byte[13]);

    public Bytes13(byte[] value) {
        super(13, value);
    }
}
