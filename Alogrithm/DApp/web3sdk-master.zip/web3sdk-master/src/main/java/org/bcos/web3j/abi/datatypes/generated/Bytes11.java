package org.bcos.web3j.abi.datatypes.generated;

import org.bcos.web3j.abi.datatypes.Bytes;

/**
 * <p>Auto generated code.<br>
 * <strong>Do not modifiy!</strong><br>
 * Please use {@link org.bcos.web3j.codegen.AbiTypesGenerator} to update.</p>
 */
public class Bytes11 extends Bytes {
    public static final Bytes11 DEFAULT = new Bytes11(new byte[11]);

    public Bytes11(byte[] value) {
        super(11, value);
    }
}
