package org.bcos.web3j.abi.datatypes.generated;

import org.bcos.web3j.abi.datatypes.Bytes;

/**
 * <p>Auto generated code.<br>
 * <strong>Do not modifiy!</strong><br>
 * Please use {@link org.bcos.web3j.codegen.AbiTypesGenerator} to update.</p>
 */
public class Bytes26 extends Bytes {
    public static final Bytes26 DEFAULT = new Bytes26(new byte[26]);

    public Bytes26(byte[] value) {
        super(26, value);
    }
}
