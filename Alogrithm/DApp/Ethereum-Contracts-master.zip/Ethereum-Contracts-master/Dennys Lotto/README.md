Denny's Lotto
=================

Totally not a scam!

I'll write more later. This is an implementation of a lottery with an html interface!