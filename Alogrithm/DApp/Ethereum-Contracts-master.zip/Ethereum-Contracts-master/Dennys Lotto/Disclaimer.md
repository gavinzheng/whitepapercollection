This software is provided for informational purposes only in order to test the concepts of certain aspects of an experimental system. It is not intented to be deployed or used in conjunction with money or any other transmission of value whatsoever. 

It is a toy example only being made available so as others can learn how to interact with the experimental system and not so as to facilitate gambling in any way. 

