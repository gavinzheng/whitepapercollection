Single Contract DOUG
=====================
Author: Dennis Mckinnon

Compatible with POC5 (April 25th 2014)

This is a simple Proof of concept I wrote for Preston. It is a simple template for a contract which can be superceded by a new contract when both parties agree. It does not contain any specifics though. Losely based on some of the funtionality of DOUG.

Potential uses are if you attach a hash of a real world document this could provide blockchain based signature system. Some aspects of the contract can also be included with this contract (such as payment etc. 

Enjoy




