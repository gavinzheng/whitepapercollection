# nim-ranges
Exploration of various implementations of memory range types
