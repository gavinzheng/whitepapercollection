This is a simulator for a blockchain lottery.

It shows that this lottery mechanism is broken. See the corresponding
post on hacking distributed.
