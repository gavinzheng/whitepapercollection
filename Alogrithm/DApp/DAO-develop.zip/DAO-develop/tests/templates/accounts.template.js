for (i = 0; i < $accounts_number; i++) {
    personal.newAccount("123");
}
console.log(JSON.stringify(eth.accounts));
