export default {
  if: 'wx:if',
  iterator1: 'wx:for-index',
  key: 'wx:key',
  alias: 'wx:for-item',
  'v-for': 'wx:for'
}
