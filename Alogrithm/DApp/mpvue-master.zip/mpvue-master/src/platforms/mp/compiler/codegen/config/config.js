export default {
  virtualTag: ['slot', 'template', 'block']
}
