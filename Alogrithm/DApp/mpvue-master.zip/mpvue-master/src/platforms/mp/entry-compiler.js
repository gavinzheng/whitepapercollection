/* @flow */

export { parseComponent } from 'sfc/parser'
export { compile, compileToFunctions, compileToWxml } from './compiler/index'
