import klass from './class'
import style from './style'
import props from './props'
import append from './append'

export default [
  klass,
  style,
  props,
  append
]
