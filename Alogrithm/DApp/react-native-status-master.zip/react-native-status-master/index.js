'use strict';

import { NativeModules } from 'react-native';
module.exports = NativeModules.Jail;
