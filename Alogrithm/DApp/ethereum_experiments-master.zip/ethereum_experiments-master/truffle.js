module.exports = {
  rpc: {
    host: "localhost",
    port: 8545
  }
};
