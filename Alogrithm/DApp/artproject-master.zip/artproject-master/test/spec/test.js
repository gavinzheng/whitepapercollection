import { assert } from 'chai';

describe('Give it some context', () => {
  describe('maybe a bit more context here', () => {
    it('should run here few assertions', () => {
      assert.isOk(true);
    });
  });
});
