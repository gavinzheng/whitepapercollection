/**
 * jCardSim remoting support classes.
 */
package com.licel.jcardsim.remote;
