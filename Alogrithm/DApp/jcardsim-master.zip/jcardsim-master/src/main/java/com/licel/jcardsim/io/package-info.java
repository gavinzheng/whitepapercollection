/**
 * jCardSim I/O support classes.
 */
package com.licel.jcardsim.io;
