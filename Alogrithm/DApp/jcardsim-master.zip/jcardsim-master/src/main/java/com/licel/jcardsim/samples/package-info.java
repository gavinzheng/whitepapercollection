/**
 * Example applets.
 */
package com.licel.jcardsim.samples;
