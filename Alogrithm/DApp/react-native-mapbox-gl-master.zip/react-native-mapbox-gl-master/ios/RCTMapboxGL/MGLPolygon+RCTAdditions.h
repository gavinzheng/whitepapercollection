//
// Copyright (c) 2016 Mapbox. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <Mapbox/Mapbox.h>

@interface MGLPolygon (RCTAdditions)
- (NSMutableArray *)coordinateArray;
@end