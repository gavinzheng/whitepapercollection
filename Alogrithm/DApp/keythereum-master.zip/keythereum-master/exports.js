var keythereum = global.keythereum || require('./');
global.keythereum = keythereum;
