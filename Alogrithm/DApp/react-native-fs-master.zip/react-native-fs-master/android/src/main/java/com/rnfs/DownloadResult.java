package com.rnfs;

public class DownloadResult {
  public int statusCode;
  public int bytesWritten;
  public Exception exception;
}
