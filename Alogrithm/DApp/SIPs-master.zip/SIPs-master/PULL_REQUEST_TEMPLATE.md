When opening a pull request to submit a new SIP, please use the suggested template: https://github.com/status-im/SIPs/blob/master/eip-X.md
