# tests

TODO: more vm tests and fixtures!

```bash
./tests/test.sh
```
