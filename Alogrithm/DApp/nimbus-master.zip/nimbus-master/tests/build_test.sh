#!/bin/bash

nim cpp tests/code_stream_test.nim
nim cpp tests/gas_meter_test.nim
nim cpp tests/memory_test.nim
nim cpp tests/stack_test.nim
