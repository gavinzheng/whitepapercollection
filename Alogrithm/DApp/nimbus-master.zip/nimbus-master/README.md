# Nimbus

[![Build Status](https://travis-ci.org/status-im/nimbus.svg?branch=master)](https://travis-ci.org/status-im/nimbus)

An Ethereum 2.0 Sharding Client for Resource-Restricted Devices

Rationale

https://docs.google.com/document/d/14u65XVNLOd83cq3t7wNC9UPweZ6kPWvmXwRTWWn0diQ/edit#
