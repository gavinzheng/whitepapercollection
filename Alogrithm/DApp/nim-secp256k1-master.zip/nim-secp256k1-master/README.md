# nim-secp256k1
A wrapper for libsecp256k1
