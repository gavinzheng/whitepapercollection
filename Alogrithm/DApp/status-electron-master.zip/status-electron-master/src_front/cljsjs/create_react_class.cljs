(ns cljsjs.create-react-class)
