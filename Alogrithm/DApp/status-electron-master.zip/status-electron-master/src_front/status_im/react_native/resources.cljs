(ns status-im.react-native.resources)

(def add-icon        nil)
(def att             nil)
(def chat-icon       nil)
(def icon-close-gray nil)
(def logo-icon       nil)
(def nav-back-icon   nil)
(def user-no-photo   nil)
(def online-icon     nil)
(def play            nil)
(def trash-icon      nil)
(def v               nil)

(def contacts
  {:auction-house      nil
   :mkr-market         nil
   :oaken-water-meter  nil
   :flight-delays-suck nil
   :jarrad             nil
   :firstblood         nil
   :gnosis             nil
   :melonport          nil
   :bchat              nil
   :dentacoin          nil
   :augur              nil
   :ethlance           nil
   :commiteth          nil
   :etherplay          nil})

(def assets
  {:ethereum nil})

(def ui
  {:empty-hashtags nil
   :empty-recent   nil})