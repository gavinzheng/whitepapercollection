const React = require('react-native');
const { AppRegistry, } = React;
const Example = require('./Example');

AppRegistry.registerComponent('Example', () => Example);
