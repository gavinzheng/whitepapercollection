extern int GetConstantInt32FromDLL();
extern int GetConstantInt64FromDLL();