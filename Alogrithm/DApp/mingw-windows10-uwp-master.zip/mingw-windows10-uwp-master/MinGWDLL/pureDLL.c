#include "pureDLL.h"

int GetConstantInt32FromDLL() { return 32; }

int GetConstantInt64FromDLL() { return 64; }