//
//  RNFaceDetectorModule.h
//  RCTCamera
//
//  Created by Joao Guilherme Daros Fidelis on 21/01/18.
//

#import <React/RCTBridgeModule.h>
#import <GoogleMobileVision/GoogleMobileVision.h>

@interface RNFaceDetectorModule : NSObject <RCTBridgeModule>
@end
