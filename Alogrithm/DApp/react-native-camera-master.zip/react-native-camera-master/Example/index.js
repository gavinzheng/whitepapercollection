import { AppRegistry } from 'react-native';
import Example from './Example';

AppRegistry.registerComponent('Example', () => Example);
