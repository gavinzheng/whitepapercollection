#import "React/RCTViewManager.h"

@interface RCTWKWebViewManager : RCTViewManager

@end
