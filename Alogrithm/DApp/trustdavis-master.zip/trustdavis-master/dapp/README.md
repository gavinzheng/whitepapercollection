# TrustDavis

## Development

Ensure you have [Meteor](https://www.meteor.com/install) installed.

Checkout the project from GitHub:

    $ git clone git@github.com:BlockchainSociety/TrustDavis.git

To run the app:

    $ cd TrustDavis/dapp
    $ meteor

Open your web browser and go to [http://localhost:3000](http://localhost:3000) to see the app running.
