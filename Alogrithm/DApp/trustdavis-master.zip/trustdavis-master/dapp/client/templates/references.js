"use strict";

Template.references.helpers({
});
