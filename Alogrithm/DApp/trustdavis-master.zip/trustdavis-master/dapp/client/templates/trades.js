"use strict";

Template.trades.helpers({
});
