"use strict";

Template.peers.helpers({
});
