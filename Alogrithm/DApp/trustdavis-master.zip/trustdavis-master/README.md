[![Stories in Ready](https://badge.waffle.io/ethercasts/trustdavis.png?label=ready&title=Ready)](https://waffle.io/ethercasts/trustdavis)
trustdavis
==========

TrustDavis
