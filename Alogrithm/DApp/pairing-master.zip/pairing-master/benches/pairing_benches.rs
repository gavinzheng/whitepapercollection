#![feature(test)]

extern crate test;
extern crate rand;
extern crate pairing;

mod bls12_381;
