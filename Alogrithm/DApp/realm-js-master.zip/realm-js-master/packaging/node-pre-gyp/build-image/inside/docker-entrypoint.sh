#!/bin/bash

scl enable devtoolset-3 -- "$@"
