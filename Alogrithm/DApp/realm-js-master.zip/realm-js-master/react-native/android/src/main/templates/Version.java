package io.realm.react;

public class Version {
    public static final String VERSION = "@version@";
}
