import os
import sys
import requests


BAMBOO_HR_TOKEN = os.environ.get('BAMBOO_HR_TOKEN')
if not BAMBOO_HR_TOKEN:
    print('Need bamboohr token')
    sys.exit()

headers = {
    'Accept': "application/json",
    'Authorization': "Basic %s" % BAMBOO_HR_TOKEN,
}


def get_employees():
    url = "https://api.bamboohr.com/api/gateway.php/statusim/v1/employees/directory"

    resp = requests.get(url, headers=headers)

    employees = resp.json()["employees"]
    employees_name_map = {emp["skypeUsername"].lower(): emp for emp in employees if emp["skypeUsername"]}

    return employees, employees_name_map


def get_employee(employee_id):

    url = "https://api.bamboohr.com/api/gateway.php/statusim/v1/employees/{}".format(
        employee_id
    )

    params = {
        'fields': ','.join(('supervisor', 'supervisorId', 'supervisorEId', 'hireDate'))
    }
    resp = requests.get(url, params=params, headers=headers)

    return resp.json()
