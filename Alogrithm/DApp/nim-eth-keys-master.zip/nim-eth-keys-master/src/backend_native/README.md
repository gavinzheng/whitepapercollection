# Pure Nim ECDSA with Secp256k1 curve backend

This experimental backend is available with the `-d:backend_native` compilation switch

Warning ⚠ - The native backend is not suitable for production use:
  - It is a proof of concept
  - It is not complete
  - It was not audited for cryptographic usage

DO NOT USE for production