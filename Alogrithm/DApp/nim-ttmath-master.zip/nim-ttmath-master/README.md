# nim-ttmath

A Nim wrapper for [ttmath library](https://www.ttmath.org/), a c++ template library for operating with
big integers and floats with fixed sizes.

