#import <UIKit/UIKit.h>
#import <React/RCTView.h>

@interface BVLinearGradient : RCTView

@end
