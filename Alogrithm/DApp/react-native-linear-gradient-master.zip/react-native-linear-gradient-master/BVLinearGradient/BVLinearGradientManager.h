#import <React/RCTViewManager.h>

@interface BVLinearGradientManager : RCTViewManager

@end
