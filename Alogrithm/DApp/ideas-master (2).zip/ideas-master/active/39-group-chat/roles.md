# Roles

| Role | Description |
| ---- | ----------- |
| Owner | Creator and owner of a chat. |
| Moderator | User with rights to moderate a chat. |
| User | Chat user without special rights. |
| Power User | Chat user without special rights but ability to develop smart contracts. |
| Contract Developer | Developer of contracts especially for chats. |
| Contract Provider | Provider of contracts especially for chats. |
