# Glossary

| Term | Meaning |
| ---- | ------- |
| Chat | Textual communication between two users. |
| Chat Room | Grouping of users chatting about a topic or having any other kind of relation. Opposite to bilateral chats. Chat rooms have one owner and possible multiple moderators. |
| Public Group Chat | Chat room without restrictions for users to join. Opposite to private chat rooms needing an invitation by the owner or a moderator. |
| SNT Burn Rate | ??? |
