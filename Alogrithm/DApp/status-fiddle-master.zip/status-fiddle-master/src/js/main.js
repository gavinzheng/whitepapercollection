window.deps = {
  'react' : require('react'),
  'react-dom' : require('react-dom'),
  'react-native-web' : require('react-native-web'),
};

window.React = window.deps['react'];
window.ReactDOM = window.deps['react-dom'];
window.ReactNativeWeb = window.deps['react-native-web'];
