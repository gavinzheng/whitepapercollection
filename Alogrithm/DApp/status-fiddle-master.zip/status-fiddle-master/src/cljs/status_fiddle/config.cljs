(ns status-fiddle.config)

(def debug?
  ^boolean goog.DEBUG)
