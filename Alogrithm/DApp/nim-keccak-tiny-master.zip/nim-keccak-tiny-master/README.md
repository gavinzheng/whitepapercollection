# nim-keccak-tiny

[![Build Status](https://travis-ci.org/status-im/nim-keccak-tiny.svg?branch=master)](https://travis-ci.org/status-im/nim-keccak-tiny)

A wrapper for the keccak-tiny C library
