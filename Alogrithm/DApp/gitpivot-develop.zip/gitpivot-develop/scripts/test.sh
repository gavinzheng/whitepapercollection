ARGN=3
ARG2="f94095ba1d48038d4a81,36ae0e8b1bc5ad261c936e8f7f730f6c827c221f"
ARG0="user-add"
ARG1="3esmit,31a58f2ddf2258697cce1b969e7c298b"

export ARGN
export ARG0
export ARG1
export ARG2




python github-oracle/github_oracle.py 

ARG0="update-new"
ARG1="ethereans/TheEtherian,master,f6a4474822a1193f81b45a571e521218a48ca8e3"

#python github-oracle/github_oracle.py

ARG0="update-old"
ARG1="ethereans/TheEtherian,master,b2ca0a249c6614d2be14d7d77694f52cd83acfd9,7d69d0e065d983cacb39f88ea1500c9224fe622f,e2c8c7a091ce3893635ce47169c972c6d5434ffa"

python github-oracle/github_oracle.py