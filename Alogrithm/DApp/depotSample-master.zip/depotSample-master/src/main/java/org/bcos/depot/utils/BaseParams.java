package org.bcos.depot.utils;

public class BaseParams {

	public static final String DATE_TIME_FORMAT = "yyyy-MM-dd HH:mm:ss";
}
