package org.bcos.depot.contract;

import java.math.BigInteger;

public class BCConstant {
    public static BigInteger gasPrice = new BigInteger("30000000");
    public static BigInteger gasLimit = new BigInteger("30000000");
    public static BigInteger initialWeiValue = new BigInteger("0");
}
