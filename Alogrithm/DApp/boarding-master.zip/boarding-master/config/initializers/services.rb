BOARDING_SERVICE = BoardingService.new
