require 'test_helper'

class InviteControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
