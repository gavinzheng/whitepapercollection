(ns reagent.dom.server)
;; Shimmed namespace to make reagent 0.6.0 work with react native packager

(defn render-to-string [_])

(defn render-to-static-markup [_])