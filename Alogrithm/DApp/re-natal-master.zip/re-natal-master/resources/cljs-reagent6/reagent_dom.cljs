(ns reagent.dom)
;; Shimmed namespace to make reagent 0.6.0 work with react native packager

(defn render
      ([_ _])
      ([_ _ _]))
(defn unmount-component-at-node [_])

(defn dom-node [_])

(defn force-update-all [])