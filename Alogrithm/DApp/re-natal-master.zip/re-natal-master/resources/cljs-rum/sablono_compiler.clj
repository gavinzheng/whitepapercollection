(ns sablono.compiler)

(defn compile-html
      [& content]
      (first content))