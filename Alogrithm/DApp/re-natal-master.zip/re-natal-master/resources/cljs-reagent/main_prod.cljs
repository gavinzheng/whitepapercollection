 (ns env.$PLATFORM$.main
  (:require [$PROJECT_NAME_HYPHENATED$.$PLATFORM$.core :as core]))

 (core/init)


