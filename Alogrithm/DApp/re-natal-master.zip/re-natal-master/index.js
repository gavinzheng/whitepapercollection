#!/usr/bin/env node

require('coffee-script/register');
require('./re-natal');
