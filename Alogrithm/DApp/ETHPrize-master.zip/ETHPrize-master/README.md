# ETHPrize
A repositry for the upcoming ETHPrize website.

## Links
1. [Figma](https://www.figma.com/file/FCakALK84WSxZB5QhvaV213e/ETHPrize?node-id=1%3A2) - The latest design version of the website. If you switch to "Code" view on the upper right corner, you can see the some of the specs. "Learn more" on the first screen is an anchor link to the About section. Links at the very bottom: Fedor Shkliarau (http://fedor.design/), Scott Webb (https://unsplash.com/@scottwebb)
2. [Readymag](https://readymag.com/shkliarau/995140/) - Prototype with animation how the effect of the effect from Tympanus and overall behavior.
3. [Tympanus](https://tympanus.net/Tutorials/CSSMaskTransition/index2.html) - effect for the hero image and second image in About section.
