# Design call notes 29/08/17

Attendance: Andrei, Denis, Anna, Vic

### TL;DR; After vacations sync up and direcitons

- Directions of the design activities:
	— Discover 
	— Onboarding flow
	— Username registration (epic: ENS Usernames)
- review and prioritize open issues with `design` label and assign to Andrei - Vic, Anna
- send command vs. new wallet UI - needs and open discussion
- need Wallet UI update to allow access to the Side bar 
- error states wallet UI
- add the date of refresh of the data? needs the open discussion with ClojureTeam
- hot issues that require design update:
    -  Add Testnet warning, so no real ether or SNT is sent to the app #1628 https://github.com/status-im/status-react/issues/1628
    - Monospace Font https://github.com/status-im/status-react/issues/1623
    - Update avatars for console - Denis
- Syncing up row and more generic error notification - revisit later
- What are all statuses of the Wallet?
- Workflow update: assign design issues to Andrei first
- invite ClojureTeam (optionally) to the coming design calls
