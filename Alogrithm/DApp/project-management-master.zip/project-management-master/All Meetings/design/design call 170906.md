# Design call notes 06/09/17

Attendance: Andrei, Denis, Anna, Vic, Andrey, Julien, Goran, Eric, Anastasia

### TL;DR; Discover update and high level discussion on the Dapp interface

- updates on the current discover only layout changes 
- existing Discover component is native
- Search - would it be general search or Discover specific?
- How can we reuse Search functionality/components?
- Dapp details page - what are the commands 
- Access favorite Daps from Contacts
- Chat updates started
- Open questions: how the user can navigate to another address when a dapp is opened
*- Follow up in the chat:*
- Dapp Chat and Web view - should we add new tab feature here? Do we need Chat tab for the Dapp?
- How we can manage the Dapp catalog - do we need a content management process (https://github.com/status-im/status-react/blob/develop/resources/default_contacts.json#L126
https://wiki.status.im/contributing/development/adding-dapps/
https://dapps.ethercasts.com/), e.g. can we find or grow the content providers similar to push notification providers?
