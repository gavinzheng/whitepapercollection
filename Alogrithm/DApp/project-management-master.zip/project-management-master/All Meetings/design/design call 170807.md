# Design call notes 8/7/17

Attendance: Andrei, Denis, Anna, Jarrad, Vic

### TL;DR; Discover screen reqiurements

Design call 7.08 notes:
- Decide about Cancel/Delete transaction (it’s more about the copy not the design?)
- How the graph would look like? (still open question)
- Send tx screen - Edit recipient - pull down menu - add Go to Profile command - but decided not adding it because the user can get lost
- Wallet Main screen - Exchange button disabled in the Beta release
- Discover screen: how does the blue bg color changes in Discover - change bg color only in wallet section
- User status - how often users update it?
- Dapps? Buy/Sell pills would be ?
- Hashtags enable public announces
- Do we need distance displayed?
- Repeat status?
- Context menu (3 dots) - add commands
- Filter Discover - popular cards (have more value)
- Search - pull down?
- Todo: feature Dapps, Ethereum news/howtos
- , ranking items for featuring in the feed
- app stores decide what you see, but Status.im will show the most trusted?
- items with URLs will be shown as icons
- how to discover new dapps?