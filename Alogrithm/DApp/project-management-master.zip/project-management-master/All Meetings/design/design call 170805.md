# Design call notes 8/5/17

Attendance: Andrei, Denis, Anna, Jarrad, Vic

### TL;DR; Polishing approved screens

Design call 5.08 notes
- before ENS is implemented can the user spoof the contact name (send tx flow)
- don’t truncate full address in the edit recipient contact screen
- changing the wallet changes to the Select wallet screen color
- send tx screen - changing the currency should change the Wallet’s  currency total value displayed
- do we want to acknowledge user’s actions e.g. cancel transaction notification?
- notify the user about ‘cancel transaction will delete it actually’
- use default spinner for long operations
- add the network name to the sensitive screens (send tx, qr, etc)
- new wallet should have eth asset added by default
- need another call for final approval (Monday)
- update the onboarding flow for the 3 words
- Tx Unsigned list: rename Cancel btn to Delete
- Explain UI animations e.g. pull to refresh
- Explain swipes when applicable
- Explain changing UI color when the wallet is changed
- Discover screen?