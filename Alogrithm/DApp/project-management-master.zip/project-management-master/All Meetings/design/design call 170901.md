# Design call notes 01/09/17

Attendance: Andrei, Denis, Anna, Vic, Andrey, Oskar, Julien, Goran

### TL;DR; Discover update and clarification of design activities

- Directions of the design activities:
	— Discover - improve existing Discover for the Devcon3 release
    - Discover - redesign the UI and flows
    - Profile - improvements per open issues
	— Onboarding flow - redesign for future release
	— Username registration (epic: ENS Usernames)
- need a follow up call with the wallet squad and approve the Wallet UI acceptance and breakdow - Vic
- need to add mockup for the wallet to change default currency
- add discover improvements issue - Vic
- add new issue for updated icons and the bottom bar
- confirmed using the system activity indicator (animation for lenghty operations)
- next call is on Wednesday
