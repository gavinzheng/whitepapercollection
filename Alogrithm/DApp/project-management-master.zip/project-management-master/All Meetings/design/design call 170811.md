# Design call notes 8/11/17

Attendance: Denis, Anna, Roman, Vic, Julien, Goran, Eric, Andrey

### TL;DR; Wallet UI Android screens - review with devs

11/08/17 design call summary
- went through Android screens with comments for the devs
- create the iOS and Android Components comparison board add comments describing the diffs - Denis
- double check the empty screens, e.g. Transactions History with no records - Denis
- ETA for the above is Monday 14/08/17
