# Design call notes 8/8/17

Attendance: Andrei, Denis, Anna

### TL;DR; Android design discussion

denis-sharypin [9:29 AM] 
Design call 8.08 notes:
Android design session
- decide on an accent color
- use white backgrounds to textfields
- how navigation bar will look like on a scroll?
- rework on sign in dialog
- use an accent color for icons