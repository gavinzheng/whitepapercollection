# Design call notes 02/10/17

Attendance: Jarrad, Andrei, Anna, Angus, Anastasya, Andrey, Eric, Vic

### TL;DR; Revisited the /send command integration with the new Wallet

*The /send flow*
- in the chat context - do now show tx final screen
- display the wallet as a popup modal
- consider security and phishing protection
- notice the send button (arrow to the right)
- 1:1 chat - need the contact suggestion inline? 
- hakaton feedback was about enabling the command line 
- in long term we want to support suggestions for full experience
- in the 1:1 chat autocomplete the recipient name /send `suggested name` amount
- design team to come up with UX update 
