# Design call notes 8/14/17

Attendance: Denis, Anna, Vic, Julien

### TL;DR; Wallet UI iOS and Android screens differences highlighted

11/08/17 design call summary

- all screens have been put on 1 board in pairs iOS and Android with comments on the differences
- will be uploaded to zepplin b y noon CET today
- setup the new call to discuss how `we can achieve the new design, without breaking this wallet-as-a-dapp idea`
