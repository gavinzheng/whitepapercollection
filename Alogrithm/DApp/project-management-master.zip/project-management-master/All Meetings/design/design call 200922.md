# Design call notes 22/09/17

Attendance: Andrei, Anna, Anastasia, Andrey, Denis, Eric, Vic

### TL;DR; Discussed details of the send transaction flow


*Send Transaction Flow*
- confirmed the updates Send flow
- need to confirm the amount number format
- validation of the user input in the select recipient screen -> display the popup error message
- Transaction details screen review -> add multiline and Gwei display
- remove ‘fancy line’ from the top of the Tx details screen (and everywhere it is)

*Chat updates*
- the blue button in chat bubble needs color update?
- do not truncate links in chat and display the preview if possible
- onboarding is not updated yet
