# Design call notes 8/3/17

Attendance: Andrei, Denis, Anna, Jarrad, Vic

### TL;DR; Approved the Send Transaction, QR codes screens with minor polishing required

Design call 3.08 notes
- Approved screens: Tx Send, QR codes, 
- pull to refresh feature add to Main Wallet and Tx History screen
- Manage Assets - add the ‘Add asset’ button?
- Wallet Settings - multisig wallets?
- 3 words password setting is system wide (not per wallet)
- QR code - add send request command
- Tx History  - add future transactions to the top of the list
- Tx History - password signing is too white
- Tx Request - in progress
- Android design is in progress
- Adding more wallets is out of Beta scope
- Empty wallet design - how the main screen would look like for the first time/empty wallet use
- Carl and Jarrad to have a call and confirm the copywrite for the confirmed screens
- Tx Overview - add the recipient name (or the dapp name) + the address
- Truncate addresses in the middle (keep the front and the ending visible to user)
- Unsigned tx icon should be gray (consistent icons and its colors)
- Tx Send - how QR is shown on the smaller screens (scroll?)
- Documenting UX - transitions between screens explanation is needed
- Android screen for the main wallet is needed
