# Design call notes 15/08/17

Attendance: Andrei, Jarrad, Denis, Anna, Vic

### TL;DR; Broad discussion on the long term design decisions

- broad discussion on the long term design decisions
- for the beta release stick to approved design
- for the long term start thinking about the design that is more a windows management system
- inside this system - the wallet app, browser and chats can be like apps
- still talking abstractly about new OS like UI, gatekeeper for inputs and outputs, e.g. gatekeeper on signing Tx, we can offer API so others can create react native wallet
- single window apps can make the composition of apps selected by the user
- discuss Discover updates on Thursday
