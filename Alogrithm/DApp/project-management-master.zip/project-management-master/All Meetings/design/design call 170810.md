# Design call notes 8/10/17

Attendance: Denis, Anna, Jarrad, Vic

### TL;DR; Wallet UI Android screens - work in progress

Design call 10.08
- Wallet UI Android screens planned to complete on Monday
- We can approve some (as much) Android screens on Monday
- Simple onboarding update with just + 1 more question to capture 3 words (no design rework atm) - Vic to update the issue

