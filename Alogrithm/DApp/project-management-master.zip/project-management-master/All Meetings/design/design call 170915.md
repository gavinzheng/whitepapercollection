# Design call notes 15/09/17

Attendance: Andrei, Denis, Anna, Goran, Eric, Vic

### TL;DR; Omnibar elaborated further, Browser window UX discussio, Discover face lifting finalized


*Omnibar and Browser*
- From the Tabs user can open web browser with address bar, standard navigation and the Open chat button in the bottom to interact with the Dapp
- Concerns about having the bottom tab with browser controls and the Open Chat 
- the bottob panel is multi-purpose and introduce a nice Chat popup, and basic navigation controls
- If dapp or web site doesnt’ support chat the button is invisible
- The web browser can be opened from any chat with the URL 
- Contacts tab -> Favorites
- send command opens new Wallet 
- send location UX updated to the full experience

*Discover update*
- update on Discover face lifting is done - create user stories and start implementation

*Profile update*
- side bar is a full screen now
