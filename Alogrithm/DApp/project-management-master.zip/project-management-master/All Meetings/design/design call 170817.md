# Design call notes 17/08/17

Attendance: Jarrad, Denis, Anna, Vic

### TL;DR; Discussion about add assets flow, discover feature and future design priorities

*Add assets*

- mark hidden/shown assets in assets list
- edit assets picture same as a profile photo or it could be link and image picker.
- pre-made beautiful assets picture (but low priority on this)

*Discover*

- browser tab is a low priority
- think about adding an omnibar and trigger browser when you tap it
- screen with chosen hashtag looks like a search field
- leave statuses in the profile
- how discover screen will look like you have posted status

*Monospace font*

- need this font to improve distinguishing between digits.
- need Andrey opinion on this

*Next priorities*

- user name registration
- revision of onboarding
- landscape version (at least 1 screen to start with)
