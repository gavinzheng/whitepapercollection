# Meeting #_
### Meeting Date/Time: _
### Meeting Duration: _
### [Video of the meeting](https://youtu.be/)

# Agenda

#### Agenda Topic Title

**[[0:00](https://youtu.be/_?t=0)] a. First Item.**

1. [[0:00:00](https://youtu.be/_?t=0)] [First Subitem](https://) [Person Accountable]


**[[0:00](https://youtu.be/_?t=0)] b. Second Item.**
- [[0:00](https://youtu.be/_?t=0)] First Subitem
    - First Sub-Subitem


#### Other Agenda Topic

**[[0:00](https://youtu.be/_?t=0)] a. First Item

1. [[0:00:00](https://youtu.be/_?t=0)] [First Subitem](https://) [Person Accountable]

# Notes

## a. First Note

### 1. Note Title  [Person Accountable]

Details

## Attendance

Jarrad Hope (), _