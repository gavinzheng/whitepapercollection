MOVΞ - A Decentralised Ride-Sharing DApp
=================================

_Last Updated: 30 July 2015_  
_Author: Jarrad Hope_

To create a global, decentralised participatory ride-sharing organisation on Ethereum, utilizing the [General Market Framework](https://github.com/syng-io/general-market-framework).


### Development Status

In Development (pre-alpha)

- `<incomplete>`
- Discuss on [gitter.im/syng-io/general](http://gitter.im/syng-io/general)
- Get [General Market Framework](https://github.com/syng-io/general-market-framework) to a usable status.
- <del>Designs Converted to HTML</del>
- <del>OpenStreets Designs</del>

### Communication

Live Chat: [gitter.im/syng-io/general](http://gitter.im/syng-io/general)

### Technical Skills Required to Contribute

Any of the following; Python, Serpent 2, HTML5/Javascript

### Features

- Interactive GUI for both Rider & Driver (Planned)
- Ride-Sharing Match Maker (Planned)
- `<incomplete>`