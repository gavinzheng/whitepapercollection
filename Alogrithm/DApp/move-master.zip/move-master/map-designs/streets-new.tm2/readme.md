mapbox-studio-streets.tm2
-------------------------

Classic Mapbox Streets with Vector Terrain.
