pacman
======

Entries to the Pacman vs. Ghosts AI competition