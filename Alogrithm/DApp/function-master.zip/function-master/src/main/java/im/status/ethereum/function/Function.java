package im.status.ethereum.function;

public interface Function<T, R> {
    R apply(T var1);
}
