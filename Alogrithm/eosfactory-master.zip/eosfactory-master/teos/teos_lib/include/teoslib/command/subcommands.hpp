#pragma once

#include <string>
#include <map>

extern const char* benchmarkSubcommands;

