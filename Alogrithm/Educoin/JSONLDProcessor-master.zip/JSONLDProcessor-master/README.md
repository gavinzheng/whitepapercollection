# JSONLDProcessor
An iOS framework for processing JSON-LD files.
