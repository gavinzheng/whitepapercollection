//
//  JSONLDProcessor.h
//  JSONLDProcessor
//
//  Created by Chris Downie on 9/29/16.
//  Copyright © 2016 Blockchain Certificates. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for JSONLDProcessor.
FOUNDATION_EXPORT double JSONLDProcessorVersionNumber;

//! Project version string for JSONLDProcessor.
FOUNDATION_EXPORT const unsigned char JSONLDProcessorVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <JSONLDProcessor/PublicHeader.h>


