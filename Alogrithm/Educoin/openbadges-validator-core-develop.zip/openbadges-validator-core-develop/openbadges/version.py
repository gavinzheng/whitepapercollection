VERSION = (1, 0, 0, 'rc1')
