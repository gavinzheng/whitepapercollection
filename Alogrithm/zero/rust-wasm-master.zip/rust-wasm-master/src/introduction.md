This small book describes how to use [Rust] and [WebAssembly] together.

[This book is open source! Find a typo? Did we overlook something? Send us a pull
request!][repo]

[Rust]: https://www.rust-lang.org
[WebAssembly]: http://webassembly.org/
[repo]: https://github.com/rust-lang-nursery/rust-wasm
