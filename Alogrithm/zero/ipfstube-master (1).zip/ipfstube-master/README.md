# ipfstube

Watch videos stored on IPFS

Live at [ipfstube.erindachtler.me](http://ipfstube.erindachtler.me)

[Demo video](https://ipfstube.erindachtler.me/v/QmU1GSqu4w29Pt7EEM57Lhte8Lce6e7kuhRHo6rSNb2UaC)
