#### hyperledger fabric v1.0 new architecture
