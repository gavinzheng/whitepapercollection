# Summary

* [Introduction](README.md)
* [code-data-structure](code-data-structure/README.md)
    * [BucketTree](code-data-structure/BucketTree.md)
* [workflow](workflow/README.md)
    * [peer](workflow/peer.md)
    * [viper](workflow/viper.md)
    * [protos](workflow/protos.md)
* [v1.0 architecture](architecture/README.md)
    * [Next-Consensus-Architecture-Proposal-zh](architecture/Next-Consensus-Architecture-Proposal-zh.md)
    * [Next-Consensus-Architecture-Proposal-en](architecture/Next-Consensus-Architecture-Proposal-en.md)
