package io.nuls.ledger.entity.params;

/**
 * @author: Niels Wang
 * @date: 2018/3/20
 */
public enum OperationType {
    COIN_BASE, TRANSFER, LOCK, UNLOCK
}
