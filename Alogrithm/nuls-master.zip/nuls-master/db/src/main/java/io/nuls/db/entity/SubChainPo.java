/**
 * MIT License
 *
 * Copyright (c) 2017-2018 nuls.io
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package io.nuls.db.entity;

/**
 * @author Niels
 * @date 2017/11/20
 */
public class SubChainPo {

    private String id;

    private String creatorAddress;

    private String txHash;

    private String gBlockHash;

    private String gMerkleHash;

    private String title;

    private byte[] gBlock;

    private byte[] gBlockHeader;

    private byte[] sign;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    public String getCreatorAddress() {
        return creatorAddress;
    }

    public void setCreatorAddress(String creatorAddress) {
        this.creatorAddress = creatorAddress == null ? null : creatorAddress.trim();
    }

    public String getTxHash() {
        return txHash;
    }

    public void setTxHash(String txHash) {
        this.txHash = txHash == null ? null : txHash.trim();
    }

    public String getgBlockHash() {
        return gBlockHash;
    }

    public void setgBlockHash(String gBlockHash) {
        this.gBlockHash = gBlockHash == null ? null : gBlockHash.trim();
    }

    public String getgMerkleHash() {
        return gMerkleHash;
    }

    public void setgMerkleHash(String gMerkleHash) {
        this.gMerkleHash = gMerkleHash == null ? null : gMerkleHash.trim();
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title == null ? null : title.trim();
    }

    public byte[] getgBlock() {
        return gBlock;
    }

    public void setgBlock(byte[] gBlock) {
        this.gBlock = gBlock;
    }

    public byte[] getgBlockHeader() {
        return gBlockHeader;
    }

    public void setgBlockHeader(byte[] gBlockHeader) {
        this.gBlockHeader = gBlockHeader;
    }

    public byte[] getSign() {
        return sign;
    }

    public void setSign(byte[] sign) {
        this.sign = sign;
    }
}
