//
//  main.m
//  ServerlessDemo
//
//  Created by Robbie Hanson on 1/8/10.
//  Copyright Deusty Designs, LLC. 2010. All rights reserved.
//

#import <UIKit/UIKit.h>

int main(int argc, char *argv[]) {
    
    @autoreleasepool {
        int retVal = UIApplicationMain(argc, argv, nil, nil);
        return retVal;
    }
}
