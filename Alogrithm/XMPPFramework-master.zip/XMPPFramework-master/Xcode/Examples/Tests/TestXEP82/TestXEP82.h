//
//  TestXEP82.h
//  TestXEP82
//
//  Created by Robbie Hanson on 4/12/11.
//  Copyright 2011 Deusty, LLC. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface TestXEP82 : NSObject

+ (void)runTests;

@end
