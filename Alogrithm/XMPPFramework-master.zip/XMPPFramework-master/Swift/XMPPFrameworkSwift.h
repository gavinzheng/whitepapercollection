@import Foundation;
@import XMPPFramework;

FOUNDATION_EXPORT double XMPPFrameworkSwiftVersionNumber;
FOUNDATION_EXPORT const unsigned char XMPPFrameworkSwiftVersionString[];
