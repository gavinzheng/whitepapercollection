# Examples

`templates/` contain markdown templates.

`engagements/` contain output of `claw`.



