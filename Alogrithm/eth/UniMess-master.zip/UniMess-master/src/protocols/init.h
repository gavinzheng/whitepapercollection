#pragma once

#include "../protocol_config.h"
#include "none.h"
#include "not.h"
#include "xor.h"
#include "xorchain.h"
#include "swap.h"
#include "deriv.h"

namespace unimess_protocols {

void init();

} // namespace unimess_protocols
