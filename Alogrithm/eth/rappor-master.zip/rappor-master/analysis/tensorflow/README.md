RAPPOR in TensorFlow
====================

This directory contains an experimental implementation of the EM algorithm in
[TensorFlow](http://tensorflow.org).

Currently the C++ implementation in `analysis/cpp` is faster and can be used
in production.


