find_cliques
============

This tool does part of the analysis for unknown dictionaries.  To run it:

    $ ./run.sh demo

This compiles and runs it on files in the testdata/ directory.

See comments in find_cliques.cc for information on how it works.


