# payment-channel
Ethereum Payment Channel in 50 lines of code
