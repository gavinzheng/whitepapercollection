#ifndef _CRT_HASH_MAP_H_
#define _CRT_HASH_MAP_H_

#include "types.h"

#define SLOT_SIZE 8
#define DEFAULT_N_SLOTS 128

struct HashMap {
    struct Slot *slots;
    crt_size_t n_slots;
    crt_size_t len;
};

struct Value {
    char *key;
    void *data;
};

struct Slot {
    struct Value values[SLOT_SIZE];
    crt_size_t next_value_pos;
    struct Slot *next;
};

struct HashMap * crt_hashmap_new();
void crt_hashmap_destroy(struct HashMap *hm);
void * crt_hashmap_insert(struct HashMap *hm, const char *key, void *data);
void * crt_hashmap_lookup(struct HashMap *hm, const char *key);
void * crt_hashmap_remove(struct HashMap *hm, const char *key);
crt_size_t crt_hashmap_len(struct HashMap *hm);
const char ** crt_hashmap_keys(struct HashMap *hm);
void crt_hashmap_destroy_borrowed_string_list(const char **list);

#endif
