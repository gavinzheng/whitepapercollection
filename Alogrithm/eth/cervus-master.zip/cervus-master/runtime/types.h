#ifndef _CRT_TYPES_H_
#define _CRT_TYPES_H_

typedef unsigned long crt_size_t;

#endif
