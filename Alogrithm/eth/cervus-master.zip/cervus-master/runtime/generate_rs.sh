#!/bin/bash

INFILE=$1

cat << EOF
pub static CODE: &'static str = r#"
EOF

base64 < $INFILE

cat << EOF
"#;
EOF
