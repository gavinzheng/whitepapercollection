#include "hash_map.h"
#include "mm.h"
#include <stdlib.h>
#include <string.h>
#include <assert.h>

static void init_value(struct Value *val, const char *key) {
    val -> key = NULL;
    val -> data = NULL;

    if(key) {
        crt_size_t key_len = strlen(key);
        val -> key = malloc(key_len + 1);
        memcpy(val -> key, key, key_len + 1);
    }
}

static void destroy_value(struct Value *val) {
    if(val -> key) {
        crt_free(val -> key);
        val -> key = NULL;
    }

    // caller should be responsible for releasing val -> data.
    val -> data = NULL;
}

static void init_slot(struct Slot *slot) {
    for(crt_size_t i = 0; i < SLOT_SIZE; i++) {
        init_value(&slot -> values[i], NULL);
    }
    slot -> next_value_pos = 0;
    slot -> next = NULL;
}

static void destroy_slot(struct Slot *slot) {
    if(slot -> next) {
        destroy_slot(slot -> next);
        crt_free(slot -> next);
        slot -> next = NULL;
    }

    for(crt_size_t i = 0; i < slot -> next_value_pos; i++) {
        destroy_value(&slot -> values[i]);
    }

    slot -> next_value_pos = 0;
}

static crt_size_t get_slot_len(struct Slot *slot) {
    crt_size_t len = 0;
    for(crt_size_t i = 0; i < slot -> next_value_pos; i++) {
        if(slot -> values[i].key && slot -> values[i].data) len++;
    }
    if(slot -> next) len += get_slot_len(slot -> next);
    return len;
}

static void collect_slot_keys(struct Slot *slot, const char **out, crt_size_t *pos) {
    for(crt_size_t i = 0; i < slot -> next_value_pos; i++) {
        if(slot -> values[i].key && slot -> values[i].data) {
            out[*pos] = slot -> values[i].key;
            ++*pos;
        }
    }
    if(slot -> next) collect_slot_keys(slot -> next, out, pos);
}

static void ** slot_lookup(struct Slot *slot, const char *key, int should_insert) {
    while(slot) {
        for(crt_size_t i = 0; i < slot -> next_value_pos; i++) {
            if(slot -> values[i].key && strcmp(slot -> values[i].key, key) == 0) {
                return &slot -> values[i].data;
            }

            // a free value space in the current slot is found...
            if(should_insert && slot -> values[i].data == NULL) {
                struct Value *val = &slot -> values[i];
                destroy_value(val);
                init_value(val, key);
                return &val -> data;
            }
        }

        if(should_insert) {
            // we are at the last slot...
            if(slot -> next_value_pos < SLOT_SIZE) {
                crt_size_t pos = slot -> next_value_pos;
                slot -> next_value_pos++;

                struct Value *val = &slot -> values[pos];
                init_value(val, key);

                return &val -> data;
            }
            if(!slot -> next) {
                slot -> next = (struct Slot *) crt_malloc(sizeof(struct Slot));
                init_slot(slot -> next);
            }
        }

        slot = slot -> next;
    }

    return NULL;
}

static crt_size_t hash_string(const char *s) {
    crt_size_t hash = 5381;
    int c;

    while((c = *(s++))) {
        hash = ((hash << 5) + hash) + c;
    }

    return hash;
}

struct HashMap * crt_hashmap_new() {
    struct HashMap *hm = (struct HashMap *) crt_malloc(sizeof(struct HashMap));
    hm -> n_slots = DEFAULT_N_SLOTS;
    hm -> len = 0;

    struct Slot *slots = (struct Slot *) crt_malloc(sizeof(struct Slot) * hm -> n_slots);

    for(crt_size_t i = 0; i < hm -> n_slots; i++) {
        init_slot(&slots[i]);
    }

    hm -> slots = slots;
    return hm;
}

void * _w_crt_hashmap_new() {
    return (void *) crt_hashmap_new();
}

void crt_hashmap_destroy(struct HashMap *hm) {
    for(crt_size_t i = 0; i < hm -> n_slots; i++) {
        destroy_slot(&hm -> slots[i]);
    }
    crt_free(hm -> slots);
    crt_free(hm);
}

void _w_crt_hashmap_destroy(void *hm) {
    crt_hashmap_destroy((struct HashMap *) hm);
}

void * crt_hashmap_insert(struct HashMap *hm, const char *key, void *data) {
    crt_size_t slot_id = (hash_string(key) % (hm -> n_slots));
    void **insert_place = slot_lookup(&hm -> slots[slot_id], key, 1);
    assert(insert_place != NULL);

    void *prev_value = *insert_place;
    *insert_place = data;

    hm -> len++;

    return prev_value;
}

void * _w_crt_hashmap_insert(void *hm, const char *key, void *data) {
    return crt_hashmap_insert((struct HashMap *) hm, key, data);
}

void * crt_hashmap_lookup(struct HashMap *hm, const char *key) {
    crt_size_t slot_id = (hash_string(key) % (hm -> n_slots));
    void **target = slot_lookup(&hm -> slots[slot_id], key, 0);
    if(!target) return NULL;
    return *target;
}

void * _w_crt_hashmap_lookup(void *hm, const char *key) {
    return crt_hashmap_lookup((struct HashMap *) hm, key);
}

void * crt_hashmap_remove(struct HashMap *hm, const char *key) {
    crt_size_t slot_id = (hash_string(key) % (hm -> n_slots));
    void **target = slot_lookup(&hm -> slots[slot_id], key, 0);
    if(!target) return NULL;

    void *prev_value = *target;
    *target = NULL;

    hm -> len--;

    return prev_value;
}

void * _w_crt_hashmap_remove(void *hm, const char *key) {
    return crt_hashmap_remove((struct HashMap *) hm, key);
}

crt_size_t crt_hashmap_len(struct HashMap *hm) {
    return hm -> len;
}

crt_size_t _w_crt_hashmap_len(void *hm) {
    return crt_hashmap_len((struct HashMap *) hm);
}

const char ** crt_hashmap_keys(struct HashMap *hm) {
    crt_size_t len = crt_hashmap_len(hm);
    const char **keys = (const char **) crt_malloc(sizeof(const char *) * len);
    crt_size_t pos = 0;

    for(crt_size_t i = 0; i < hm -> n_slots; i++) {
        collect_slot_keys(&hm -> slots[i], keys, &pos);
    }

    assert(pos == len);
    return keys;
}

void * _w_crt_hashmap_keys(void *hm) {
    return (void *) crt_hashmap_keys((struct HashMap *) hm);
}

void crt_hashmap_destroy_borrowed_string_list(const char **list) {
    crt_free((void *) list);
}

void _w_crt_hashmap_destroy_borrowed_string_list(void *list) {
    crt_hashmap_destroy_borrowed_string_list((const char **) list);
}
