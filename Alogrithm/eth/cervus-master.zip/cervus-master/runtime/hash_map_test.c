#include "hash_map.h"
#include <assert.h>
#include <stdlib.h>
#include <stdio.h>

int main() {
    int val1 = 42;
    int val2 = 100;

    struct HashMap *hm = crt_hashmap_new();

    void *ret = crt_hashmap_insert(hm, "some_value_1", (void *) &val1);
    assert(ret == NULL);

    ret = crt_hashmap_insert(hm, "some_value_2", (void *) &val2);
    assert(ret == NULL);

    assert(crt_hashmap_len(hm) == 2);

    for(int i = 0; i < 1000000; i++) {
        assert(crt_hashmap_remove(hm, "some_value_2") == (void *) &val2);
        assert(crt_hashmap_len(hm) == 1);
        assert(crt_hashmap_insert(hm, "some_value_2", (void *) &val2) == NULL);
        assert(crt_hashmap_len(hm) == 2);
    }

    crt_size_t current_len = crt_hashmap_len(hm);
    assert(current_len == 2);
    const char **keys = crt_hashmap_keys(hm);
    printf("[*] Key 0: %s\n", keys[0]);
    printf("[*] Key 1: %s\n", keys[1]);
    crt_hashmap_destroy_borrowed_string_list(keys);

    for(int i = 0; i < 1000000; i++) {
        char key_buf[128];
        sprintf(key_buf, "test_key_%d", i);
        assert(crt_hashmap_insert(hm, key_buf, (void *) &val1) == NULL);
        assert(crt_hashmap_lookup(hm, key_buf) == (void *) &val1);
        assert(crt_hashmap_remove(hm, key_buf) == (void *) &val1);
        assert(crt_hashmap_lookup(hm, key_buf) == NULL);
        assert(crt_hashmap_remove(hm, key_buf) == NULL);
    }

    assert(* (int *) crt_hashmap_lookup(hm, "some_value_1") == val1);
    assert(* (int *) crt_hashmap_lookup(hm, "some_value_2") == val2);

    assert(* (int *) crt_hashmap_remove(hm, "some_value_1") == val1);

    assert(crt_hashmap_lookup(hm, "some_value_1") == NULL);
    assert(* (int *) crt_hashmap_lookup(hm, "some_value_2") == val2);

    crt_hashmap_destroy(hm);

    printf("[+] OK: hash_map_test\n");

    return 0;
}
