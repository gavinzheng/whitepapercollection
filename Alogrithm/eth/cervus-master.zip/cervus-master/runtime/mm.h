#ifndef _CRT_MM_H_
#define _CRT_MM_H_

#include <stdlib.h>

static inline void * crt_malloc(crt_size_t size) {
    return malloc(size);
}

static inline void crt_free(void *p) {
    free(p);
}

#endif
