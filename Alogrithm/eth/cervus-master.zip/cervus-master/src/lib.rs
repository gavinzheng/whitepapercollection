extern crate llvm_sys;
#[macro_use]
extern crate lazy_static;
extern crate base64;

pub mod engine;
pub mod value_type;
pub mod patcher;
pub mod logging;
pub mod value;
pub mod builder_scope;
pub mod crt;
mod crt_generated;
//pub mod rt;

#[cfg(test)]
mod engine_test;

#[cfg(test)]
mod patcher_test;

#[cfg(test)]
mod logging_test;

#[cfg(test)]
mod tests;

#[cfg(test)]
mod crt_test;
