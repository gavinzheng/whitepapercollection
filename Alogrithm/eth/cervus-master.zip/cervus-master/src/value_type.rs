use std::os::raw::c_void;
use std::any::TypeId;
use llvm_sys::core::*;
use llvm_sys::prelude::*;

lazy_static! {
    static ref BUILTIN_TYPES: BuiltinTypes = BuiltinTypes::new();
}

#[allow(non_snake_case)]
pub struct BuiltinTypes {
    Void: TypeId,
    Int8: TypeId,
    Int16: TypeId,
    Int32: TypeId,
    Int64: TypeId,
    Uint8: TypeId,
    Uint16: TypeId,
    Uint32: TypeId,
    Uint64: TypeId,
    Float64: TypeId,
    Int8ConstPtr: TypeId,
    Int8MutPtr: TypeId,
    Uint8ConstPtr: TypeId,
    Uint8MutPtr: TypeId,
    CvoidConstPtr: TypeId,
    CvoidMutPtr: TypeId
}

impl BuiltinTypes {
    pub fn new() -> BuiltinTypes {
        BuiltinTypes {
            Void: TypeId::of::<()>(),
            Int8: TypeId::of::<i8>(),
            Int16: TypeId::of::<i16>(),
            Int32: TypeId::of::<i32>(),
            Int64: TypeId::of::<i64>(),
            Uint8: TypeId::of::<u8>(),
            Uint16: TypeId::of::<u16>(),
            Uint32: TypeId::of::<u32>(),
            Uint64: TypeId::of::<u64>(),
            Float64: TypeId::of::<f64>(),
            Int8ConstPtr: TypeId::of::<*const i8>(),
            Int8MutPtr: TypeId::of::<*mut i8>(),
            Uint8ConstPtr: TypeId::of::<*const u8>(),
            Uint8MutPtr: TypeId::of::<*mut u8>(),
            CvoidConstPtr: TypeId::of::<*const c_void>(),
            CvoidMutPtr: TypeId::of::<*mut c_void>()
        }
    }

    pub fn get_default() -> &'static BuiltinTypes {
        &BUILTIN_TYPES
    }
}

#[derive(Clone, Eq, PartialEq)]
pub enum ValueType {
    Void,
    Int1,
    Int8,
    Int16,
    Int32,
    Int64,
    Float64,
    Pointer(Box<ValueType>),
    Function(Box<ValueType>, Vec<ValueType>)
}

impl ValueType {
    pub fn get_ref(&self) -> LLVMTypeRef {
        unsafe {
            match self {
                &ValueType::Void => LLVMVoidType(),
                &ValueType::Int1 => LLVMInt1Type(),
                &ValueType::Int8 => LLVMInt8Type(),
                &ValueType::Int16 => LLVMInt16Type(),
                &ValueType::Int32 => LLVMInt32Type(),
                &ValueType::Int64 => LLVMInt64Type(),
                &ValueType::Float64 => LLVMDoubleType(),
                &ValueType::Pointer(ref inner) => LLVMPointerType(inner.get_ref(), 0),
                &ValueType::Function(ref ret_type, ref param_types) => {
                    let mut param_types_ref: Vec<LLVMTypeRef> = param_types.iter().map(|v| v.get_ref()).collect();
                    LLVMFunctionType(ret_type.get_ref(), param_types_ref.as_mut_ptr(), param_types_ref.len() as u32, 0)
                }
            }
        }
    }

    pub fn of<T: ?Sized + 'static>() -> Option<ValueType> {
        let tid = TypeId::of::<T>();
        let types = BuiltinTypes::get_default();

        if tid == types.Void {
            Some(ValueType::Void)
        } else if tid == types.Int8 || tid == types.Uint8 {
            Some(ValueType::Int8)
        } else if tid == types.Int16 || tid == types.Uint16 {
            Some(ValueType::Int16)
        } else if tid == types.Int32 || tid == types.Uint32 {
            Some(ValueType::Int32)
        } else if tid == types.Int64 || tid == types.Uint64 {
            Some(ValueType::Int64)
        } else if tid == types.Float64 {
            Some(ValueType::Float64)
        } else if
            tid == types.Int8ConstPtr || tid == types.Int8MutPtr
            || tid == types.Uint8ConstPtr || tid == types.Uint8MutPtr
        {
            Some(ValueType::Pointer(Box::new(ValueType::Int8)))
        } else if
            tid == types.CvoidConstPtr || tid == types.CvoidMutPtr
        {
            Some(ValueType::Pointer(Box::new(ValueType::Void)))
        } else {
            None
        }
    }

    pub fn is_pointer(&self) -> bool {
        if let ValueType::Pointer(_) = *self {
            true
        } else {
            false
        }
    }

    pub fn is_integer(&self) -> bool {
        use self::ValueType::*;

        match *self {
            Int1 | Int8 | Int16 | Int32 | Int64 => true,
            _ => false
        }
    }
}


pub trait BuildTypeList {
    fn build() -> Vec<ValueType>;
}

impl BuildTypeList for () {
    fn build() -> Vec<ValueType> {
        vec![]
    }
}

impl<T1> BuildTypeList for (T1,)
    where
        T1: ?Sized + 'static
{
    fn build() -> Vec<ValueType> {
        vec![
            ValueType::of::<T1>().unwrap()
        ]
    }
}

impl<T1, T2> BuildTypeList for (T1, T2)
    where
        T1: 'static,
        T2: 'static
{
    fn build() -> Vec<ValueType> {
        vec![
            ValueType::of::<T1>().unwrap(),
            ValueType::of::<T2>().unwrap()
        ]
    }
}

impl<T1, T2, T3> BuildTypeList for (T1, T2, T3)
    where
        T1: 'static,
        T2: 'static,
        T3: 'static
{
    fn build() -> Vec<ValueType> {
        vec![
            ValueType::of::<T1>().unwrap(),
            ValueType::of::<T2>().unwrap(),
            ValueType::of::<T3>().unwrap()
        ]
    }
}

impl<T1, T2, T3, T4> BuildTypeList for (T1, T2, T3, T4)
    where
        T1: 'static,
        T2: 'static,
        T3: 'static,
        T4: 'static
{
    fn build() -> Vec<ValueType> {
        vec![
            ValueType::of::<T1>().unwrap(),
            ValueType::of::<T2>().unwrap(),
            ValueType::of::<T3>().unwrap(),
            ValueType::of::<T4>().unwrap(),
        ]
    }
}

impl<T1, T2, T3, T4, T5> BuildTypeList for (T1, T2, T3, T4, T5)
    where
        T1: 'static,
        T2: 'static,
        T3: 'static,
        T4: 'static,
        T5: 'static
{
    fn build() -> Vec<ValueType> {
        vec![
            ValueType::of::<T1>().unwrap(),
            ValueType::of::<T2>().unwrap(),
            ValueType::of::<T3>().unwrap(),
            ValueType::of::<T4>().unwrap(),
            ValueType::of::<T5>().unwrap()
        ]
    }
}

impl<T1, T2, T3, T4, T5, T6> BuildTypeList for (T1, T2, T3, T4, T5, T6)
    where
        T1: 'static,
        T2: 'static,
        T3: 'static,
        T4: 'static,
        T5: 'static,
        T6: 'static
{
    fn build() -> Vec<ValueType> {
        vec![
            ValueType::of::<T1>().unwrap(),
            ValueType::of::<T2>().unwrap(),
            ValueType::of::<T3>().unwrap(),
            ValueType::of::<T4>().unwrap(),
            ValueType::of::<T5>().unwrap(),
            ValueType::of::<T6>().unwrap(),
        ]
    }
}
