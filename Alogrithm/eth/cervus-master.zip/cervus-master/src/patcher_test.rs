use std::os::raw::c_void;
use std::sync::{Arc, Mutex};
use engine;
use patcher;
use value_type::ValueType;

#[derive(Clone)]
struct PatchTestResult {
    value: Arc<Mutex<i32>>
}

#[test]
fn build_and_run_patched() {
    let test_result = PatchTestResult {
        value: Arc::new(Mutex::new(0))
    };

    let (ee, fn_handle) = {
        let m = engine::Module::new("patched");
        let m = patcher::add_local_fn(
            m,
            "write_result",
            _write_result as *const c_void,
            ValueType::Void,
            vec![
                patcher::Argument::Local(Box::new(test_result.clone())),
                patcher::Argument::FromCall(ValueType::Int32)
            ]
        );

        let f = engine::Function::new_null_handle("write_result",
            ValueType::Void,
            vec![
                ValueType::Int32
            ]
        );

        (engine::ExecutionEngine::new(m), f)
    };
    ee.prepare();

    let f = ee.get_callable_1::<(), i32>(&fn_handle);
    f(20);
    if *test_result.value.lock().unwrap() != 20 {
        panic!("Incorrect test result");
    }
}

#[test]
fn build_and_run_patched_with_retval() {
    let test_result = PatchTestResult {
        value: Arc::new(Mutex::new(0))
    };

    let (ee, fn_handle) = {
        let m = engine::Module::new("patched");
        let m = patcher::add_local_fn(
            m,
            "write_result",
            _write_result_and_return as *const c_void,
            ValueType::Int32,
            vec![
                patcher::Argument::Local(Box::new(test_result.clone())),
                patcher::Argument::FromCall(ValueType::Int32)
            ]
        );

        let f = engine::Function::new_null_handle("write_result",
            ValueType::Int32,
            vec![
                ValueType::Int32
            ]
        );

        (engine::ExecutionEngine::new(m), f)
    };
    ee.prepare();

    let f = ee.get_callable_1::<i32, i32>(&fn_handle);
    let ret = f(20);
    if *test_result.value.lock().unwrap() != 20 || ret != 20 {
        panic!("Incorrect test result");
    }
}

extern fn _write_result(target: *const engine::ModuleResource, v: i32) {
    let target = unsafe { &*target };
    let target = target.downcast_ref::<PatchTestResult>().unwrap();
    *target.value.lock().unwrap() = v;
}

extern fn _write_result_and_return(target: *const engine::ModuleResource, v: i32) -> i32 {
    let target = unsafe { &*target };
    let target = target.downcast_ref::<PatchTestResult>().unwrap();
    *target.value.lock().unwrap() = v;
    v
}