use std::os::raw::{c_void, c_char};
use std::ffi::CStr;
use engine;
use value_type::ValueType;
use patcher;

pub enum LogLevel {
    Emergency,
    Alert,
    Critical,
    Error,
    Warning,
    Notice,
    Info,
    Debug
}

struct LoggerFn {
    target: Box<Fn(LogLevel, &str)>
}

pub fn set_logger(m: engine::Module, logger: Box<Fn(LogLevel, &str)>) -> engine::Module {
    let logger = Box::new(LoggerFn {
        target: logger
    });

    let m = patcher::add_local_fn(
        m,
        "cervus_log",
        _call_logger as *const c_void,
        ValueType::Void,
        vec![
            patcher::Argument::Local(logger),
            patcher::Argument::FromCall(ValueType::Int32),
            patcher::Argument::FromCall(ValueType::Pointer(Box::new(ValueType::Int8)))
        ]
    );
    m
}

unsafe extern fn _call_logger(logger: *const engine::ModuleResource, log_level: i32, msg: *const c_char) {
    let logger = (&*logger).downcast_ref::<LoggerFn>().unwrap();
    (logger.target)(
        match log_level {
            0 => LogLevel::Emergency,
            1 => LogLevel::Alert,
            2 => LogLevel::Critical,
            3 => LogLevel::Error,
            4 => LogLevel::Warning,
            5 => LogLevel::Notice,
            6 => LogLevel::Info,
            7 => LogLevel::Debug,
            _ => LogLevel::Debug
        },
        CStr::from_ptr(msg).to_str().unwrap()
    );
}
