use std::os::raw::c_char;
use std::sync::{Arc, Mutex};
use std::ffi::CString;
use engine;
use logging;
use value_type::ValueType;

#[test]
fn build_and_run_basic_logger() {
    let storage = Arc::new(Mutex::new(String::new()));
    let storage_cloned = storage.clone();

    let (ee, fn_handle) = {
        let m = engine::Module::new("basic_logger");
        let m = logging::set_logger(m, Box::new(move |_, msg| {
            *storage_cloned.lock().unwrap() = msg.to_string()
        }));

        let f = engine::Function::new_null_handle("cervus_log",
            ValueType::Void,
            vec![
                ValueType::Int32,
                ValueType::Pointer(Box::new(ValueType::Int8))
            ]
        );

        (engine::ExecutionEngine::new(m), f)
    };
    ee.prepare();

    let f = ee.get_callable_2::<(), i32, *const c_char>(&fn_handle);
    f(0, CString::new("OK").unwrap().as_ptr());
    if *storage.lock().unwrap() != "OK" {
        panic!("Incorrect test result");
    }
}
