use std::any::Any;
use std::os::raw::c_void;
use engine;
use value_type::ValueType;

pub enum Argument {
    Local(Box<Any>),
    LocalRaw(*const c_void),
    FromCall(ValueType)
}

pub fn add_local_fn(m: engine::Module, name: &str, f: *const c_void, ret_type: ValueType, args: Vec<Argument>) -> engine::Module {
    let t = engine::Module::new("_linking");
    t.copy_data_layout_from(&m);
    
    {
        let target_fn = engine::Function::new(
            &t,
            name,
            ret_type.clone(),
            args.iter().map(|v| {
                match v {
                    &Argument::Local(_) | &Argument::LocalRaw(_)=> None,
                    &Argument::FromCall(ref t) => Some(t.clone())
                }
            }).filter(|v| v.is_some()).map(|v| v.unwrap()).collect()
        );
        let bb = engine::BasicBlock::new(
            &target_fn,
            "bb"
        );
        let builder = engine::Builder::new(&bb);

        let mut target_param_types = Vec::new();
        let mut target_params = Vec::new();
        let mut target_param_pos: usize = 0;

        for v in args {
            target_param_types.push(
                match v {
                    Argument::Local(_) | Argument::LocalRaw(_) => ValueType::Pointer(Box::new(ValueType::Void)),
                    Argument::FromCall(ref t) => t.clone()
                }
            );
            target_params.push(
                match v {
                    Argument::Local(v) => {
                        let mut resources = m.resources.lock().unwrap();
                        resources.push(Box::new(v.into()));
                        let addr = &*resources[resources.len() - 1] as *const engine::ModuleResource;
                        //println!("ModuleResource: {}", addr as u64);
                        engine::Value::from(addr as *const c_void as u64).const_int_to_ptr(
                            ValueType::Pointer(Box::new(ValueType::Void))
                        )
                    },
                    Argument::LocalRaw(v) => {
                        engine::Value::from(v as u64).const_int_to_ptr(
                            ValueType::Pointer(Box::new(ValueType::Void))
                        )
                    },
                    Argument::FromCall(_) => {
                        let v = target_fn.get_param(target_param_pos).unwrap();
                        target_param_pos += 1;
                        v
                    }
                }
            );
        }

        let ret = builder.append(
            engine::Action::Call(
                engine::Value::from(f as u64).const_int_to_ptr(
                    ValueType::Pointer(Box::new(
                        ValueType::Function(
                            Box::new(ret_type.clone()),
                            target_param_types
                        )
                    ))
                ),
                target_params
            )
        );

        if ret_type == ValueType::Void {
            builder.append(engine::Action::ReturnVoid);
        }
        else {
            builder.append(engine::Action::Return(ret));
        }
    }
    m.link(t)
}
