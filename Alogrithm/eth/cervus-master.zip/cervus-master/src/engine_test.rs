use std;
use std::sync::Arc;
use engine;
use value_type::ValueType;
use builder_scope;

/*
use std::io::Write;
macro_rules! println_stderr(
    ($($arg:tt)*) => { {
        writeln!(&mut ::std::io::stderr(), $($arg)*).unwrap();
    } }
);
*/

fn build_basic_sum_function() -> (engine::ExecutionEngine, engine::Function<'static>) {
    let fn_handle;
    let ee;

    {
        let m = engine::Module::new("basic_sum");
        {
            let f = engine::Function::new(
                &m,
                "test_function",
                ValueType::Int32,
                vec![
                    ValueType::Int32,
                    ValueType::Int32
                ]
            );
            {

                let bb = engine::BasicBlock::new(&f, "default_bb");
                let builder = engine::Builder::new(&bb);
                let ret;

                {
                    let _bs = builder.scope_handle();
                    ret = ((f.get_param(0).unwrap() + f.get_param(1).unwrap()) * (2 as i32).into());
                }
                builder.return_value(ret);
            }
            fn_handle = f.into_null_handle();
        }
        ee = engine::ExecutionEngine::new(m);
    }

    ee.prepare();
    (ee, fn_handle)
}

#[test]
fn build_and_run_basic_sum_function() {
    let (ee, fn_handle) = build_basic_sum_function();

    let code = ee.get_callable_2::<i32, i32, i32>(&fn_handle);
    if code(2, 3) != 10 {
        panic!("Incorrect result from jitted code");
    }
}

#[test]
fn build_and_run_float_sum() {
    let (ee, fn_handle) = {
        let m = engine::Module::new("float_sum");
        let f = {
            let f = engine::Function::new(
                &m,
                "test_function",
                ValueType::Float64,
                vec![
                    ValueType::Float64,
                    ValueType::Float64
                ]
            );
            let initial_bb = engine::BasicBlock::new(&f, "bb");
            let builder = engine::Builder::new(&initial_bb);
            builder.append(
                engine::Action::Return(
                    builder.append(
                        engine::Action::FloatAdd(
                            f.get_param(0).unwrap(),
                            f.get_param(1).unwrap()
                        )
                    )
                )
            );
            f.to_null_handle()
        };
        (engine::ExecutionEngine::new(m), f)
    };

    ee.prepare();

    let f = ee.get_callable_2::<f64, f64, f64>(&fn_handle);
    let ret = f(1.0, 2.0);
    if (ret - 3.0).abs() > 0.0001 {
        panic!("Incorrect result from floating point operation: {}", ret);
    }
}

#[test]
fn build_and_run_branch() {
    let (ee, fn_handle) = {
        let m = engine::Module::new("branch");
        let f = {
            let f = engine::Function::new(
                &m,
                "test_function",
                ValueType::Int8,
                vec![
                    ValueType::Int32
                ]
            );
            let initial_bb = engine::BasicBlock::new(&f, "initial");
            let if_true = engine::BasicBlock::new(&f, "t");
            let if_false = engine::BasicBlock::new(&f, "f");

            let mut builder = engine::Builder::new(&initial_bb);
            builder.append(
                engine::Action::ConditionalBranch(
                    builder.append(engine::Action::IntEqual(
                        builder.append(engine::Action::And(
                            f.get_param(0).unwrap(),
                            (1 as i32).into()
                        )),
                        (1 as i32).into()
                    )),
                    &if_true,
                    &if_false
                )
            );

            builder = engine::Builder::new(&if_true);
            builder.append(
                engine::Action::Return((1 as i8).into())
            );

            builder = engine::Builder::new(&if_false);
            builder.append(
                engine::Action::Return((0 as i8).into())
            );
            f.to_null_handle()
        };
        (engine::ExecutionEngine::new(m), f)
    };
    ee.prepare();
    let f = ee.get_callable_1::<i8, i32>(&fn_handle);
    if f(11) != 1 {
        panic!("f(11) != 1");
    }
    if f(10) != 0 {
        panic!("f(10) != 0");
    }
}

#[test]
fn test_mem_ops() {
    let mut buf1: Vec<u8> = vec![0; 16];
    let mut buf2: Vec<u16> = vec![0; 16];

    buf1[0] = 42;
    buf1[1] = 53;

    buf2[0] = 2333;
    buf2[1] = 7711;

    let m = engine::Module::new("test_mem_ops");
    let f_decl;

    {
        let f = engine::Function::new(
            &m,
            "test_function",
            ValueType::Void,
            vec![]
        );

        let bb = engine::BasicBlock::new(&f, "");
        let mut builder = engine::Builder::new(&bb);

        let buf1_handle: engine::Value = (&mut buf1[0] as *mut u8 as u64).into();
        let buf1_handle = buf1_handle.const_int_to_ptr(
            ValueType::Pointer(Box::new(ValueType::Int8))
        );

        let buf2_handle: engine::Value = (&mut buf2[0] as *mut u16 as u64).into();
        let buf2_handle = buf2_handle.const_int_to_ptr(
            ValueType::Pointer(Box::new(ValueType::Int16))
        );

        builder.append(engine::Action::Store(
            builder.append(engine::Action::Load(
                buf1_handle.clone()
            )),
            builder.append(engine::Action::PtrOffset(
                buf1_handle.clone(),
                (2 as u64).into()
            ))
        ));
        builder.append(engine::Action::Store(
            builder.append(engine::Action::Load(
                buf2_handle.clone()
            )),
            builder.append(
                engine::Action::PtrOffset(
                    buf2_handle.clone(),
                    (2 as u64).into()
                )
            )
        ));
        builder.append(engine::Action::ReturnVoid);

        f_decl = f.to_null_handle();
    }

    let ee = engine::ExecutionEngine::new(m);
    ee.prepare();

    let f = ee.get_callable_0::<()>(&f_decl);
    f();

    if buf1[2] != buf1[0] {
        panic!("Expecting value {} in buffer 1 slot 2, found {}", buf1[0], buf1[2]);
    }

    if buf2[2] != buf2[0] {
        panic!("Expecting value {} in buffer 2 slot 2, found {}", buf2[0], buf2[2]);
    }
}

#[test]
fn multithread_sync() {
    let (ee, _) = build_basic_sum_function();
    let mut threads = Vec::new();
    let ee = Arc::new(ee);

    for _ in 0..1000 {
        let ee = ee.clone();
        threads.push(std::thread::spawn(move || {
            let f = ee.get_callable_2::<i32, i32, i32>(
                &engine::Function::new_null_handle(
                    "test_function",
                    ValueType::Int32,
                    vec![
                        ValueType::Int32,
                        ValueType::Int32
                    ]
                )
            );
            if f(2, 3) != 10 {
                panic!("Incorrect result from jitted code");
            }
        }));
    }

    for t in threads {
        t.join().unwrap();
    }
}
