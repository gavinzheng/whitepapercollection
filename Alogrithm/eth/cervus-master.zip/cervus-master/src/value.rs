use std::ffi::CString;
use std::ops::{Add, Sub, Mul};
use std::os::raw::c_void;
use llvm_sys::prelude::*;
use llvm_sys::core::*;
use engine;
use engine::{Module, Function};
use value_type::ValueType;
use engine::GLOBAL_LLVM_LOCK;
use builder_scope;

#[derive(Clone)]
pub struct Value {
    pub _ref: LLVMValueRef,
    pub kind: Option<ValueType>
}

pub trait IntoValue {
    fn into_value(self) -> Value;
}

#[derive(Eq, PartialEq)]
pub enum SignedOrNot {
    Undefined,
    Signed,
    Unsigned
}

#[derive(Eq, PartialEq)]
pub enum CompareType {
    Lt,
    Le,
    Gt,
    Ge,
    Eq,
    Ne
}

impl CompareType {
    fn prepare_for_int(self, left: engine::Value, right: engine::Value, signed: &SignedOrNot) -> engine::Action {
        use self::SignedOrNot::*;
        use self::CompareType::*;

        match self {
            Lt => match *signed {
                Signed => engine::Action::SignedIntLessThan(left, right),
                Unsigned => engine::Action::UnsignedIntLessThan(left, right),
                Undefined => panic!("SignedOrNot required")
            },
            Le => match *signed {
                Signed => engine::Action::SignedIntLessThanOrEqual(left, right),
                Unsigned => engine::Action::UnsignedIntLessThanOrEqual(left, right),
                Undefined => panic!("SignedOrNot required")
            },
            Gt => match *signed {
                Signed => engine::Action::SignedIntGreaterThan(left, right),
                Unsigned => engine::Action::UnsignedIntGreaterThan(left, right),
                Undefined => panic!("SignedOrNot required")
            },
            Ge => match *signed {
                Signed => engine::Action::SignedIntGreaterThanOrEqual(left, right),
                Unsigned => engine::Action::UnsignedIntGreaterThanOrEqual(left, right),
                Undefined => panic!("SignedOrNot required")
            },
            Eq => engine::Action::IntEqual(left, right),
            Ne => engine::Action::IntNotEqual(left, right)
        }
    }
}

impl<T> IntoValue for T where T: Into<Value> {
    fn into_value(self) -> Value {
        self.into()
    }
}

impl Value {
    pub fn const_int_to_ptr(&self, target_type: ValueType) -> Value {
        let _gll = GLOBAL_LLVM_LOCK.lock().unwrap();

        Value {
            _ref: unsafe {
                let type_ref = target_type.get_ref();
                let v = LLVMConstIntToPtr(self._ref, type_ref);
                if v.is_null() {
                    panic!("const_int_to_ptr: Unexpected null pointer");
                }
                v
            },
            kind: Some(target_type.clone())
        }
    }

    pub fn from_named_function(m: &Module, name: &str) -> Value {
        let _gll = GLOBAL_LLVM_LOCK.lock().unwrap();
        let f = unsafe {
            LLVMGetNamedFunction(
                *m._ref.borrow_mut(),
                CString::new(name).unwrap().as_ptr()
            )
        };

        if f.is_null() {
            panic!("LLVMGetNamedFunction failed");
        }

        Value {
            _ref: f,
            kind: None
        }
    }

    pub fn store(&self, val: Value) {
        let builder = unsafe { builder_scope::current_builder() };
        if self.kind.is_some() && self.kind.as_ref().unwrap().is_pointer() {
            builder.append(
                engine::Action::Store(
                    val,
                    self.clone()
                )
            );
        } else {
            panic!("store: Type mismatch");
        }
    }

    pub fn store_to(self, p: &Value) {
        p.store(self);
    }

    pub fn load(&self) -> Value {
        let builder = unsafe { builder_scope::current_builder() };
        if self.kind.is_some() && self.kind.as_ref().unwrap().is_pointer() {
            let mut ret = builder.append(
                engine::Action::Load(
                    self.clone()
                )
            );
            let kind = self.kind.as_ref().unwrap();

            if let ValueType::Pointer(ref inner) = *kind {
                ret.kind = Some((**inner).clone());
            } else {
                unreachable!();
            }

            ret
        } else {
            panic!("load: Type mismatch");
        }
    }

    pub fn cast(&self, target_type: ValueType) -> Value {
        let builder = unsafe { builder_scope::current_builder() };
        let mut ret = if target_type.is_integer() && self.kind.as_ref().unwrap().is_integer() {
            builder.append(
                engine::Action::IntCast(self.clone(), target_type.clone())
            )
        } else if self.kind.as_ref().unwrap().is_pointer() && target_type == ValueType::Int64 {
            builder.append(
                engine::Action::PtrToInt(self.clone(), target_type.clone())
            )
        } else if *self.kind.as_ref().unwrap() == ValueType::Int64 && target_type.is_pointer() {
            builder.append(
                engine::Action::IntToPtr(self.clone(), target_type.clone())
            )
        } else if self.kind.as_ref().unwrap().is_pointer() && target_type.is_pointer() {
            builder.append(
                engine::Action::PointerCast(self.clone(), target_type.clone())
            )
        } else {
            panic!("cast: Unsupported type(s)")
        };

        ret.kind = Some(target_type);
        ret
    }

    pub fn compare(&self, other: Value, signed: SignedOrNot, cmp_type: CompareType) -> Value {
        let builder = unsafe { builder_scope::current_builder() };

        if self.kind == other.kind {
            if
                self.kind == Some(ValueType::Int1)
                || self.kind == Some(ValueType::Int8)
                || self.kind == Some(ValueType::Int16)
                || self.kind == Some(ValueType::Int32)
                || self.kind == Some(ValueType::Int64)
            {
                let act = cmp_type.prepare_for_int(self.clone(), other, &signed);
                let mut ret = builder.append(act);
                ret.kind = Some(ValueType::Int1);
                ret
            } else {
                panic!("compare: Unsupported type");
            }
        } else {
            panic!("compare: Type mismatch");
        }
    }

    pub fn conditional_branch(&self, if_true: &engine::BasicBlock, if_false: &engine::BasicBlock) {
        let builder = unsafe { builder_scope::current_builder() };

        if self.kind != Some(ValueType::Int1) {
            panic!("conditional_branch: Int1 required");
        }

        builder.append(
            engine::Action::ConditionalBranch(
                self.clone(),
                if_true,
                if_false
            )
        );
    }

    pub fn is_callable(&self) -> bool {
        if let ValueType::Pointer(ref inner) = *self.kind.as_ref().unwrap() {
            if let ValueType::Function(_, _) = **inner {
                true
            } else {
                false
            }
        } else {
            false
        }
    }

    pub fn call<T: BuildValueList>(&self, params: T) -> Value {
        if !self.is_callable() {
            panic!("call: Value is not callable");
        }

        let params = params.build_value_list();
        let ret_type: ValueType;
        let param_types: Vec<ValueType> = params
            .iter()
            .map(|v| v.kind.as_ref().unwrap().clone())
            .collect();

        if let ValueType::Pointer(ref inner) = *self.kind.as_ref().unwrap() {
            if let ValueType::Function(ref rt, ref pt) = **inner {
                ret_type = (**rt).clone();

                if pt.len() != param_types.len() {
                    panic!("call: Invalid parameter count");
                }

                for i in 0..pt.len() {
                    if pt[i] != param_types[i] {
                        panic!("call: Param {} type mismatch", i);
                    }
                }
            } else {
                unreachable!();
            }
        } else {
            unreachable!();
        }

        let builder = unsafe { builder_scope::current_builder() };
        let mut ret = builder.append(engine::Action::Call(
            self.clone(),
            params
        ));
        ret.kind = Some(ret_type);
        ret
    }
}

impl<'a> From<Function<'a>> for Value {
    fn from(v: Function<'a>) -> Value {
        let _gll = GLOBAL_LLVM_LOCK.lock().unwrap();
        let ret_type = v.ret_type.clone();
        let param_types = v.param_types.clone();

        Value {
            _ref: v._ref,
            kind: Some(ValueType::Pointer(Box::new(ValueType::Function(
                Box::new(ret_type),
                param_types
            ))))
        }
    }
}

impl<'a> From<&'a Function<'a>> for Value {
    fn from(v: &'a Function<'a>) -> Value {
        let _gll = GLOBAL_LLVM_LOCK.lock().unwrap();
        let ret_type = v.ret_type.clone();
        let param_types = v.param_types.clone();

        Value {
            _ref: v._ref,
            kind: Some(ValueType::Pointer(Box::new(ValueType::Function(
                Box::new(ret_type),
                param_types
            ))))
        }
    }
}

impl From<bool> for Value {
    fn from(v: bool) -> Value {
        let _gll = GLOBAL_LLVM_LOCK.lock().unwrap();

        unsafe {
            Value {
                _ref: LLVMConstInt(ValueType::Int1.get_ref(), v as u64, 0),
                kind: Some(ValueType::Int1)
            }
        }
    }
}

impl From<i8> for Value {
    fn from(v: i8) -> Value {
        let _gll = GLOBAL_LLVM_LOCK.lock().unwrap();

        unsafe {
            Value {
                _ref: LLVMConstInt(ValueType::Int8.get_ref(), v as u64, 1),
                kind: Some(ValueType::Int8)
            }
        }
    }
}

impl From<i16> for Value {
    fn from(v: i16) -> Value {
        let _gll = GLOBAL_LLVM_LOCK.lock().unwrap();

        unsafe {
            Value {
                _ref: LLVMConstInt(ValueType::Int16.get_ref(), v as u64, 1),
                kind: Some(ValueType::Int16)
            }
        }
    }
}

impl From<i32> for Value {
    fn from(v: i32) -> Value {
        let _gll = GLOBAL_LLVM_LOCK.lock().unwrap();
        
        unsafe {
            Value {
                _ref: LLVMConstInt(ValueType::Int32.get_ref(), v as u64, 1),
                kind: Some(ValueType::Int32)
            }
        }
    }
}

impl From<i64> for Value {
    fn from(v: i64) -> Value {
        let _gll = GLOBAL_LLVM_LOCK.lock().unwrap();

        unsafe {
            Value {
                _ref: LLVMConstInt(ValueType::Int64.get_ref(), v as u64, 1),
                kind: Some(ValueType::Int64)
            }
        }
    }
}

impl From<u8> for Value {
    fn from(v: u8) -> Value {
        let _gll = GLOBAL_LLVM_LOCK.lock().unwrap();

        unsafe {
            Value {
                _ref: LLVMConstInt(ValueType::Int8.get_ref(), v as u64, 0),
                kind: Some(ValueType::Int8)
            }
        }
    }
}

impl From<u16> for Value {
    fn from(v: u16) -> Value {
        let _gll = GLOBAL_LLVM_LOCK.lock().unwrap();

        unsafe {
            Value {
                _ref: LLVMConstInt(ValueType::Int16.get_ref(), v as u64, 0),
                kind: Some(ValueType::Int16)
            }
        }
    }
}

impl From<u32> for Value {
    fn from(v: u32) -> Value {
        let _gll = GLOBAL_LLVM_LOCK.lock().unwrap();

        unsafe {
            Value {
                _ref: LLVMConstInt(ValueType::Int32.get_ref(), v as u64, 0),
                kind: Some(ValueType::Int32)
            }
        }
    }
}

impl From<u64> for Value {
    fn from(v: u64) -> Value {
        let _gll = GLOBAL_LLVM_LOCK.lock().unwrap();

        unsafe {
            Value {
                _ref: LLVMConstInt(ValueType::Int64.get_ref(), v as u64, 0),
                kind: Some(ValueType::Int64)
            }
        }
    }
}

impl From<f64> for Value {
    fn from(v: f64) -> Value {
        let _gll = GLOBAL_LLVM_LOCK.lock().unwrap();

        unsafe {
            Value {
                _ref: LLVMConstReal(ValueType::Float64.get_ref(), v),
                kind: Some(ValueType::Float64)
            }
        }
    }
}

impl<T> From<*const T> for Value where T: Sized + 'static {
    fn from(v: *const T) -> Value {
        let _gll = GLOBAL_LLVM_LOCK.lock().unwrap();
        let vt = ValueType::Pointer(Box::new(ValueType::of::<T>().unwrap()));

        unsafe {
            Value {
                _ref: LLVMConstIntToPtr(
                    LLVMConstInt(ValueType::Int64.get_ref(), v as u64, 0),
                    vt.get_ref()
                ),
                kind: Some(vt)
            }
        }
    }
}

impl<T> From<*mut T> for Value where T: Sized + 'static {
    fn from(v: *mut T) -> Value {
        Value::from(v as *const T)
    }
}

impl Add for Value {
    type Output = Value;

    fn add(self, other: Value) -> Value {
        let builder = unsafe { builder_scope::current_builder() };
        if self.kind == other.kind {
            if
                self.kind == Some(ValueType::Int8)
                || self.kind == Some(ValueType::Int16)
                || self.kind == Some(ValueType::Int32)
                || self.kind == Some(ValueType::Int64)
            {
                let mut ret = builder.append(
                    engine::Action::IntAdd(
                        self.clone(),
                        other.clone()
                    )
                );
                ret.kind = self.kind.clone();
                ret
            } else if self.kind == Some(ValueType::Float64) {
                let mut ret = builder.append(
                    engine::Action::FloatAdd(
                        self.clone(),
                        other.clone()
                    )
                );
                ret.kind = self.kind.clone();
                ret
            } else {
                panic!("add: Unsupported type");
            }
        } else if
            self.kind.is_some()
            && self.kind.as_ref().unwrap().is_pointer()
            && (
                other.kind == Some(ValueType::Int8)
                || other.kind == Some(ValueType::Int16)
                || other.kind == Some(ValueType::Int32)
                || other.kind == Some(ValueType::Int64)
            )
        {
            let mut ret = builder.append(
                engine::Action::PtrOffset(
                    self.clone(),
                    other.clone()
                )
            );
            ret.kind = self.kind.clone();
            ret
        } else {
            panic!("add: Type mismatch")
        }
    }
}

impl Sub for Value {
    type Output = Value;

    fn sub(self, other: Value) -> Value {
        let builder = unsafe { builder_scope::current_builder() };
        if self.kind == other.kind {
            if
                self.kind == Some(ValueType::Int8)
                || self.kind == Some(ValueType::Int16)
                || self.kind == Some(ValueType::Int32)
                || self.kind == Some(ValueType::Int64)
            {
                let mut ret = builder.append(
                    engine::Action::IntSub(
                        self.clone(),
                        other.clone()
                    )
                );
                ret.kind = self.kind.clone();
                ret
            } else if self.kind == Some(ValueType::Float64) {
                let mut ret = builder.append(
                    engine::Action::FloatSub(
                        self.clone(),
                        other.clone()
                    )
                );
                ret.kind = self.kind.clone();
                ret
            } else {
                panic!("sub: Unsupported type");
            }
        } else {
            panic!("sub: Type mismatch")
        }
    }
}

impl Mul for Value {
    type Output = Value;

    fn mul(self, other: Value) -> Value {
        let builder = unsafe { builder_scope::current_builder() };
        if self.kind == other.kind {
            if
                self.kind == Some(ValueType::Int8)
                || self.kind == Some(ValueType::Int16)
                || self.kind == Some(ValueType::Int32)
                || self.kind == Some(ValueType::Int64)
            {
                let mut ret = builder.append(
                    engine::Action::IntMul(
                        self.clone(),
                        other.clone()
                    )
                );
                ret.kind = self.kind.clone();
                ret
            } else if self.kind == Some(ValueType::Float64) {
                let mut ret = builder.append(
                    engine::Action::FloatMul(
                        self.clone(),
                        other.clone()
                    )
                );
                ret.kind = self.kind.clone();
                ret
            } else {
                panic!("mul: Unsupported type");
            }
        } else {
            panic!("mul: Type mismatch")
        }
    }
}

pub trait IntoFunctionPointer {
    fn into_function_pointer(self) -> Value;
}

fn raw_into_function_pointer(
    f: *const c_void,
    ret_type: ValueType,
    param_types: Vec<ValueType>
) -> Value {
    engine::Value::from(f as u64)
        .const_int_to_ptr(ValueType::Pointer(Box::new(
            ValueType::Function(
                Box::new(ret_type),
                param_types
            )
        )))
}

impl<R> IntoFunctionPointer for extern "C" fn () -> R where R: 'static {
    fn into_function_pointer(self) -> Value {
        raw_into_function_pointer(
            self as *const c_void,
            ValueType::of::<R>().unwrap(),
            vec![]
        )
    }
}

impl<R, T1> IntoFunctionPointer for extern "C" fn (T1) -> R
    where
        R: 'static,
        T1: 'static
{
    fn into_function_pointer(self) -> Value {
        raw_into_function_pointer(
            self as *const c_void,
            ValueType::of::<R>().unwrap(),
            vec![
                ValueType::of::<T1>().unwrap()
            ]
        )
    }
}

impl<R, T1, T2> IntoFunctionPointer for extern "C" fn (T1, T2) -> R
    where
        R: 'static,
        T1: 'static,
        T2: 'static
{
    fn into_function_pointer(self) -> Value {
        raw_into_function_pointer(
            self as *const c_void,
            ValueType::of::<R>().unwrap(),
            vec![
                ValueType::of::<T1>().unwrap(),
                ValueType::of::<T2>().unwrap()
            ]
        )
    }
}

impl<R, T1, T2, T3> IntoFunctionPointer for extern "C" fn (T1, T2, T3) -> R
    where
        R: 'static,
        T1: 'static,
        T2: 'static,
        T3: 'static
{
    fn into_function_pointer(self) -> Value {
        raw_into_function_pointer(
            self as *const c_void,
            ValueType::of::<R>().unwrap(),
            vec![
                ValueType::of::<T1>().unwrap(),
                ValueType::of::<T2>().unwrap(),
                ValueType::of::<T3>().unwrap()
            ]
        )
    }
}

impl<R, T1, T2, T3, T4> IntoFunctionPointer for extern "C" fn (T1, T2, T3, T4) -> R
    where
        R: 'static,
        T1: 'static,
        T2: 'static,
        T3: 'static,
        T4: 'static,
{
    fn into_function_pointer(self) -> Value {
        raw_into_function_pointer(
            self as *const c_void,
            ValueType::of::<R>().unwrap(),
            vec![
                ValueType::of::<T1>().unwrap(),
                ValueType::of::<T2>().unwrap(),
                ValueType::of::<T3>().unwrap(),
                ValueType::of::<T4>().unwrap()
            ]
        )
    }
}

impl<R, T1, T2, T3, T4, T5> IntoFunctionPointer for extern "C" fn (T1, T2, T3, T4, T5) -> R
    where
        R: 'static,
        T1: 'static,
        T2: 'static,
        T3: 'static,
        T4: 'static,
        T5: 'static
{
    fn into_function_pointer(self) -> Value {
        raw_into_function_pointer(
            self as *const c_void,
            ValueType::of::<R>().unwrap(),
            vec![
                ValueType::of::<T1>().unwrap(),
                ValueType::of::<T2>().unwrap(),
                ValueType::of::<T3>().unwrap(),
                ValueType::of::<T4>().unwrap(),
                ValueType::of::<T5>().unwrap()
            ]
        )
    }
}

impl<R, T1, T2, T3, T4, T5, T6> IntoFunctionPointer for extern "C" fn (T1, T2, T3, T4, T5, T6) -> R
    where
        R: 'static,
        T1: 'static,
        T2: 'static,
        T3: 'static,
        T4: 'static,
        T5: 'static,
        T6: 'static
{
    fn into_function_pointer(self) -> Value {
        raw_into_function_pointer(
            self as *const c_void,
            ValueType::of::<R>().unwrap(),
            vec![
                ValueType::of::<T1>().unwrap(),
                ValueType::of::<T2>().unwrap(),
                ValueType::of::<T3>().unwrap(),
                ValueType::of::<T4>().unwrap(),
                ValueType::of::<T5>().unwrap(),
                ValueType::of::<T6>().unwrap()
            ]
        )
    }
}

pub trait BuildValueList {
    fn build_value_list(self) -> Vec<Value>;
}

impl BuildValueList for Vec<Value> {
    fn build_value_list(self) -> Vec<Value> {
        self
    }
}

impl BuildValueList for () {
    fn build_value_list(self) -> Vec<Value> {
        vec![]
    }
}

impl<T1> BuildValueList for (T1,)
    where
        T1: Into<Value>
{
    fn build_value_list(self) -> Vec<Value> {
        vec![
            self.0.into()
        ]
    }
}

impl<T1, T2> BuildValueList for (T1, T2)
    where
        T1: Into<Value>,
        T2: Into<Value>
{
    fn build_value_list(self) -> Vec<Value> {
        vec![
            self.0.into(),
            self.1.into()
        ]
    }
}

impl<T1, T2, T3> BuildValueList for (T1, T2, T3)
    where
        T1: Into<Value>,
        T2: Into<Value>,
        T3: Into<Value>
{
    fn build_value_list(self) -> Vec<Value> {
        vec![
            self.0.into(),
            self.1.into(),
            self.2.into()
        ]
    }
}

impl<T1, T2, T3, T4> BuildValueList for (T1, T2, T3, T4)
    where
        T1: Into<Value>,
        T2: Into<Value>,
        T3: Into<Value>,
        T4: Into<Value>
{
    fn build_value_list(self) -> Vec<Value> {
        vec![
            self.0.into(),
            self.1.into(),
            self.2.into(),
            self.3.into()
        ]
    }
}

impl<T1, T2, T3, T4, T5> BuildValueList for (T1, T2, T3, T4, T5)
    where
        T1: Into<Value>,
        T2: Into<Value>,
        T3: Into<Value>,
        T4: Into<Value>,
        T5: Into<Value>
{
    fn build_value_list(self) -> Vec<Value> {
        vec![
            self.0.into(),
            self.1.into(),
            self.2.into(),
            self.3.into(),
            self.4.into()
        ]
    }
}

impl<T1, T2, T3, T4, T5, T6> BuildValueList for (T1, T2, T3, T4, T5, T6)
    where
        T1: Into<Value>,
        T2: Into<Value>,
        T3: Into<Value>,
        T4: Into<Value>,
        T5: Into<Value>,
        T6: Into<Value>
{
    fn build_value_list(self) -> Vec<Value> {
        vec![
            self.0.into(),
            self.1.into(),
            self.2.into(),
            self.3.into(),
            self.4.into(),
            self.5.into()
        ]
    }
}
