use std;
use std::any::Any;
use std::ops::{Deref, DerefMut};
use std::ffi::{CStr, CString};
use std::os::raw::{c_char, c_void};
use std::sync::atomic;
use std::sync::Mutex;
use std::cell::RefCell;
use llvm_sys::linker::*;
use llvm_sys::target::*;
use llvm_sys::bit_reader::*;
use llvm_sys::target_machine::*;
use llvm_sys::core::*;
use llvm_sys::transforms::scalar::*;
use llvm_sys::analysis::*;
use llvm_sys::execution_engine::*;
use llvm_sys::prelude::*;
use llvm_sys::LLVMIntPredicate;
use base64;
use value_type::{ValueType, BuildTypeList};
pub use value::Value;
use builder_scope;
use crt_generated;
use crt::Crt;

lazy_static! {
    static ref GLOBAL_INIT_DONE: Mutex<bool> = Mutex::new(false);
    pub static ref GLOBAL_LLVM_LOCK: Mutex<bool> = Mutex::new(false);
    static ref CRT_BITCODE: Vec<u8> = {
        let mut bitcode = String::new();
        for c in crt_generated::CODE.chars() {
            if c == '\n' || c == ' ' {
                continue;
            }
            bitcode.push(c);
        }
        base64::decode(bitcode.as_str()).unwrap()
    };
}

pub unsafe fn init() {
    let mut global_init_done = GLOBAL_INIT_DONE.lock().unwrap();

    if *global_init_done {
        return;
    }

    {
        let _gll = GLOBAL_LLVM_LOCK.lock().unwrap();

        LLVMLinkInMCJIT();
        LLVM_InitializeNativeTarget();
        LLVM_InitializeNativeAsmPrinter();
        LLVM_InitializeNativeAsmParser();
    }

    *global_init_done = true;
}

/*
pub unsafe fn add_global_symbol(name: &str, target: *const c_void) {
    let _gll = GLOBAL_LLVM_LOCK.lock().unwrap();
    LLVMAddSymbol(CString::new(name).unwrap().as_ptr(), std::mem::transmute(target));
}*/

pub struct ModuleResource {
    inner: Box<Any>
}

impl From<Box<Any>> for ModuleResource {
    fn from(v: Box<Any>) -> ModuleResource {
        ModuleResource {
            inner: v
        }
    }
}

impl Into<Box<Any>> for ModuleResource {
    fn into(self) -> Box<Any> {
        self.inner
    }
}

impl Deref for ModuleResource {
    type Target = Box<Any>;
    fn deref(&self) -> &Box<Any> {
        &self.inner
    }
}

impl DerefMut for ModuleResource {
    fn deref_mut(&mut self) -> &mut Box<Any> {
        &mut self.inner
    }
}

#[allow(dead_code)]
pub struct Module {
    name: String,
    pub resources: Mutex<Vec<Box<ModuleResource>>>,
    pub _ref: RefCell<LLVMModuleRef>
}

impl Module {
    pub fn new(_name: &str) -> Module {
        unsafe {
            init();
        }

        let name = CString::new(_name).unwrap();

        let _gll = GLOBAL_LLVM_LOCK.lock().unwrap();

        let mod_ref = unsafe { LLVMModuleCreateWithName(name.as_ptr()) };
        Module {
            name: _name.to_string(),
            resources: Mutex::new(Vec::new()),
            _ref: RefCell::new(mod_ref)
        }
    }

    fn _patch(self) -> Module {
        let patch_mod = Module::from_bitcode("", CRT_BITCODE.as_slice()).unwrap();
        patch_mod.copy_data_layout_from(&self);

        self.link(patch_mod)
    }

    pub fn from_bitcode(name: &str, data: &[u8]) -> Option<Module> {
        unsafe {
            init();

            let _gll = GLOBAL_LLVM_LOCK.lock().unwrap();

            let buf = LLVMCreateMemoryBufferWithMemoryRange(
                data.as_ptr() as *const i8,
                data.len(),
                CString::new(format!("code_{}", name)).unwrap().as_ptr(),
                0
            );

            let mut m = std::ptr::null_mut();
            let ret = LLVMParseBitcode2(buf, &mut m);

            LLVMDisposeMemoryBuffer(buf);
            if ret != 0 {
                None
            } else {
                Some(Module {
                    name: name.to_string(),
                    resources: Mutex::new(Vec::new()),
                    _ref: RefCell::new(m)
                })
            }
        }
    }

    pub fn copy_data_layout_from(&self, other: &Module) {
        let _gll = GLOBAL_LLVM_LOCK.lock().unwrap();

        unsafe {
            LLVMSetDataLayout(*self._ref.borrow_mut(), LLVMGetDataLayout(*other._ref.borrow_mut()));
        }
    }

    pub fn link(self, other: Module) -> Module {
        let _gll = GLOBAL_LLVM_LOCK.lock().unwrap();
        
        unsafe {
            let ret = LLVMLinkModules2(*self._ref.borrow_mut(), *other._ref.borrow_mut());
            if ret != 0 {
                panic!("Linking failed");
            }

            *other._ref.borrow_mut() = std::ptr::null_mut();
        }

        self
    }

    pub fn into_execution_engine(self) -> ExecutionEngine {
        ExecutionEngine::new(self)
    }

    pub fn crt<'a>(&'a self) -> Crt<'a> {
        Crt::new(self)
    }
}

impl Drop for Module {
    fn drop(&mut self) {
        let _ref = self._ref.borrow_mut();
        if !_ref.is_null() {
            let _gll = GLOBAL_LLVM_LOCK.lock().unwrap();

            unsafe {
                LLVMDisposeModule(*_ref);
            }
        }
    }
}

unsafe impl Send for Module {}
unsafe impl Sync for Module {}

pub struct ExecutionEngine {
    module: Module,
    _ref: LLVMExecutionEngineRef,
    _pm_ref: LLVMPassManagerRef
}

impl ExecutionEngine {
    pub fn new(module: Module) -> ExecutionEngine {
        let module = module._patch();
        let _gll = GLOBAL_LLVM_LOCK.lock().unwrap();

        unsafe {
            let mut err_str: *mut c_char = std::ptr::null_mut();
            let ret = LLVMVerifyModule(*module._ref.borrow_mut(), LLVMVerifierFailureAction::LLVMReturnStatusAction, &mut err_str);
            if ret != 0 {
                let err_msg = CStr::from_ptr(err_str).to_str().unwrap();
                panic!("Module verification failed: {}", err_msg);
            }
            LLVMDisposeMessage(err_str);
            err_str = std::ptr::null_mut();

            let mut ee: LLVMExecutionEngineRef = std::ptr::null_mut();
            let mut mcjit_options = LLVMMCJITCompilerOptions {
                OptLevel: 3,
                CodeModel: LLVMCodeModel::LLVMCodeModelJITDefault,
                NoFramePointerElim: 0,
                EnableFastISel: 0,
                MCJMM: std::ptr::null_mut()
            };

            LLVMInitializeMCJITCompilerOptions(&mut mcjit_options, std::mem::size_of::<LLVMMCJITCompilerOptions>());
            mcjit_options.OptLevel = 3;

            let ret = LLVMCreateMCJITCompilerForModule(&mut ee, *module._ref.borrow_mut(), &mut mcjit_options, std::mem::size_of::<LLVMMCJITCompilerOptions>(), &mut err_str);

            if ret != 0 {
                panic!("Unable to create execution engine");
            }

            if !err_str.is_null() {
                LLVMDisposeMessage(err_str);
                //err_str = std::ptr::null_mut();
            }

            let pm = LLVMCreatePassManager();
            LLVMAddConstantPropagationPass(pm);
            LLVMAddInstructionCombiningPass(pm);
            LLVMAddGVNPass(pm);

            ExecutionEngine {
                module: module,
                _ref: ee,
                _pm_ref: pm
            }
        }
    }

    pub fn get_module(&self) -> &Module {
        &self.module
    }

    pub fn prepare(&self) {
        let _gll = GLOBAL_LLVM_LOCK.lock().unwrap();

        unsafe {
            LLVMRunPassManager(self._pm_ref, *self.module._ref.borrow_mut());
        }
    }

    pub fn get_raw_callable(&self, f: &Function) -> *const c_void {
        let _gll = GLOBAL_LLVM_LOCK.lock().unwrap();

        unsafe {
            let fn_name = f.name.as_str();

            let f = LLVMGetFunctionAddress(self._ref, CString::new(fn_name).unwrap().as_ptr()) as usize;
            if f == 0 {
                panic!("Unable to get function address for: {}", fn_name);
            }

            f as *const c_void
        }
    }

    // FIXME: get_callable_* should be refactored in the next major version.

    pub fn get_callable_0<R>(&self, f: &Function) -> extern "C" fn () -> R
        where
            R: 'static
    {
        if ValueType::of::<R>().unwrap() != f.ret_type {
            panic!("get_callable: Return type mismatch");
        }

        if f.param_types.len() != 0 {
            panic!("get_callable: Incorrect param count");
        }

        unsafe {
            std::mem::transmute::<*const c_void, extern "C" fn () -> R>(self.get_raw_callable(f))
        }
    }

    pub fn get_callable_1<R, A>(&self, f: &Function) -> extern "C" fn (A) -> R
        where
            R: 'static,
            A: 'static
    {
        if ValueType::of::<R>().unwrap() != f.ret_type {
            panic!("get_callable: Return type mismatch");
        }

        if f.param_types.len() != 1 {
            panic!("get_callable: Incorrect param count");
        }

        if ValueType::of::<A>().unwrap() != f.param_types[0] {
            panic!("get_callable: Param 0 type mismatch")
        }

        unsafe {
            std::mem::transmute::<*const c_void, extern "C" fn (A) -> R>(self.get_raw_callable(f))
        }
    }

    pub fn get_callable_2<R, A, B>(&self, f: &Function) -> extern "C" fn (A, B) -> R
        where
            R: 'static,
            A: 'static,
            B: 'static
    {
        if ValueType::of::<R>().unwrap() != f.ret_type {
            panic!("get_callable: Return type mismatch");
        }

        if f.param_types.len() != 2 {
            panic!("get_callable: Incorrect param count");
        }

        if ValueType::of::<A>().unwrap() != f.param_types[0] {
            panic!("get_callable: Param 0 type mismatch")
        }

        if ValueType::of::<B>().unwrap() != f.param_types[1] {
            panic!("get_callable: Param 1 type mismatch")
        }

        unsafe {
            std::mem::transmute::<*const c_void, extern "C" fn (A, B) -> R>(self.get_raw_callable(f))
        }
    }

    pub fn get_callable_3<R, A, B, C>(&self, f: &Function) -> extern "C" fn (A, B, C) -> R
        where
            R: 'static,
            A: 'static,
            B: 'static,
            C: 'static
    {
        if ValueType::of::<R>().unwrap() != f.ret_type {
            panic!("get_callable: Return type mismatch");
        }

        if f.param_types.len() != 3 {
            panic!("get_callable: Incorrect param count");
        }

        if ValueType::of::<A>().unwrap() != f.param_types[0] {
            panic!("get_callable: Param 0 type mismatch")
        }

        if ValueType::of::<B>().unwrap() != f.param_types[1] {
            panic!("get_callable: Param 1 type mismatch")
        }

        if ValueType::of::<C>().unwrap() != f.param_types[2] {
            panic!("get_callable: Param 2 type mismatch")
        }

        unsafe {
            std::mem::transmute::<*const c_void, extern "C" fn (A, B, C) -> R>(self.get_raw_callable(f))
        }
    }
}

impl Drop for ExecutionEngine {
    fn drop(&mut self) {
        let _gll = GLOBAL_LLVM_LOCK.lock().unwrap();

        unsafe {
            LLVMDisposePassManager(self._pm_ref);
            LLVMDisposeExecutionEngine(self._ref);
            let mut module_ref = self.module._ref.borrow_mut();
            if !module_ref.is_null() {
                *module_ref = std::ptr::null_mut();
            }
        }
    }
}

unsafe impl Send for ExecutionEngine {}
unsafe impl Sync for ExecutionEngine {}

#[allow(dead_code)]
pub struct Function<'a> {
    module: Option<&'a Module>,
    name: String,
    pub ret_type: ValueType,
    pub param_types: Vec<ValueType>,
    pub _ref: LLVMValueRef
}

unsafe impl<'a> Send for Function<'a> {}

impl<'a> Function<'a> {
    pub fn new(module: &'a Module, name: &str, ret_type: ValueType, param_types: Vec<ValueType>) -> Function<'a> {
        let _gll = GLOBAL_LLVM_LOCK.lock().unwrap();

        let fn_ref = unsafe {
            let mut raw_pt = Vec::with_capacity(param_types.len());
            for t in &param_types {
                raw_pt.push(t.get_ref());
            }
            let ret_type_ref = ret_type.get_ref();
            let fn_type = LLVMFunctionType(ret_type_ref, raw_pt.as_mut_ptr(), raw_pt.len() as u32, 0);
            LLVMAddFunction(*module._ref.borrow_mut(), CString::new(name).unwrap().as_ptr(), fn_type)
        };

        Function {
            module: Some(module),
            name: name.to_owned(),
            ret_type: ret_type,
            param_types: param_types,
            _ref: fn_ref
        }
    }

    pub fn new_typed_ret<R>(module: &'a Module, name: &str, param_types: Vec<ValueType>) -> Function<'a>
        where R: ?Sized + 'static
    {
        Function::new(module, name, ValueType::of::<R>().unwrap(), param_types)
    }

    pub fn new_typed<R, T>(module: &'a Module, name: &str) -> Function<'a>
        where
            R: ?Sized + 'static,
            T: BuildTypeList
    {
        Function::new_typed_ret::<R>(module, name, T::build())
    }

    pub fn new_null_handle(name: &str, ret_type: ValueType, param_types: Vec<ValueType>) -> Function<'static> {
        Function {
            module: None,
            name: name.to_owned(),
            ret_type: ret_type,
            param_types: param_types,
            _ref: std::ptr::null_mut()
        }
    }

    pub fn into_null_handle(self) -> Function<'static> {
        Function {
            module: None,
            name: self.name,
            ret_type: self.ret_type,
            param_types: self.param_types,
            _ref: std::ptr::null_mut()
        }
    }

    pub fn to_null_handle(&self) -> Function<'static> {
        Function {
            module: None,
            name: self.name.clone(),
            ret_type: self.ret_type.clone(),
            param_types: self.param_types.clone(),
            _ref: std::ptr::null_mut()
        }
    }

    pub fn get_param(&self, index: usize) -> Option<Value> {
        let _gll = GLOBAL_LLVM_LOCK.lock().unwrap();

        if index < self.param_types.len() {
            Some(Value {
                _ref: unsafe {
                    LLVMGetParam(self._ref, index as u32)
                },
                kind: Some(self.param_types[index].clone())
            })
        } else {
            None
        }
    }

    pub fn basic_block(&'a self, name: &str) -> BasicBlock<'a> {
        BasicBlock::new(self, name)
    }
}

#[allow(dead_code)]
pub struct BasicBlock<'a> {
    func: &'a Function<'a>,
    name: String,
    _ref: LLVMBasicBlockRef
}

impl<'a> BasicBlock<'a> {
    pub fn new(func: &'a Function, name: &str) -> BasicBlock<'a> {
        let _gll = GLOBAL_LLVM_LOCK.lock().unwrap();

        let bb_ref = unsafe {
            LLVMAppendBasicBlock(func._ref, CString::new(name).unwrap().as_ptr())
        };

        BasicBlock {
            func: func,
            name: name.to_owned(),
            _ref: bb_ref
        }
    }

    pub fn builder(&'a self) -> Builder<'a> {
        Builder::new(self)
    }
}

#[allow(dead_code)]
pub struct Builder<'a> {
    basic_block: &'a BasicBlock<'a>,
    next_action_id: atomic::AtomicUsize,
    _ref: LLVMBuilderRef
}

impl<'a> Builder<'a> {
    pub fn new(bb: &'a BasicBlock) -> Builder<'a> {
        let _gll = GLOBAL_LLVM_LOCK.lock().unwrap();

        let builder_ref = unsafe {
            let r = LLVMCreateBuilder();
            LLVMPositionBuilderAtEnd(r, bb._ref);
            r
        };
        Builder {
            basic_block: bb,
            next_action_id: atomic::AtomicUsize::new(0),
            _ref: builder_ref
        }
    }

    pub fn append(&self, act: Action<'a>) -> Value {
        let _gll = GLOBAL_LLVM_LOCK.lock().unwrap();

        Value {
            _ref: act.build(self),
            kind: None
        }
    }

    pub fn scope_handle(&'a self) -> builder_scope::BuilderScopeHandle<'a> {
        builder_scope::BuilderScopeHandle::new(self)
    }

    pub fn branch(&self, target: &BasicBlock) {
        self.append(
            Action::Branch(target)
        );
    }

    pub fn return_void(self) {
        self.append(
            Action::ReturnVoid
        );
    }

    pub fn return_value(self, val: Value) {
        self.append(
            Action::Return(val)
        );
    }

    pub fn alloca(&self, t: ValueType) -> Value {
        let mut ret = self.append(
            Action::Alloca(t.clone())
        );
        ret.kind = Some(ValueType::Pointer(Box::new(t)));
        ret
    }

    pub fn build_string<T: AsRef<str>>(&self, s: T) -> Value {
        let ret = self.append(
            Action::GlobalString(CString::new(s.as_ref()).unwrap())
        );
        let mut ret = self.append(
            Action::PointerCast(ret, ValueType::Pointer(Box::new(ValueType::Int8)))
        );
        ret.kind = Some(ValueType::Pointer(Box::new(ValueType::Int8)));
        ret
    }
}

impl<'a> Drop for Builder<'a> {
    fn drop(&mut self) {
        let _gll = GLOBAL_LLVM_LOCK.lock().unwrap();

        unsafe {
            LLVMDisposeBuilder(self._ref);
        }
    }
}


#[allow(dead_code)]
pub enum Action<'a> {
    IntAdd(Value, Value),
    FloatAdd(Value, Value),
    IntSub(Value, Value),
    FloatSub(Value, Value),
    IntMul(Value, Value),
    FloatMul(Value, Value),
    SignedIntDiv(Value, Value),
    UnsignedIntDiv(Value, Value),
    FloatDiv(Value, Value),
    SignedIntRem(Value, Value),
    UnsignedIntRem(Value, Value),
    FloatRem(Value, Value),
    And(Value, Value),
    Or(Value, Value),
    Xor(Value, Value),
    Not(Value),
    Shl(Value, Value),
    LogicalShr(Value, Value),
    ArithmeticShr(Value, Value),
    Return(Value),
    ReturnVoid,
    IntToPtr(Value, ValueType),
    PtrToInt(Value, ValueType),
    Call(Value, Vec<Value>),
    Branch(&'a BasicBlock<'a>),
    ConditionalBranch(Value, &'a BasicBlock<'a>, &'a BasicBlock<'a>),
    IntEqual(Value, Value),
    IntNotEqual(Value, Value),
    UnsignedIntGreaterThan(Value, Value),
    UnsignedIntGreaterThanOrEqual(Value, Value),
    UnsignedIntLessThan(Value, Value),
    UnsignedIntLessThanOrEqual(Value, Value),
    SignedIntGreaterThan(Value, Value),
    SignedIntGreaterThanOrEqual(Value, Value),
    SignedIntLessThan(Value, Value),
    SignedIntLessThanOrEqual(Value, Value),
    Load(Value),
    Store(Value, Value),
    PtrOffset(Value, Value),
    IntCast(Value, ValueType),
    Alloca(ValueType),
    GlobalString(CString),
    PointerCast(Value, ValueType)
}

impl<'a> Action<'a> {
    fn build(&self, builder: &Builder) -> LLVMValueRef {
        let action_id = builder.next_action_id.fetch_add(1, atomic::Ordering::SeqCst);
        let action_name = CString::new(format!("action_{}", action_id)).unwrap();

        unsafe {
            match self {
                &Action::IntAdd(ref left, ref right) => {
                    LLVMBuildAdd(builder._ref, left._ref, right._ref, action_name.as_ptr())
                },
                &Action::FloatAdd(ref left, ref right) => {
                    LLVMBuildFAdd(builder._ref, left._ref, right._ref, action_name.as_ptr())
                },
                &Action::IntSub(ref left, ref right) => {
                    LLVMBuildSub(builder._ref, left._ref, right._ref, action_name.as_ptr())
                },
                &Action::FloatSub(ref left, ref right) => {
                    LLVMBuildFSub(builder._ref, left._ref, right._ref, action_name.as_ptr())
                },
                &Action::IntMul(ref left, ref right) => {
                    LLVMBuildMul(builder._ref, left._ref, right._ref, action_name.as_ptr())
                },
                &Action::FloatMul(ref left, ref right) => {
                    LLVMBuildFMul(builder._ref, left._ref, right._ref, action_name.as_ptr())
                },
                &Action::SignedIntDiv(ref left, ref right) => {
                    LLVMBuildSDiv(builder._ref, left._ref, right._ref, action_name.as_ptr())
                },
                &Action::UnsignedIntDiv(ref left, ref right) => {
                    LLVMBuildUDiv(builder._ref, left._ref, right._ref, action_name.as_ptr())
                },
                &Action::FloatDiv(ref left, ref right) => {
                    LLVMBuildFDiv(builder._ref, left._ref, right._ref, action_name.as_ptr())
                },
                &Action::SignedIntRem(ref left, ref right) => {
                    LLVMBuildSRem(builder._ref, left._ref, right._ref, action_name.as_ptr())
                },
                &Action::UnsignedIntRem(ref left, ref right) => {
                    LLVMBuildURem(builder._ref, left._ref, right._ref, action_name.as_ptr())
                },
                &Action::FloatRem(ref left, ref right) => {
                    LLVMBuildFRem(builder._ref, left._ref, right._ref, action_name.as_ptr())
                },
                &Action::And(ref left, ref right) => {
                    LLVMBuildAnd(builder._ref, left._ref, right._ref, action_name.as_ptr())
                },
                &Action::Or(ref left, ref right) => {
                    LLVMBuildOr(builder._ref, left._ref, right._ref, action_name.as_ptr())
                },
                &Action::Xor(ref left, ref right) => {
                    LLVMBuildXor(builder._ref, left._ref, right._ref, action_name.as_ptr())
                },
                &Action::Not(ref v) => {
                    LLVMBuildNot(builder._ref, v._ref, action_name.as_ptr())
                },
                &Action::Shl(ref left, ref right) => {
                    LLVMBuildShl(builder._ref, left._ref, right._ref, action_name.as_ptr())
                },
                &Action::LogicalShr(ref left, ref right) => {
                    LLVMBuildLShr(builder._ref, left._ref, right._ref, action_name.as_ptr())
                },
                &Action::ArithmeticShr(ref left, ref right) => {
                    LLVMBuildAShr(builder._ref, left._ref, right._ref, action_name.as_ptr())
                },
                &Action::Return(ref v) => {
                    LLVMBuildRet(builder._ref, v._ref)
                },
                &Action::ReturnVoid => {
                    LLVMBuildRetVoid(builder._ref)
                },
                &Action::IntToPtr(ref v, ref target_type) => {
                    LLVMBuildIntToPtr(builder._ref, v._ref, target_type.get_ref(), action_name.as_ptr())
                },
                &Action::PtrToInt(ref v, ref target_type) => {
                    LLVMBuildPtrToInt(builder._ref, v._ref, target_type.get_ref(), action_name.as_ptr())
                },
                &Action::Call(ref target, ref args) => {
                    let mut args: Vec<LLVMValueRef> = args.iter().map(|v| v._ref).collect();
                    let name_buf = CString::new("").unwrap();

                    LLVMBuildCall(builder._ref, target._ref, args.as_mut_ptr(), args.len() as u32, name_buf.as_ptr())
                },
                &Action::Branch(ref target) => {
                    LLVMBuildBr(builder._ref, target._ref)
                },
                &Action::ConditionalBranch(ref v, ref if_true, ref if_false) => {
                    LLVMBuildCondBr(builder._ref, v._ref, if_true._ref, if_false._ref)
                },
                &Action::IntEqual(ref left, ref right) => {
                    LLVMBuildICmp(
                        builder._ref,
                        LLVMIntPredicate::LLVMIntEQ,
                        left._ref,
                        right._ref,
                        action_name.as_ptr()
                    )
                },
                &Action::IntNotEqual(ref left, ref right) => {
                    LLVMBuildICmp(
                        builder._ref,
                        LLVMIntPredicate::LLVMIntNE,
                        left._ref,
                        right._ref,
                        action_name.as_ptr()
                    )
                },
                &Action::UnsignedIntGreaterThan(ref left, ref right) => {
                    LLVMBuildICmp(
                        builder._ref,
                        LLVMIntPredicate::LLVMIntUGT,
                        left._ref,
                        right._ref,
                        action_name.as_ptr()
                    )
                },
                &Action::UnsignedIntGreaterThanOrEqual(ref left, ref right) => {
                    LLVMBuildICmp(
                        builder._ref,
                        LLVMIntPredicate::LLVMIntUGE,
                        left._ref,
                        right._ref,
                        action_name.as_ptr()
                    )
                },
                &Action::UnsignedIntLessThan(ref left, ref right) => {
                    LLVMBuildICmp(
                        builder._ref,
                        LLVMIntPredicate::LLVMIntULT,
                        left._ref,
                        right._ref,
                        action_name.as_ptr()
                    )
                },
                &Action::UnsignedIntLessThanOrEqual(ref left, ref right) => {
                    LLVMBuildICmp(
                        builder._ref,
                        LLVMIntPredicate::LLVMIntULE,
                        left._ref,
                        right._ref,
                        action_name.as_ptr()
                    )
                },
                &Action::SignedIntGreaterThan(ref left, ref right) => {
                    LLVMBuildICmp(
                        builder._ref,
                        LLVMIntPredicate::LLVMIntSGT,
                        left._ref,
                        right._ref,
                        action_name.as_ptr()
                    )
                },
                &Action::SignedIntGreaterThanOrEqual(ref left, ref right) => {
                    LLVMBuildICmp(
                        builder._ref,
                        LLVMIntPredicate::LLVMIntSGE,
                        left._ref,
                        right._ref,
                        action_name.as_ptr()
                    )
                },
                &Action::SignedIntLessThan(ref left, ref right) => {
                    LLVMBuildICmp(
                        builder._ref,
                        LLVMIntPredicate::LLVMIntSLT,
                        left._ref,
                        right._ref,
                        action_name.as_ptr()
                    )
                },
                &Action::SignedIntLessThanOrEqual(ref left, ref right) => {
                    LLVMBuildICmp(
                        builder._ref,
                        LLVMIntPredicate::LLVMIntSLE,
                        left._ref,
                        right._ref,
                        action_name.as_ptr()
                    )
                },
                &Action::Load(ref addr) => {
                    LLVMBuildLoad(
                        builder._ref,
                        addr._ref,
                        action_name.as_ptr()
                    )
                },
                &Action::Store(ref val, ref addr) => {
                    LLVMBuildStore(
                        builder._ref,
                        val._ref,
                        addr._ref
                    )
                },
                &Action::PtrOffset(ref p, ref offset) => {
                    LLVMBuildGEP(
                        builder._ref,
                        p._ref,
                        &offset._ref as *const LLVMValueRef as *mut LLVMValueRef,
                        1,
                        action_name.as_ptr()
                    )
                },
                &Action::IntCast(ref v, ref target_type) => {
                    LLVMBuildIntCast(
                        builder._ref,
                        v._ref,
                        target_type.get_ref(),
                        action_name.as_ptr()
                    )
                },
                &Action::Alloca(ref target_type) => {
                    LLVMBuildAlloca(
                        builder._ref,
                        target_type.get_ref(),
                        action_name.as_ptr()
                    )
                },
                &Action::GlobalString(ref s) => {
                    LLVMBuildGlobalString(
                        builder._ref,
                        s.as_ptr(),
                        action_name.as_ptr()
                    )
                },
                &Action::PointerCast(ref v, ref target_type) => {
                    LLVMBuildPointerCast(
                        builder._ref,
                        v._ref,
                        target_type.get_ref(),
                        action_name.as_ptr()
                    )
                }
            }
        }
    }
}
