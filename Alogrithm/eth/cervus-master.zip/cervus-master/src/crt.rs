use std::sync::Mutex;
use std::os::raw::c_char;
use engine::{Module, ExecutionEngine, Function};
use value::{Value, IntoValue};

lazy_static! {
    static ref LOCAL_EE: ExecutionEngine = {
        let m = Module::new("");
        m.into_execution_engine()
    };
    static ref LOCAL_CRT: Mutex<Crt<'static>> = {
        Mutex::new(Crt::new(LOCAL_EE.get_module()))
    };
}

pub struct Crt<'a> {
    _module: &'a Module,
    rt_hashmap_new: Function<'a>,
    rt_hashmap_insert: Function<'a>,
    rt_hashmap_lookup: Function<'a>,
    rt_hashmap_remove: Function<'a>,
    rt_hashmap_destroy: Function<'a>
}

impl<'a> Crt<'a> {
    pub fn new(m: &'a Module) -> Crt<'a> {
        Crt {
            _module: m,
            rt_hashmap_new: Function::new_typed::<*const i8, ()>(m, "_w_crt_hashmap_new"),
            rt_hashmap_insert: Function::new_typed::<*const i8, (*const i8, *const c_char, *const i8)>(&m, "_w_crt_hashmap_insert"),
            rt_hashmap_lookup: Function::new_typed::<*const i8, (*const i8, *const c_char)>(&m, "_w_crt_hashmap_lookup"),
            rt_hashmap_remove: Function::new_typed::<*const i8, (*const i8, *const c_char)>(&m, "_w_crt_hashmap_remove"),
            rt_hashmap_destroy: Function::new_typed::<(), (*const i8,)>(&m, "_w_crt_hashmap_destroy")
        }
    }

    pub fn hash_map(&'a self) -> RtHashMap<'a> {
        RtHashMap::new(self)
    }
}

pub struct RtHashMap<'a> {
    rt: &'a Crt<'a>,
    val: Option<Value>,
    owned: bool
}

impl<'a> RtHashMap<'a> {
    pub fn new(rt: &'a Crt) -> RtHashMap<'a> {
        RtHashMap {
            rt: rt,
            val: Some((&rt.rt_hashmap_new).into_value().call(())),
            owned: true
        }
    }

    fn new_borrowed(rt: &'a Crt, val: Value) -> RtHashMap<'a> {
        RtHashMap {
            rt: rt,
            val: Some(val),
            owned: false
        }
    }

    fn new_owned(rt: &'a Crt, val: Value) -> RtHashMap<'a> {
        RtHashMap {
            rt: rt,
            val: Some(val),
            owned: true
        }
    }

    pub fn into_raw(mut self) -> Value {
        ::std::mem::replace(&mut self.val, None).unwrap()
    }

    pub fn from_raw(rt: &'a Crt, val: Value, owned: bool) -> RtHashMap<'a> {
        RtHashMap {
            rt: rt,
            val: Some(val),
            owned: owned
        }
    }

    pub fn insert(&self, key: Value, val: Value) -> Value {
        (&self.rt.rt_hashmap_insert).into_value().call((
            self.val.as_ref().unwrap().clone(),
            key,
            val
        ))
    }

    pub fn lookup(&self, key: Value) -> Value {
        (&self.rt.rt_hashmap_lookup).into_value().call((
            self.val.as_ref().unwrap().clone(),
            key
        ))
    }

    pub fn remove(&self, key: Value) -> Value {
        (&self.rt.rt_hashmap_remove).into_value().call((
            self.val.as_ref().unwrap().clone(),
            key
        ))
    }
}

impl<'a> Drop for RtHashMap<'a> {
    fn drop(&mut self) {
        if self.owned {
            if let Some(v) = ::std::mem::replace(&mut self.val, None) {
                (&self.rt.rt_hashmap_destroy).into_value().call((v,));
            }
        }
    }
}

impl<'a> Into<Value> for RtHashMap<'a> {
    fn into(self) -> Value {
        self.into_raw()
    }
}

pub struct LocalHashMap {
    handle: *const i8,
    _rt_insert: extern "C" fn (*const i8, *const c_char, *const i8) -> *const i8,
    _rt_lookup: extern "C" fn (*const i8, *const c_char) -> *const i8,
    _rt_remove: extern "C" fn (*const i8, *const c_char) -> *const i8
}

unsafe impl Send for LocalHashMap {}

impl LocalHashMap {
    pub fn new() -> LocalHashMap {
        let lcrt = LOCAL_CRT.lock().unwrap();
        LocalHashMap {
            handle: (LOCAL_EE.get_callable_0::<*const i8>(&lcrt.rt_hashmap_new))(),
            _rt_insert: LOCAL_EE.get_callable_3::<*const i8, *const i8, *const c_char, *const i8>(&lcrt.rt_hashmap_insert),
            _rt_lookup: LOCAL_EE.get_callable_2::<*const i8, *const i8, *const c_char>(&lcrt.rt_hashmap_lookup),
            _rt_remove: LOCAL_EE.get_callable_2::<*const i8, *const i8, *const c_char>(&lcrt.rt_hashmap_remove)
        }
    }

    pub fn borrow_rt<'a>(&self, other_crt: &'a Crt<'a>) -> RtHashMap<'a> {
        RtHashMap::new_borrowed(other_crt, self.handle.into_value())
    }

    pub fn into_rt<'a>(self, other_crt: &'a Crt<'a>) -> RtHashMap<'a> {
        RtHashMap::new_owned(other_crt, self.handle.into_value())
    }
}

impl Drop for LocalHashMap {
    fn drop(&mut self) {
        let lcrt = LOCAL_CRT.lock().unwrap();
        (LOCAL_EE.get_callable_1::<(), *const i8>(&lcrt.rt_hashmap_destroy))(self.handle);
    }
}
