use std;
use std::cell::RefCell;
use engine;

thread_local! {
    static BUILDER_STACK: RefCell<Vec<BuilderScope>> = RefCell::new(Vec::new());
}

pub struct BuilderScope {
    builder: &'static engine::Builder<'static>
}

pub struct BuilderScopeHandle<'a> {
    builder: &'a engine::Builder<'a>
}

impl<'a> BuilderScopeHandle<'a> {
    pub fn new(builder: &'a engine::Builder<'a>) -> BuilderScopeHandle<'a> {
        let scope = BuilderScope {
            builder: unsafe {
                std::mem::transmute::<&'a engine::Builder<'a>, &'static engine::Builder<'static>>(builder)
            }
        };
        BUILDER_STACK.with(|bs| {
            bs.borrow_mut().push(scope);
        });
        
        BuilderScopeHandle {
            builder: builder
        }
    }
}

impl<'a> Drop for BuilderScopeHandle<'a> {
    fn drop(&mut self) {
        BUILDER_STACK.with(|bs| {
            let mut builder_stack = bs.borrow_mut();
            if !std::ptr::eq(
                builder_stack.last().unwrap().builder as *const engine::Builder,
                self.builder as *const engine::Builder
            ) {
                builder_stack.clear();
                panic!("Invalid builder scope");
            }
            builder_stack.pop();
        });
    }
}

pub unsafe fn current_builder() -> &'static engine::Builder<'static> {
    BUILDER_STACK.with(|bs| {
        let bs = bs.borrow();
        bs.last().unwrap().builder
    })
}
