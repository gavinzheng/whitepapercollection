use std::os::raw::{c_void, c_char};
use engine;
use value::IntoValue;
use value_type::ValueType;
use crt;

#[test]
fn run_crt_test() {
    let m: engine::Module = engine::Module::new("");

    let entry_fn = {
        let entry_fn = engine::Function::new_typed::<i32, (i32,)>(&m, "entry");
        let rt = m.crt();

        {
            let bb = entry_fn.basic_block("");
            let builder = bb.builder();
            let ret;

            {

                let _bs = builder.scope_handle();
                let hm = rt.hash_map();

                let p = builder.alloca(ValueType::Int32);
                p.store(entry_fn.get_param(0).unwrap());

                let key1 = builder.build_string("some_value");
                let key2 = builder.build_string("some_value_2");

                hm.insert(
                    key1.clone(),
                    p.cast(ValueType::Pointer(Box::new(ValueType::Int8)))
                );

                let p2 = builder.alloca(ValueType::Int32);
                p2.store(0i32.into());

                hm.insert(
                    key2.clone(),
                    p2.cast(ValueType::Pointer(Box::new(ValueType::Int8)))
                );

                ret = hm.lookup(
                    key1
                ).cast(ValueType::Pointer(Box::new(ValueType::Int32))).load();

                drop(hm);
            }
            builder.return_value(ret);
        }

        entry_fn.into_null_handle()
    };

    let ee = m.into_execution_engine();

    ee.prepare();
    let entry = ee.get_callable_1::<i32, i32>(&entry_fn);
    assert!(entry(42) == 42);
}

#[test]
fn run_local_crt_test() {
    for _ in 0..1000000 {
        let _local_hm = crt::LocalHashMap::new();
    }
}
