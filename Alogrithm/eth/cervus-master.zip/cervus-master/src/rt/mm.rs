use std;
use std::cell::RefCell;
use rt::value::Value;
use std::collections::{HashSet, VecDeque};

pub struct MemoryManager {
    allocs: RefCell<Vec<Option<Box<Alloc>>>>,
    free_allocs: RefCell<VecDeque<usize>>
}

pub struct Alloc {
    value: Option<Value>,
    ref_by: HashSet<usize>,
    ref_to: HashSet<usize>
}

#[derive(Clone)]
pub struct AllocHandle<'a> {
    manager: &'a MemoryManager,
    id: usize
}

impl<'a> AllocHandle<'a> {
    pub fn new(parent: &AllocHandle<'a>, value: Option<Value>) -> AllocHandle<'a> {
        let mut allocs = parent.manager.allocs.borrow_mut();
        let mut free_allocs = parent.manager.free_allocs.borrow_mut();

        let my_id;

        if let Some(v) = free_allocs.pop_front() {
            my_id = v;
        } else {
            allocs.push(None);
            my_id = allocs.len() - 1;
        }

        assert!(allocs[my_id].is_none());

        let mut new_alloc = Box::new(Alloc {
            value: value,
            ref_by: HashSet::new(),
            ref_to: HashSet::new()
        });

        allocs[parent.id].as_mut().unwrap().ref_to.insert(my_id);
        new_alloc.ref_by.insert(parent.id);

        allocs[my_id] = Some(new_alloc);

        AllocHandle {
            manager: parent.manager,
            id: my_id
        }
    }

    pub unsafe fn fetch(&'a self) -> &'a Option<Value> {
        std::mem::transmute::<&Option<Value>, &'a Option<Value>>(
            &self.manager.allocs.borrow()[self.id].as_ref().unwrap().value
        )
    }

    pub unsafe fn fetch_mut(&'a self) -> &'a mut Option<Value> {
        std::mem::transmute::<&mut Option<Value>, &'a mut Option<Value>>(
            &mut self.manager.allocs.borrow_mut()[self.id].as_mut().unwrap().value
        )
    }

    pub unsafe fn into_static(self) -> AllocHandle<'static> {
        std::mem::transmute::<AllocHandle<'a>, AllocHandle<'static>>(self)
    }
}

impl<'a> Drop for AllocHandle<'a> {
    fn drop(&mut self) {
        let mut allocs = self.manager.allocs.borrow_mut();
        let me = std::mem::replace(&mut allocs[self.id], None).unwrap();

        for other_id in me.ref_by.iter() {
            allocs[*other_id].as_mut().unwrap().ref_to.remove(&self.id);
        }

        for other_id in me.ref_to.iter() {
            allocs[*other_id].as_mut().unwrap().ref_by.remove(&self.id);
        }

        // should be freed while the collector runs.
        allocs[self.id] = Some(me);

        //self.manager.free_allocs.borrow_mut().push_back(self.id);
    }
}

impl MemoryManager {
    pub fn new() -> MemoryManager {
        MemoryManager {
            allocs: RefCell::new(vec![Some(Box::new(Alloc::new(None)))]),
            free_allocs: RefCell::new(VecDeque::new())
        }
    }

    pub fn root_alloc<'a>(&'a self) -> AllocHandle<'a> {
        AllocHandle {
            manager: self,
            id: 0
        }
    }
}

impl Alloc {
    pub fn new(value: Option<Value>) -> Alloc {
        Alloc {
            value: value,
            ref_by: HashSet::new(),
            ref_to: HashSet::new()
        }
    }
}
