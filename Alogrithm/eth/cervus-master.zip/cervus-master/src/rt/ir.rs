use engine;
use rt::helper;

pub struct Block {
    ops: Vec<Box<Operation>>
}

pub trait Operation {
    fn build<'a>(
        &self,
        build_ctx: &mut helper::BuildContext,
        f: &'a engine::Function,
        current_builder: &engine::Builder
    ) -> Option<engine::BasicBlock<'a>>;
}
