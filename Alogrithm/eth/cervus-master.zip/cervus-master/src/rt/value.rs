use std::rc::Rc;
use std::cell::{RefCell, Ref};
use rt::core::Executor;

#[derive(Clone, PartialEq)]
pub enum Value {
    Null,
    Integer(i64),
    Float(f64),
    String(String)
}

#[derive(Clone)]
pub enum ValueSource {
    Plain(Value),
    GlobalVariable(String),
    LocalVariable(String)
}
