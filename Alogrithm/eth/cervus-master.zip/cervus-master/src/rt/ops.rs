use engine;
use rt::ir;
use rt::value::{Value, ValueSource};
use rt::helper;
use rt::core::Executor;

pub struct PrintOperation {
    message: ValueSource
}

impl ir::Operation for PrintOperation {
    fn build<'a>(
        &self,
        build_ctx: &mut helper::BuildContext,
        f: &'a engine::Function,
        current_builder: &engine::Builder
    ) -> Option<engine::BasicBlock<'a>> {
        unimplemented!();
        None
    }
}
