use rt::mm;
use rt::value::Value;

#[test]
fn test_mm() {
    let manager = mm::MemoryManager::new();

    let root = manager.root_alloc();

    for i in 0..20000 {
        let v1 = mm::AllocHandle::new(&root, Some(Value::Integer(42)));
        assert!(*unsafe { v1.fetch() }.as_ref().unwrap() == Value::Integer(42));
    }
}
