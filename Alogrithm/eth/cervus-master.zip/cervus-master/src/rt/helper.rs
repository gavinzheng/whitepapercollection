use std::collections::HashMap;
use engine;
use rt::core::Executor;

pub struct BuildContext<'a> {
    executor: &'a Executor,
    m: engine::Module,
    intrinsics: Intrinsics,
    global_numbering: HashMap<String, usize>,
    local_numbering: Vec<HashMap<String, usize>>
}

pub struct Intrinsics {
}

impl<'a> BuildContext<'a> {
    pub fn new(executor: &'a Executor) -> BuildContext<'a> {
        let m = engine::Module::new("");
        let intrinsics = Intrinsics::initialize(&m);

        BuildContext {
            executor: executor,
            m: m,
            intrinsics: intrinsics,
            global_numbering: HashMap::new(),
            local_numbering: vec![HashMap::new()]
        }
    }

    pub fn get_global_numbering<T: AsRef<str>>(&mut self, k: T) -> usize {
        let k = k.as_ref();

        if let Some(v) = self.global_numbering.get(k) {
            return *v;
        }

        let id = self.global_numbering.len();
        self.global_numbering.insert(k.to_string(), id);
        id
    }

    pub fn get_local_numbering<T: AsRef<str>>(&mut self, k: T) -> usize {
        let k = k.as_ref();
        let target = self.local_numbering.last_mut().unwrap();

        if let Some(v) = target.get(k) {
            return *v;
        }

        let id = target.len();
        target.insert(k.to_string(), id);
        id
    }

    pub fn enter_local_scope(&mut self) {
        self.local_numbering.push(HashMap::new());
    }

    pub fn exit_local_scope(&mut self) {
        self.local_numbering.pop();
    }
}

impl Intrinsics {
    pub fn initialize(m: &engine::Module) -> Intrinsics {
        Intrinsics {
        }
    }
}
