use std::cell::RefCell;
use std::collections::HashMap;
use rt::value::{Value, ValueSource};
use rt::mm;

pub struct Executor {
    mm: Box<mm::MemoryManager>,
    call_stack: RefCell<Vec<FunctionScope>>
}

pub struct FunctionScope {
    mm_base: mm::AllocHandle<'static>
}

impl Executor {
    pub fn new() -> Executor {
        // mem_manager must be boxed because cs_mm_base holds a reference to it
        let mem_manager = Box::new(mm::MemoryManager::new());
        let cs_mm_base = unsafe { mm::AllocHandle::new(&mem_manager.root_alloc(), None).into_static() };

        Executor {
            mm: mem_manager,
            call_stack: RefCell::new(vec![
                FunctionScope {
                    mm_base: cs_mm_base
                }
            ])
        }
    }

    pub fn enter_function_scope(&self) {
        let mut call_stack = self.call_stack.borrow_mut();
        let mm_base = mm::AllocHandle::new(&call_stack[call_stack.len() - 1].mm_base, None);

        call_stack.push(FunctionScope {
            mm_base: mm_base
        });
    }

    pub fn exit_function_scope(&self) {
        self.call_stack.borrow_mut().pop();
    }

    pub fn get_function_scope_mm_base(&self) -> mm::AllocHandle<'static> {
        self.call_stack.borrow().last().as_ref().unwrap().mm_base.clone()
    }

    pub fn get_global_mm_base(&self) -> mm::AllocHandle<'static> {
        self.call_stack.borrow()[0].mm_base.clone()
    }
}
