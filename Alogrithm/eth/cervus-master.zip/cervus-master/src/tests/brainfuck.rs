use std;
use std::os::raw::c_void;
use std::io::Read;
use std::io::Write;
use std::collections::VecDeque;
use super::brainfuck_mandelbrot;
use super::brainfuck_bitwidth;
use engine;
use value_type::ValueType;
use value::{IntoValue, IntoFunctionPointer, CompareType, SignedOrNot};

struct Tape {
    ops: Vec<Op>
}

#[derive(Eq, PartialEq, Clone, Debug)]
enum Op {
    Invalid,
    MoveForward(usize),
    MoveBackward(usize),
    Inc(u8),
    Dec(u8),
    WhileBegin,
    WhileEnd,
    Putchar,
    Getchar
}

impl Tape {
    fn from_str(s: &str) -> Tape {
        let ops: Vec<Op> = s.chars()
            .map(|ch| {
                use self::Op::*;
                match ch {
                    '>' => MoveForward(1),
                    '<' => MoveBackward(1),
                    '+' => Inc(1),
                    '-' => Dec(1),
                    '[' => WhileBegin,
                    ']' => WhileEnd,
                    '.' => Putchar,
                    ',' => Getchar,
                    _ => Invalid
                }
            })
            .filter(|op| *op != Op::Invalid)
            .collect();

        Tape {
            ops: ops
        }
    }

    fn optimize(&mut self) {
        self.optimize_move();
        self.optimize_incdec();
    }

    fn optimize_incdec(&mut self) {
        let mut cnt_inc: usize = 0;
        let mut cnt_dec: usize = 0;

        let mut in_calc = false;
        let mut new_ops: Vec<Op> = Vec::new();

        self.ops.push(Op::Invalid);

        for op in self.ops.iter() {
            use self::Op::*;

            match *op {
                Inc(n) => {
                    cnt_inc += n as usize;
                    in_calc = true;
                },
                Dec(n) => {
                    cnt_dec += n as usize;
                    in_calc = true;
                },
                _ => {
                    if in_calc {
                        if cnt_inc > cnt_dec {
                            new_ops.push(Inc((cnt_inc - cnt_dec) as u8));
                        }
                        if cnt_inc < cnt_dec {
                            new_ops.push(Dec((cnt_dec - cnt_inc) as u8));
                        }
                        cnt_inc = 0;
                        cnt_dec = 0;
                        in_calc = false;
                    }
                    new_ops.push(op.clone());
                }
            }
        }

        new_ops.pop();
        self.ops = new_ops;
    }

    fn optimize_move(&mut self) {
        let mut cnt_forward: usize = 0;
        let mut cnt_backward: usize = 0;

        let mut in_move = false;
        let mut new_ops: Vec<Op> = Vec::new();

        self.ops.push(Op::Invalid);

        for op in self.ops.iter() {
            use self::Op::*;

            match *op {
                MoveForward(n) => {
                    cnt_forward += n;
                    in_move = true;
                },
                MoveBackward(n) => {
                    cnt_backward += n;
                    in_move = true;
                },
                _ => {
                    if in_move {
                        if cnt_forward > cnt_backward {
                            new_ops.push(MoveForward(cnt_forward - cnt_backward));
                        }
                        if cnt_forward < cnt_backward {
                            new_ops.push(MoveBackward(cnt_backward - cnt_forward));
                        }
                        cnt_forward = 0;
                        cnt_backward = 0;
                        in_move = false;
                    }
                    new_ops.push(op.clone());
                }
            }
        }

        new_ops.pop();
        self.ops = new_ops;
    }

    fn eval(&self) {
        let mut mem: Vec<u8> = vec![0; 1048576];
        let mut ip: usize = 0;
        let mut p: usize = 0;
        let mut stack: VecDeque<usize> = VecDeque::new();

        let mut loop_ends: Vec<Option<usize>> = vec![None; self.ops.len()];

        loop {
            if ip >= self.ops.len() {
                break;
            }

            let op = &self.ops[ip];

            use self::Op::*;
            match *op {
                Invalid => panic!("Unexpected invalid operation"),
                MoveForward(n) => {
                    p += n;
                },
                MoveBackward(n) => {
                    p -= n;
                },
                Inc(n) => {
                    mem[p] += n as u8;
                },
                Dec(n) => {
                    mem[p] -= n as u8;
                },
                WhileBegin => {
                    if mem[p] != 0 {
                        stack.push_back(ip);
                    } else {
                        if let Some(end) = loop_ends[ip] {
                            ip = end;
                        } else {
                            let initial_ip = ip;
                            let mut depth: usize = 1;

                            while depth != 0 {
                                ip += 1;
                                if self.ops[ip] == WhileBegin {
                                    depth += 1;
                                }
                                if self.ops[ip] == WhileEnd {
                                    depth -= 1;
                                }
                            }

                            loop_ends[initial_ip] = Some(ip);
                        }
                    }
                },
                WhileEnd => {
                    let prev_ip = stack.pop_back().unwrap();
                    ip = prev_ip - 1;
                },
                Putchar => {
                    write_byte(mem[p]);
                },
                Getchar => {
                    mem[p] = read_byte();
                }
            }

            ip += 1;
        }
    }

    fn eval_jit(&self) {
        let eval_ctx = JitEvalContext::new(1048576);
        let build_ctx = JitBuildContext::new(&eval_ctx, self);
        let m = engine::Module::new("");
        let entry = build_ctx.build(&m).into_null_handle();

        let ee = engine::ExecutionEngine::new(m);
        ee.prepare();
        let callable = ee.get_callable_0::<()>(&entry);

        callable();
    }
}

struct JitEvalContext {
    mem: Vec<u8>,
    tp: usize
}

struct JitBuildContext<'a> {
    ip: usize,
    tp_ptr: engine::Value,
    mem_handle: engine::Value,
    eval_ctx: &'a JitEvalContext,
    tape: &'a Tape
}

impl JitEvalContext {
    fn new(mem_size: usize) -> JitEvalContext {
        let mem = vec![0; mem_size];
        let tp = &mem[0] as *const u8 as usize;

        JitEvalContext {
            mem: mem,
            tp: tp
        }
    }
}

impl<'a> JitBuildContext<'a> {
    fn new(eval_ctx: &'a JitEvalContext, tape: &'a Tape) -> JitBuildContext<'a> {
        JitBuildContext {
            ip: 0,
            tp_ptr: engine::Value::from(&eval_ctx.tp as *const usize as u64).const_int_to_ptr(
                ValueType::Pointer(Box::new(ValueType::Pointer(Box::new(ValueType::Int8))))
            ),
            mem_handle: engine::Value::from(&eval_ctx.mem[0] as *const u8 as u64).const_int_to_ptr(
                ValueType::Pointer(Box::new(ValueType::Int8))
            ),
            eval_ctx: eval_ctx,
            tape: tape
        }
    }

    fn build<'b>(&self, m: &'b engine::Module) -> engine::Function<'b> {
        let mut ip: usize = 0;
        let entry = self.build_function(m, &mut ip);
        entry
    }

    fn build_function<'b>(&self, m: &'b engine::Module, ip: &mut usize) -> engine::Function<'b> {
        let f = engine::Function::new(
            m,
            format!("fn-{}", *ip).as_str(),
            ValueType::Void,
            vec![]
        );

        let mem_lower_bound = &self.eval_ctx.mem[0] as *const u8 as usize;
        let mem_upper_bound = mem_lower_bound + self.eval_ctx.mem.len();

        {
            let mut bb = engine::BasicBlock::new(&f, "");
            let mut new_bb: Option<engine::BasicBlock> = None;

            loop {
                if let Some(v) = std::mem::replace(&mut new_bb, None) {
                    bb = v;
                }

                let builder = engine::Builder::new(&bb);

                if *ip >= self.tape.ops.len() {
                    break;
                }

                use self::Op::*;
                match self.tape.ops[*ip] {
                    Invalid => panic!("Unexpected invalid opcode"),
                    MoveForward(n) => {
                        let _bs = builder.scope_handle();
                        (self.tp_ptr.load() + (n as i64).into_value()).store_to(&self.tp_ptr);
                        new_bb = Some(build_ptr_bound_check(
                            &f,
                            &builder,
                            &self.tp_ptr,
                            mem_lower_bound,
                            mem_upper_bound
                        ));
                    },
                    MoveBackward(n) => {
                        let _bs = builder.scope_handle();
                        (self.tp_ptr.load() + (-(n as i64)).into()).store_to(&self.tp_ptr);
                        new_bb = Some(build_ptr_bound_check(
                            &f,
                            &builder,
                            &self.tp_ptr,
                            mem_lower_bound,
                            mem_upper_bound
                        ));
                    },
                    Inc(n) => {
                        let _bs = builder.scope_handle();
                        let tp_target = self.tp_ptr.load();

                        (tp_target.load() + (n as i8).into()).store_to(&tp_target);
                    },
                    Dec(n) => {
                        let _bs = builder.scope_handle();
                        let tp_target = self.tp_ptr.load();

                        (tp_target.load() - (n as i8).into()).store_to(&tp_target);
                    },
                    WhileBegin => {
                        *ip += 1;
                        let target_fn = self.build_function(m, ip); // we are at WhileEnd now

                        new_bb = Some(engine::BasicBlock::new(&f, ""));

                        let jumper_bb = engine::BasicBlock::new(&f, "");
                        let jumper_builder = engine::Builder::new(&jumper_bb);

                        {
                            let _bs = jumper_builder.scope_handle();
                            target_fn.into_value().call(());
                        }

                        let checker_bb = engine::BasicBlock::new(&f, "");
                        let checker_builder = engine::Builder::new(&checker_bb);

                        {
                            let _bs = checker_builder.scope_handle();
                            self.tp_ptr.load().load().compare(
                                (0 as u8).into(),
                                SignedOrNot::Undefined,
                                CompareType::Ne
                            ).conditional_branch(
                                &jumper_bb,
                                new_bb.as_ref().unwrap()
                            );
                        }

                        jumper_builder.branch(&checker_bb);
                        builder.branch(&checker_bb);
                    },
                    WhileEnd => {
                        break;
                    },
                    Putchar => {
                        let _bs = builder.scope_handle();
                        (write_byte as extern "C" fn (u8)).into_function_pointer().call(
                            (
                                self.tp_ptr.load().load(),
                            )
                        );
                    },
                    Getchar => {
                        let _bs = builder.scope_handle();
                        (read_byte as extern "C" fn () -> u8).into_function_pointer().call(())
                            .store_to(&self.tp_ptr.load());
                    }
                }

                *ip += 1;
            }

            let builder = engine::Builder::new(&bb);
            builder.return_void();
        }

        f
    }
}

fn build_ptr_bound_check<'a>(
    f: &'a engine::Function,
    builder: &engine::Builder,
    indirect_ptr: &engine::Value,
    lower: usize,
    upper: usize
) -> engine::BasicBlock<'a> {
    let new_bb = engine::BasicBlock::new(f, "");
    let fail_bb = engine::BasicBlock::new(f, "");
    let upper_check_bb = engine::BasicBlock::new(f, "");

    {
        let scope = builder.scope_handle();
        indirect_ptr
            .load()
            .cast(ValueType::Int64)
            .compare((lower as u64).into_value(), SignedOrNot::Unsigned, CompareType::Ge)
            .conditional_branch(&upper_check_bb, &fail_bb);
    }

    let mut upper_check_builder = engine::Builder::new(&upper_check_bb);

    {
        let scope = upper_check_builder.scope_handle();
        indirect_ptr
            .load()
            .cast(ValueType::Int64)
            .compare((upper as u64).into_value(), SignedOrNot::Unsigned, CompareType::Lt)
            .conditional_branch(&new_bb, &fail_bb);
    }

    let mut fail_builder = engine::Builder::new(&fail_bb);
    {
        let _bs = fail_builder.scope_handle();
        (handle_ptr_out_of_bound as extern "C" fn()).into_function_pointer().call(());
    }
    fail_builder.return_void();

    new_bb
}

extern "C" fn read_byte() -> u8 {
    std::io::stdin().bytes().next().unwrap().unwrap()
}

extern "C" fn write_byte(b: u8) {
    std::io::stdout().write(&[b]).unwrap();
}

extern "C" fn handle_ptr_out_of_bound() {
    panic!("Pointer out of bound");
}

//static TEST_TAPE_DATA: &'static str = "++++[>++++<-]>[>+>++>[+++++++>]+++[<]>-]>>>>>>>>-.<<<<.<..+++.<.>>>>.<<<.+++.------.>-.<<+.<------.";
//static TEST_TAPE_DATA: &'static str = "+[+>++++++++++++++++++++++++++++++++.--------------------------------<]";
//static TEST_TAPE_DATA: &'static str = "<";
static TEST_TAPE_DATA: &'static str = "+[>+]";

#[test]
fn test_brainfuck() {
    //let mut tape = Tape::from_str(TEST_TAPE_DATA);
    //let mut tape = Tape::from_str(brainfuck_mandelbrot::TAPE_DATA);
    let mut tape = Tape::from_str(brainfuck_bitwidth::TAPE_DATA);
    eprintln!("Before optimize: {} ops", tape.ops.len());
    tape.optimize();
    eprintln!("After optimize: {} ops", tape.ops.len());
    //tape.eval();
    tape.eval_jit();
}
