#! /bin/bash

# install bitcoin js lib
cd btc
npm install bitcoinjs-lib

cd ..


# install tendermint abci js lib
cd tendermint
npm install js-abci
