from setuptools import setup

setup(
    name='imouto',
    version='0.1.1',
    description='async web frameword',
    url='https://github.com/Hanaasagi/imouto',
    author='Hanaasagi',
    author_email='ambiguous404@gmail.com',
    packages=['imouto'],
    license='BSD3',
    platforms=['Linux'],
)
