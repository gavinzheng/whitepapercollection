import { metaPay } from './metamask-payment/actions/index';

module.exports =  {
  metaPay
}
