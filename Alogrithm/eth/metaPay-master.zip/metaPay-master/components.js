import { MetaPay } from './metamask-payment/components/index';

module.exports =  {
  MetaPay
}
