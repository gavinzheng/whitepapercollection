import metaPay from './metaPay';

export {
  metaPay,
}
