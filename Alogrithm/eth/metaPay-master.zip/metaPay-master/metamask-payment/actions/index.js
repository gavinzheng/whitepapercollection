import metaPay from './metaPay'

module.exports = {
  metaPay: new metaPay({})
}
