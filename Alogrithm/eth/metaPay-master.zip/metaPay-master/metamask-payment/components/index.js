import MetaPay from './MetaPay.jsx';

module.exports = {
  MetaPay
}
