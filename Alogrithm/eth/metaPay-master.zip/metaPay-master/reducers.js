import { metaPay } from './metamask-payment/reducers/index';

module.exports = {
  metaPay
}
