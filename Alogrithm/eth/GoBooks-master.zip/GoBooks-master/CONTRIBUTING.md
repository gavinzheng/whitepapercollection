Contribution Guidelines
====

Add books with this format :


```
### [BOOK NAME](BOOK URL)

<img src="BOOK COVER IMAGE ADDRESS" width="120px"/>

BOOK DESCRIPTION

```

* If book is free, add it after free books of that category and also add `*Free*` after book url.
* Add other books at the end of the list in that category
