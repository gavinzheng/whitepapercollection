# pwasm-libc

Parity WASM contracts standard library libc bindings

[Documentation](https://paritytech.github.io/pwasm-std/pwasm_libc/)

# License

`pwasm-libc` is primarily distributed under the terms of both the MIT
license and the Apache License (Version 2.0), at your choice.

See LICENSE-APACHE, and LICENSE-MIT for details.
