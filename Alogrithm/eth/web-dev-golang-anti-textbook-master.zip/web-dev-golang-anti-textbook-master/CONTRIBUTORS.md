As of 28'th August 2016.

https://github.com/benkasminbullock
https://github.com/sprstnd
https://github.com/appleboy
https://github.com/datyayu
https://github.com/roebuk
https://github.com/smihir
https://github.com/ghurley
https://github.com/dgrosenblatt

Following users raised issues:
https://github.com/norbertfuhs 
https://github.com/astropanic 
https://github.com/gernest 
https://github.com/raggi 