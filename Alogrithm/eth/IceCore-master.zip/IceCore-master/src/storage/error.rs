pub enum StorageError {
    Other(String)
}
