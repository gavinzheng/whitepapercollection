package core

// a single integer is sufficient here

const Version = "3" // rpc routes for profiling, setting config
