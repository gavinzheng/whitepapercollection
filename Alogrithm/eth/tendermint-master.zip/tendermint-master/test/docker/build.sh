#! /bin/bash

docker build -t tester -f ./test/docker/Dockerfile .
