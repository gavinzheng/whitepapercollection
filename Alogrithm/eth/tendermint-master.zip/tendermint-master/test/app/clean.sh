killall tendermint
killall dummy
killall counter
rm -rf ~/.tendermint_app
