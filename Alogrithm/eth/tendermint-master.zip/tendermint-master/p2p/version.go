package p2p

const Version = "0.5.0"
