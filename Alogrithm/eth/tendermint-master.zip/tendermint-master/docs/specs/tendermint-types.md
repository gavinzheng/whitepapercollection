# types
see the [godoc version](https://godoc.org/github.com/tendermint/tendermint/types)
