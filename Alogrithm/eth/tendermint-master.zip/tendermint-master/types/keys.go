package types

var (
	PeerStateKey     = "ConsensusReactor.peerState"
	PeerMempoolChKey = "MempoolReactor.peerMempoolCh"
)
