# Sanity Of Sanity
A tool for verifying that the Sanity rates are relatively close to the main contract ones.

## Running

    $ python3 -m tools.sanity_of_sanity.main --deployment-file-path DEPLOYMENT_FILE_PATH