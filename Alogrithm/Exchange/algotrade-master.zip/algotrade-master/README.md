# Algorithmic trading playground

Some trading algorithms with different strategies, and a runner to apply them over CSV files for stock prices.

Run `trade.py` to start! (requires python3).

Read the blogpost http://coconauts.net/blog/2017/08/29/bank-holiday-hackday-algorithmic-trading/
