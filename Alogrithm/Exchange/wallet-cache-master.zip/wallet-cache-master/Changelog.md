# 0.4.0 (2018-02-07)
## Features: 
- Create api for check kyber enable, get max gas price, get gas price
- Add fetching data from multi nodes 

## Compatability:
- This version only works with KyberNetwork smart contracts version 0.4.0

