import ccxt
print(ccxt.bitfinex().fetch_ticker('BTC/USD'))
