from plasma.root_chain.deployer import Deployer

Deployer().create_contract("RootChain/RootChain.sol")
