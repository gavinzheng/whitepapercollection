# ethereum-testnet-supply-button

Client-side testnet account ether supply request using https://github.com/locals-world/locals-faucetserver#api
