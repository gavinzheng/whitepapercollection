import { balances, relayer } from './Relayer/reducers/index';

module.exports = {
  balances,
  relayer,
}
