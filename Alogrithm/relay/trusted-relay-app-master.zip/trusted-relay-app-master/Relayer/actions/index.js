import relayer from './relayer'

module.exports = {
  relayer: new relayer({})
}
