export default class relayer {
  constructor (options) {
    this.owner_address = options.owner_address || '0xF70d67F47444DD538AB95DdC14ab15B1908CB0d9';
  }
}
