module.exports = {
    db: {
        uri: 'mongo',
        port: 27017,
        name: 'developmentDb',
        user: '',
        password: '',
    },
    auth: {
        usersTokenLife: 3600,
    },
    rinkeby: {
        account: '0x12A44e4A2d0e376023E59CA6DcbB0723cE5FF11F',
        privateKey: '1b2b18a5d903144720fb2c96db1f5f317a8da694c2e39e8a7f1a4739c949a6c8'
    }
};