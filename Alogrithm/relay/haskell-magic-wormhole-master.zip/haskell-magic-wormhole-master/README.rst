==========================
Magic Wormhole for Haskell
==========================

Library and command-line tools for interacting with `Magic Wormhole`_ in Haskell

Magic Wormhole lets you get things from one computer to another, safely.

.. _`Magic Wormhole`: https://github.com/warner/magic-wormhole/
