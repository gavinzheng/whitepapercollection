package edu.stanford.cs.crypto.efficientct.circuit;

import java.util.List;

public class PlainCircuit {
    int nVariables;
    List<Constraint> constraints;

}
