
Note: http://tahoe-lafs.readthedocs.io/en/latest/ is the preferred place to
read this documentation (GitHub doesn't render cross-document links or
images). If you're reading this on https://github.com/tahoe-lafs/tahoe-lafs ,
or from a checked-out source tree, then either run `tox -e docs` and open
_build/html/index.html in your browser, or view the pre-rendered trunk copy
at http://tahoe-lafs.readthedocs.io/en/latest/
