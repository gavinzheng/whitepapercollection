Specifications
==============

This section contains various attempts at writing detailed specifications of
the data formats used by Tahoe.

.. toctree::
   :maxdepth: 2

   outline
   uri
   file-encoding
   URI-extension
   mutable
   dirnodes
   servers-of-happiness
   backends/raic
