import sys

from allmydata.scripts.runner import run

if __name__ == "__main__":
    sys.exit(run())
