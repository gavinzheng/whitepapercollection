
class Namespace(object):
    pass
