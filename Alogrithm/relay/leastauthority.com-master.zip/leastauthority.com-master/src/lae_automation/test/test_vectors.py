MOCKJSONCONFIGFILE = """{
  "s3_access_key_id":         "TESTS3S3S3S3S3S3S3S3",
  "s3_secret_path":           "mock_s3_secret",

  "incident_gatherer_furl": "MOCK_incident_gatherer_furl",
  "stats_gatherer_furl":    "MOCK_stats_gatherer_furl",
  "sinkname_suffix":        "unitteststorageserver/rss"
}"""
