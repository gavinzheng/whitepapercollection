Some Pointers for the Enlightenment of LAE Issue Responders
===========================================================

 The purpose of an Issue Responder is to resolve the Issue.

 Great clarity can be obtained by communicating about the same, or nearly the
 same phenomenon, as was reported.  To put it another way fixing the wrong
 bug won't resolve the Issue.

Step 0: Reproduce The Issue
~~~~~~~~~~~~~~~~~~~~~~~~~~~

 If you can't reproduce the Issue then more input is required from the Issue
 Reporter.  Of course, we seek to minimize requests of the Reporter.
