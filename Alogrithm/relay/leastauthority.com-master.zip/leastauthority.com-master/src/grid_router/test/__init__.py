# Copyright Least Authority Enterprises.
# See LICENSE for details.

"""
Tests for ``grid_router``.
"""

from . import twisted_9087
twisted_9087.patch()
