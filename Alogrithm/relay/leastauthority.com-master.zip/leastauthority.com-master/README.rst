leastauthority.com
==================

.. image:: https://travis-ci.org/LeastAuthority/leastauthority.com.svg?master
    :target: https://travis-ci.org/LeastAuthority/leastauthority.com

.. image:: https://requires.io/github/LeastAuthority/leastauthority.com/requirements.svg?branch=master
     :target: https://requires.io/github/LeastAuthority/leastauthority.com/requirements/?branch=master
     :alt: Requirements Status

This website is a Twisted Web server with a set of static files.
It also has some application logic for using Kubernetes (k8s) and Amazon Web Services (aws) on behalf of LAE customers.

See ``docs/operations.rst`` for more details.
