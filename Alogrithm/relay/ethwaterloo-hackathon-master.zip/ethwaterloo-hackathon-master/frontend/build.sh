#!/bin/sh

browserify client.js > ./public/js/bundle.js