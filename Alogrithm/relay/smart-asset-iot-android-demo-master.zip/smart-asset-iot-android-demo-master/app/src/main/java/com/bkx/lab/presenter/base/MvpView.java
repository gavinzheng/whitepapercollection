package com.bkx.lab.presenter.base;

public interface MvpView {

}