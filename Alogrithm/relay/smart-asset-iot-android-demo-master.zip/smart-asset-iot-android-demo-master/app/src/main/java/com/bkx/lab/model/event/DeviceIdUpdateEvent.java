package com.bkx.lab.model.event;

public class DeviceIdUpdateEvent {
    public static DeviceIdUpdateEvent newInstance() {
        return new DeviceIdUpdateEvent();
    }
}
