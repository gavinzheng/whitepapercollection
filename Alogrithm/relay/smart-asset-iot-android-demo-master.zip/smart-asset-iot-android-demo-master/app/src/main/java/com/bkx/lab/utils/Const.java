package com.bkx.lab.utils;

public class Const {

    public static final String URL = "https://devicehive.bankex.org/api/rest/";
    public static final String REGISTER_URL = "https://devicehive.bankex.org/register";
    public static final String DEVICE_ID_FORMAT = "%1$s-%2$s-%3$s";
    public static final String NOTIFICATION_NAME_FORMAT = "%1$s-%2$s";
    public static final String KEY = "4TzFLFXkMEILDHsbQHVIX1u93TXGpCg5";
    public static final String DEVICE_NAME = "IoT Device | assetId=%s";
}
