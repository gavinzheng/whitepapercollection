# config-file-liveness-server

## Docker image

To build the Docker image:

  $ stack image container
