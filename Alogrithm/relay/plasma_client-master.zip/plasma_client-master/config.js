
module.exports = {

    plasma_contract_address: "0xd8AC480331870c5764b5430F854926b1cfd1d8B1",
    plasma_host: 'https://plasma.bankex.com/'

}
