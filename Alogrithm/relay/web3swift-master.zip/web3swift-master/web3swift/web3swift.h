//
//  web3swift.h
//  web3swift
//
//  Created by Petr Korolev on 06/12/2017.
//  Copyright © 2017 Bankex Foundation. All rights reserved.
//

#if TARGET_OS_IPHONE
#import <UIKit/UIKit.h>
#else
#import <Cocoa/Cocoa.h>
#endif
//! Project version number for web3swift.
FOUNDATION_EXPORT double web3swiftVersionNumber;

//! Project version string for web3swift.
FOUNDATION_EXPORT const unsigned char web3swiftVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <web3swift/PublicHeader.h>



