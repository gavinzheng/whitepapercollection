To help us debug your issue please explain:
- What you were trying to do (and why)
- What happened (include command output)
- What you expected to happen
- Step-by-step reproduction instructions

# Features
Please replace this section with:
- a detailed description of your proposed feature
- the motivation for the feature
- how the feature would be relevant to at least 90% of Plasma users
