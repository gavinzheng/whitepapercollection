=========
Tahoe-GUI
=========

This project has been superseded by `Gridsync`_; see https://github.com/gridsync/gridsync

.. _Gridsync: http://gridsync.io

