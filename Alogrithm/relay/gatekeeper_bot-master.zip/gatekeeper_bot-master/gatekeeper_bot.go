package main

import (
	"github.com/Syfaro/telegram-bot-api"
	"log"
	"math/rand"
)

func main() {


  		//test https://t.me/joinchat/BQeMJw1f-H6muuFRwMAy4g
  		// GroupChatId := int64(-224393342)
  		//real https://t.me/joinchat/BQeMJw_hlPJlt1MNagNBHg
  		GroupChatId := int64(-266441970)

	// подключаемся к боту с помощью токена
  //testBot @Openthegate_bot
	// bot, err := tgbotapi.NewBotAPI("566571630:AAFgn5Ue4zyp5AoiwvUtZUVFebwSWyqhZ9U")
  // @BankexGatekeeper_bot
	bot, err := tgbotapi.NewBotAPI("513199955:AAFcBsQv_4hxGmdq4znYSrogof-W41jlX1k")
	if err != nil {
		log.Panic(err)
	}

	bot.Debug = true
	log.Printf("Authorized on account %s", bot.Self.UserName)

	// инициализируем канал, куда будут прилетать обновления от API
	var ucfg tgbotapi.UpdateConfig = tgbotapi.NewUpdate(0)
	ucfg.Timeout = 60
	updates, err := bot.GetUpdatesChan(ucfg)
	// читаем обновления из канала
	for update := range updates {
		if update.Message == nil {
			continue
		}

		// Пользователь, который написал боту
		UserName := update.Message.From.UserName

		// ID чата/диалога.
		// Может быть идентификатором как чата с пользователем
		// (тогда он равен UserID) так и публичного чата/канала
		ChatID := update.Message.Chat.ID

		// Текст сообщения
		// Text := update.Message.Text

		///////////////
		NewMembers := update.Message.NewChatMembers

    GroupHelpMsg := "Привет, @" + update.Message.From.UserName + "! Я тут слежу за порядком. Веди себя хорошо. 😉\n Отправь мне сообщение в личку и я вышлю тебе инструкции. 😎"
		HelpMsg := "Привет, @" + update.Message.From.UserName + "!\nЯ умею оповещать ребят, что ты приехал в офис.\n\nЧтобы открыли дверь - отправь сюда или мне в личное сообщение /open 💬\n\nИ все в чате https://t.me/joinchat/BQeMJw_hlPJlt1MNagNBHg узнают что ты приехал! 🚍👈"
		if NewMembers != nil {
			reply := HelpMsg
			replyG := GroupHelpMsg
			if reply != "" {
				// Созадаем сообщение
				msg := tgbotapi.NewMessage(int64(update.Message.From.ID), reply)
				msg2 := tgbotapi.NewMessage(GroupChatId, replyG)
				// и отправляем его
				bot.Send(msg)
				bot.Send(msg2)
			}
		} else {

			log.Printf("[%s] %s", update.Message.From.UserName, update.Message.Text)

			msg := tgbotapi.NewMessage(ChatID, "")
			if update.Message.IsCommand() {

				switch update.Message.Command() {
				case "help":
          if ChatID == GroupChatId {
            msg.Text = HelpMsg
          } else {
            msg.Text = GroupHelpMsg
          }

				case "start":
					msg.Text = HelpMsg
				case "sayhi":
					msg.Text = "Hi :)"
				case "status":
					msg.Text = "I'm ok."
				case "open":
          if ChatID != GroupChatId {
            //Send personally:
            Text := "Ок, сейчас позову ребят! 🛰"
  					msg.Text = Text
          } else {msg.Text = ""}

					Cars := []string{"🚗", "🚕", "🚐", "🚛", "🚜", "🏍", "🚛"}
					n := rand.Int() % len(Cars)
					Car := Cars[n]
					GroupCallText := "@vvzubkov @ygabuev @Sofya_Drynkina @maximdmitrov\nРебята, откройте, пожалуйста, ворота! 🚧\n\n@" + UserName + " приехал! " + Car
					gmsg := tgbotapi.NewMessage(GroupChatId, GroupCallText)
					bot.Send(gmsg)
				default:
					msg.Text = "I don't know that command.\nЧто бы оповестить ребят в чате - отправь команду /open.\nЧто бы узнать больше информации - напиши /help"
				}
			} else {
				msg.Text = "Что бы оповестить ребят в чате - отправь команду /open.\nЧто бы узнать больше информации - напиши /help"
			}
			bot.Send(msg)

		}
	}
}
