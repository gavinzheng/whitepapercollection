# smart-asset-iot-html-demo
HTML5 version of IoT demo
