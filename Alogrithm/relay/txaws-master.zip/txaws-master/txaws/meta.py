display_name = "txAWS"
library_name = "txaws"
author = "txAWS Developers"
author_email = "txaws-dev@lists.launchpad.net"
license = "MIT"
url = "http://launchpad.net/txaws"
description = """
Twisted-based Asynchronous Libraries for Amazon Web Services
"""

