from txaws.version import txaws as __version__
__version__
