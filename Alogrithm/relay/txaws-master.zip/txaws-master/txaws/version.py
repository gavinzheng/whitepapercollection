txaws = "0.2.1.post5"
ec2_api = "2008-12-01"
s3_api = "2006-03-01"
