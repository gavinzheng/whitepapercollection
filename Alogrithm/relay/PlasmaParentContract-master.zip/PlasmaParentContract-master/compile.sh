#!/bin/sh 
solc --optimize --bin PlasmaParent.sol > out.txt
