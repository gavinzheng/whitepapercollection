# Воробьёв Артем

Разрабочик в компании 3CX
Навыки в хронологическом порядке :-)
* Frontend: TS, JS, RxJS, Node, Anular, AngualaJS, Webpack, Gulp, HTML, CSS, LESS
* .Net C#, WPF, Net Core, ASP.NET Core
* C/C++ Qt4, Boos, POCO, OpenCV

Интересуюсь Blockchain и связанными технологиями
Вы можете связаться со мной в телеграм @artall64 или по почте artall64@gmail.com