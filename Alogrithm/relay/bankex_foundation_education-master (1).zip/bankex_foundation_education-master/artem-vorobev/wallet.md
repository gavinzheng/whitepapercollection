0x9A75BCcb9046827A9Ee9C5038b9aF16E3044b629
Пост: https://plus.google.com/+ArtemVorobev/posts/MofTApSePDG
Транзакция в etherscan: https://rinkeby.etherscan.io/tx/0xfd98eb61d9def80c134881f6f6d160a0237015e89b04cd4a8b4a369cdf75ee2e