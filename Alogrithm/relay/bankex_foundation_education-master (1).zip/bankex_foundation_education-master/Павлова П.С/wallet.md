﻿**Адрес:** 0x0f4918ab27f48ce4ad15a5535b6ff72b13af5ab4   
**Ссылка:** https://rinkeby.etherscan.io/address/0x0f4918ab27f48ce4ad15a5535b6ff72b13af5ab4
**Ссылка на пост:** https://plus.google.com/108789716953873659786/posts/V478Dfd8GPT
**Ссылка на транзакцию:** https://rinkeby.etherscan.io/tx/0x527b14dc8b4988ddfcc851d5d8ef02853f79900af1eb529c1bfe1a4e1182c2a7
