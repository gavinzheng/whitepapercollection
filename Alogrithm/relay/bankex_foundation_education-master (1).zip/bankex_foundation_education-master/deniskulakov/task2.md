# Task 2. DKS nft token

## ERC-721 contract:
https://rinkeby.etherscan.io/address/0xa3af1cac819ff4c7385a869193b5507d91cfd189

## Simple app which allows you to mint and send DKS tokens
https://dkstoken.herokuapp.com/
