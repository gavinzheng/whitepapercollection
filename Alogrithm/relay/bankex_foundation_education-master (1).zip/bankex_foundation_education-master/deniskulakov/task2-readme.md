## Small example of how to use https://dkstoken.herokuapp.com/ to send DKS non-fungible token:

https://yadi.sk/i/yDMrmaMS3SJKZL