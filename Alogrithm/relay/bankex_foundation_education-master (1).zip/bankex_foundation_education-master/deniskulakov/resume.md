# Kulakov Denis Sergeevich, 30 years old
## Experience
9+ years experience in IT, 4+ years of bank card processing experience (support, delivery), 2+ years of QA automation experience, 1+ year of project management experience

## Programming languages (hands on experience)
* Apple Swift
* JS (Node.js)

## Foreign languages
* English - upper intermediate
* Greek - basic

## Certificates
* Certified Associate in Project Management (CAPM)
* IBM Blockchain Essentials

## Courses
Developing iOS 9 Apps with Swift (CS193p)

## Interests
* Blockchain
* Mobile apps
* FinTech (payment systems)

## Contacts
* Telegram: @askformusic
* Skype: deniskulakov87
* Email: denisskulakov@gmail.com
