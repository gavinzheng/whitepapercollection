Задача 0.0
Номер кошелька - 0xf6CcA204d367F0F3D2BaDD7721a0769945D92580
Ссылка на rinkeby https://rinkeby.etherscan.io/address/0xf6CcA204d367F0F3D2BaDD7721a0769945D92580

Задача 0.1
https://plus.google.com/105036902714131702928/posts/aNK3FFSYMWj?hl=ru

Задача 0.2
https://rinkeby.etherscan.io/tx/0x5b7d3dc3bcb3603d2a91c05c5e7ef6c3cdb3859647bacec3161fb9f6b32f71d7

