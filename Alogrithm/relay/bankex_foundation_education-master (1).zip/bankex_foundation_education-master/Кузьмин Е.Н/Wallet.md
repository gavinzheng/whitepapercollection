Адрес MetaMask: 0xea3d45844e4480333acd72aa7ae0ff662a78ef94
Rinkeby: https://rinkeby.etherscan.io/address/0xea3d45844e4480333acd72aa7ae0ff662a78ef94
Ссылка на репост в Google+: https://plus.google.com/109553606429479807978/posts/dbo7zo1NRzc?hl=ru
Ссылка на транзакцию в плазму: https://rinkeby.etherscan.io/tx/0xe788d73043e62dd90d8b51eae96e1ba3a0be27bfe8add5540bd7e0f4022b28a8
