***Kukushkin Aleksey*** (alex97xx)<br>

Adress of ETH wallet <code>0xDF7f81c83CA4701d83D582CD78FF4964a44bc277 </code><br>

URL of Wallet on Rinkeby <https://rinkeby.etherscan.io/address/0xdf7f81c83ca4701d83d582cd78ff4964a44bc277>

URL of post 'g+'<https://plus.google.com/107907769071302583100/posts/7caMjBbxpNr><br>

URL of Sent to Plasma <https://rinkeby.etherscan.io/tx/0x80ec40b6df3c3e3a57dab9148bda64fccece7324cff9b4ea26718edbe851718e>