Adress of ETH wallet:
0xF8502B0BA7872F46ba27d1cf579FdAAdB8004a1D

URL of Wallet on Rinkeby:
https://rinkeby.etherscan.io/address/0xf8502b0ba7872f46ba27d1cf579fdaadb8004a1d

URL of post on Facebook:
https://www.facebook.com/arsen.badalyan.1048/posts/2142329202661322?pnref=story

URL of Sent to Plasma:
https://rinkeby.etherscan.io/tx/0x3ff0d73ae6887751e5325a96e68ed27c08723bde3a4ecd4c37fcf5079e7647aa
