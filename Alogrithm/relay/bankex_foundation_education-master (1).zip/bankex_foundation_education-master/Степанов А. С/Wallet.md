# Задача 0
### Задача 0.0
**Адрес MetaMask кошелька:** 0x1ABa1CD1A9A77081918E8243A5c631EFa7817Cf6

**Ссылка:** https://rinkeby.etherscan.io/address/0x1aba1cd1a9a77081918e8243a5c631efa7817cf6
### Задача 0.1
**Ссылка на репост:** https://plus.google.com/u/0/111338581182871774899/posts/cDD2XU3pjZf
### Задача 0.2
**Ссылка с индексом транзакции:** https://rinkeby.etherscan.io/tx/0x30ee3df6d5ee117083a5b220d92e26223908d45b393a35aa9d50e42c702e16c7