Адрес Metamask - 0xebeAC18B8E10568069a7FE9c38B5D8B0B4426d5F
Rinkeby - https://rinkeby.etherscan.io/address/0xebeAC18B8E10568069a7FE9c38B5D8B0B4426d5F
Ссылка на пост - https://plus.google.com/u/0/109337048109185225009/posts/PLyMCbVpfkH
Транзакция в Plasma - https://rinkeby.etherscan.io/tx/0x3dea83ad5bb62c6b2fc410465736dd05b389d4ebbcb2097877bed3017c09bf5f