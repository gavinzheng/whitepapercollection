# Task 0
**wallet:** 0xC7be7EDF283ec1C510db3dC54ea5e5F5ddb1400F

[LINK to wallet](https://rinkeby.etherscan.io/address/0xc7be7edf283ec1c510db3dc54ea5e5f5ddb1400f)

[LINK to facebook post](https://www.facebook.com/juashik/posts/1518008968276217)

Plasma transaction (probably): 0x9319556191152c3c99402854112f36ae1bb39ea2e086cd815fadbaa3e8ebfbf6