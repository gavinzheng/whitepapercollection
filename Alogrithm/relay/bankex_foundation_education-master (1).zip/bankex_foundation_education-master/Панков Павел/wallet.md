Адрес metamask-кошелька: 0xd26c792cb9D0b2e527af3bb067Aa3Ba3993856B8
Адрес на сайте: https://rinkeby.etherscan.io/address/0xd26c792cb9D0b2e527af3bb067Aa3Ba3993856B8
Адрес поста: https://plus.google.com/105712169534871697906/posts/DsEAn4VnjoR
Адрес транзакции: https://rinkeby.etherscan.io/tx/0x794248144d071ccaf41ca35989ab09d4d5cf1e0d365ddc83ea118c3984fe12c0