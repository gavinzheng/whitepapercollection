# Why am I here
I need more blockchain in my life and I want to tokenize my apparment
# Languages
English&Russian

# Personal profile
- Seven years experience encompassing diverse areas of web development;
- Strengths include in-depth knowledge of project management and system/business analysis;
- Blockchain experience.

### Projects overview
I have worked on different complex projects including startups and government services as well as small web applications. 

I will help with understanding business value and managing overall project. I'm experienced with writing user stories, software requirements specifications and agile practices. 
I also developed few projects individually. So I can speak the developers' language and understand technical details.

I can create for you:
- business requirement document;
- software requirement specification;
- full UX-cycle for your project including: personas, customer journey map, informational architecture and wireframes;
- competitive analysis.

If you have any questions just drop me a line. I will be glad to help you!