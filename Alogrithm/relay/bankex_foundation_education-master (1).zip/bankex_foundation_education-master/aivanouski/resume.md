# Ивановский Андрей
## Experience
* 9 years web development (Dev, Lead, CTO)

## Interests
* world communication systems
* body, soul and spirit union
* integration blockchain to web and life

## Contacts
* Telegram: @aivanouski
* Skype: kydesnik_by
* Email: aivanouski@gmail.com
