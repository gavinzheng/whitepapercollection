# plasma-test-coin-distributer

1. To start app use `npm run start`
2. Replace wallet and private key in config.
