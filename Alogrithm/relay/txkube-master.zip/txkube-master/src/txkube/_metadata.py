# Copyright Least Authority Enterprises.
# See LICENSE for details.

"""
txkube package metadata definitions.
"""

version_tuple = (0, 2, 0)
version_string = ".".join(map(str, version_tuple))
