module.exports = {
    norpc: true, // Windows support
    copyNodeModules: true // OpenZeppelin dependencies
}
