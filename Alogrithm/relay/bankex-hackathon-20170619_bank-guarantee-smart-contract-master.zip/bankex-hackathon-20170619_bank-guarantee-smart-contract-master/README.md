# Bank Gurantee Smart Contract Server side
