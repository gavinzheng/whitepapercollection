
version_tuple = (17, 4, 17, 1)
version_string = ".".join(map(str, version_tuple) + ["dev0"])
