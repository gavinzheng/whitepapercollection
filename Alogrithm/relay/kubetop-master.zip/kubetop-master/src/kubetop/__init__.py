# Copyright Least Authority Enterprises.
# See LICENSE for details.
