stuff = {
    "metadata": {},
    "items": [
        {
            "metadata": {
                "name": "image-building-3987116516-g6s93",
                "namespace": "default",
                "creationTimestamp": "2017-04-07T15:21:22Z"
            },
            "timestamp": "2017-04-07T15:21:00Z",
            "window": "1m0s",
            "containers": [
                {
                    "name": "image-building",
                    "usage": {
                        "cpu": "0",
                        "memory": "13656Ki"
                    }
                }
            ]
        },
    ],
}
