export const views: Object[] = [
	{
		name: 'Dashboard',
		link: ['']
	},
	{
		name: 'Lazy',
		link: ['lazy']
	},
	{
		name: 'Bad Link',
		link: ['wronglink']
	}
];
