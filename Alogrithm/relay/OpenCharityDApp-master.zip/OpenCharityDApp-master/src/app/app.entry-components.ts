export const APP_ENTRY_COMPONENTS = [];
