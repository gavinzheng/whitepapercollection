import {Component} from '@angular/core';

@Component({
	selector: 'my-not-found',
	template: '<section><h3>Error 404: Not found</h3></section>'
})

export class NotFound404Component {
}
