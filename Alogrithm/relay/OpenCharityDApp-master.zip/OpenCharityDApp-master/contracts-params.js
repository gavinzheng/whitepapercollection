module.exports = {
	admin_addresses: ['0xce5A6a759Fd5dE4C14a4F0c527b182F1fe42e9Bb', '0x60F678985119c8cEd7827A07bEB1Bcb8EF23C681', '0xD0E9Ba62EB8aff66b38b83E110378Aa2E8eF991f'],
	token: {
		name: "Open Charity Token",
		symbol: "OCT",
		decimals: 18
	}

};
