__author__ = 'grigory51'


class MongoMixin(object):
    pass
