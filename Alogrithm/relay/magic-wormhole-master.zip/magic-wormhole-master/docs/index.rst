.. Magic-Wormhole documentation master file, created by
   sphinx-quickstart on Sun Nov 12 10:24:09 2017.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Magic-Wormhole: Get Things From One Computer To Another, Safely
===============================================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   welcome
   tor

   introduction
   api
   transit
   server-protocol
   client-protocol
   file-transfer-protocol

   attacks
   journal


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
