var config = {
	server: '<DEVICEHIVE_SERVER[:PORT]>',
	login: '<DEVICEHIVE_LOGIN>',
	pass: '<DEVICEHIVE_PASSWORD>',
	deviceId: '<DEVICE_ID>'
};

module.exports = config;