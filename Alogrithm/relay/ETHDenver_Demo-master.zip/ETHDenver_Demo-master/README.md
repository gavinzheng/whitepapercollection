# ETHDenver: BANKEX Confidential Transactions Demo
Confidential Transactions Demo

![Alt text](https://bankex.github.io/ETHDenver_Demo/img/screenshot-01.png)

## Running the example

```bash
npm install -g lite-server
```

```bash
lite-server

Did not detect a `bs-config.json` or `bs-config.js` override file. Using lite-server defaults...
** browser-sync config **
{ injectChanges: false,
  files: [ './**/*.{html,htm,css,js}' ],
  watchOptions: { ignored: 'node_modules' },
  server: { baseDir: './', middleware: [ [Function], [Function] ] } }
[Browsersync] Access URLs:
 -------------------------------------
       Local: http://localhost:3000
    External: http://10.251.2.111:3000
 -------------------------------------
          UI: http://localhost:3001
 UI External: http://10.251.2.111:3001
 -------------------------------------
[Browsersync] Serving files from: ./
[Browsersync] Watching files...

```