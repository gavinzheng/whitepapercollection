#External Resources

##BigInt
Origin: http://leemon.com/crypto/BigInt.html  
License: PD  

##Crypto-JS
Origin: http://code.google.com/p/crypto-js/  
License: BSD-2-Clause  

##EventEmitter
Origin: https://github.com/Wolfy87/EventEmitter/  
License: MIT  

##jQuery
Origin: http://jquery.org/  
License: MIT, GPL-2+  

##jQuery.color
Origin: https://github.com/jquery/jquery-color/  
License: MIT  

##jQuery.qTip2
Origin: https://github.com/craga89/qtip2/  
License: MIT, GPL  

##Mustache.js
Origin: https://github.com/janl/mustache.js/  
License: MIT  

##OTR.js
Origin: https://github.com/arlolra/otr/  
License: MPL 2.0  

##Strophe.js
Origin: http://strophe.im  
License: MIT  

##Tinycon
Origin: https://github.com/tommoor/tinycon  
License: MIT  

##WeaveCrypto
Origin: https://github.com/daviddahl/domcrypt  
License: MPL 1.1, GPL 2.0, LGPL 2.1  
