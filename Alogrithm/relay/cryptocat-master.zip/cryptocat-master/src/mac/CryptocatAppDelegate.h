//
//  CryptocatAppDelegate.h
//  Cryptocat
//
//  Created by Nadim Kobeissi on 2013-06-20.
//  Copyright (c) 2013 Cryptocat. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface CryptocatAppDelegate : NSObject <NSApplicationDelegate, NSMenuDelegate>{
	BOOL _isReinitializing;
}
- (void) reinitialize;
@end
