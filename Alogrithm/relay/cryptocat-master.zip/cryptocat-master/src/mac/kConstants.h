//
//  kConstants.h
//  Cryptocat
//
//  Created by Frederic Jacobs on 22/6/13.
//  Copyright (c) 2013 Cryptocat. All rights reserved.
//

#ifndef Cryptocat_kConstants_h
#define Cryptocat_kConstants_h

#define kApplicationName @"Cryptocat"
#define kConversationMenuItemName @"Conversations"

#define kKeyForTorPreferences @"torIsEnabled"

#define kTorMenuItemTag 100

#endif
