pref("extensions.cryptocat.autoRun", false);
pref("extensions.cryptocat.firstRun", true);