#!/usr/bin/env node

/*
 * Example program to use the Chain3 RPC commands
 * 
*/

var Chain3 = require('../index.js');
var chain3 = new Chain3();

chain3.setProvider(new chain3.providers.HttpProvider('http://localhost:8545'));
//A test node
// chain3.setProvider(new chain3.providers.HttpProvider('http://35.190.170.132:8545'));
//test machine mc01
//chain3.setProvider(new chain3.providers.HttpProvider('http://35.227.47.158:8545'));
//md03
// chain3.setProvider(new chain3.providers.HttpProvider('http://35.192.52.229:8545'));


if (!chain3.isConnected()){
    console.log("Chain3 RPC is not connected!");
    return;
}

// //Create a new account
// var account = new Web3EthAccounts('ws://localhost:8546');
// account.create();

// return;

console.log("Check account balance\n=========================================\n");
var coinbase = chain3.mc.accounts[0];//coinbase;
console.log(coinbase);

var balance = chain3.mc.getBalance(coinbase);
console.log(balance.toString(10));
console.log(chain3.fromSha(balance.toString(),'mc'), 'mc');
console.log(chain3.fromSha(balance.toString(),'Gsha'), 'Gsha');

var value = chain3.fromSha('21000000000000', 'Gsha');
console.log(value);

console.log("Display network info\n=========================================\n");
console.log(chain3.version.network);
console.log(chain3.version.moac);
console.log(chain3.version.api);
console.log(chain3.version.node);

chain3.version.getMoac(function(err, res) {
        if (!err){
            
            console.log("Succeed!: ", res);
            return res;
        }else{
            console.log("Chain3 error:", err.message);
            // response.success = false;
            // response.error = err.message;
            return err.message;
        }
    
    // console.log("Get response from MOAC node in the feedback function!")
 res.send(response);
});

chain3.version.getNode(function(err, res) {
        if (!err){
            
            console.log("Succeed!: ", res);
            return res;
        }else{
            console.log("Chain3 error:", err.message);
            // response.success = false;
            // response.error = err.message;
            return err.message;
        }
    
    // console.log("Get response from MOAC node in the feedback function!")
        // res.send(response);
});

chain3.version.getMoac(function(err, res) {
        if (!err){
            
            console.log("Succeed!: ", res);
            return res;
        }else{
            console.log("Chain3 error:", err.message);
            // response.success = false;
            // response.error = err.message;
            return err.message;
        }
    
    // console.log("Get response from MOAC node in the feedback function!")
        // res.send(response);
});

chain3.version.getNetwork(function(err, res) {
        if (!err){
            
            console.log("Succeed!: ", res);
            return res;
        }else{
            console.log("Chain3 error:", err.message);
            // response.success = false;
            // response.error = err.message;
            return err.message;
        }
    
    // console.log("Get response from MOAC node in the feedback function!")
        // res.send(response);
});


console.log("is mining?", chain3.mc.mining);


var accts = chain3.mc.accounts;
console.log("Total accounts:", accts.length);

return;

