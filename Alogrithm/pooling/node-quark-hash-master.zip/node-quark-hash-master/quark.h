#ifndef QUARK_H
#define QUARK_H

void quark_hash(const char* input, char* output);

#endif
