# King of the Ether Throne

An Ethereum ÐApp (a "contract"), living on the blockchain, that could have made you a King or Queen, granted you riches, or immortalized your name. It's no longer updated, but visit [kingoftheether.com](http://www.kingoftheether.com/) to find out more about my first solidity project.

Or why not check out my new project, https://ubitok.io/, the unstoppable exchange for trading Ethereum tokens ...
