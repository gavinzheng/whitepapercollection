# Merkle Signature Scheme  

## [2017-12-01]  
### Update    
+ the draft version of Winternitz One-Time Signature Scheme Plus  

