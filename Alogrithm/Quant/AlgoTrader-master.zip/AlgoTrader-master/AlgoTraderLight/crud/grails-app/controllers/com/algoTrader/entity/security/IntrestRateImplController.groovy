package com.algoTrader.entity.security

class IntrestRateImplController {

	def scaffold = IntrestRateImpl
}
