package com.algoTrader.entity

import com.algoTrader.entity.StrategyImpl

class StrategyImplController {

	def scaffold = StrategyImpl
}
