package com.algoTrader.entity.security

class StockImplController {

	def scaffold = StockImpl
}
