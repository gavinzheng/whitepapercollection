package com.algoTrader.entity.security

class SecurityImplController {

	def scaffold = SecurityImpl
}