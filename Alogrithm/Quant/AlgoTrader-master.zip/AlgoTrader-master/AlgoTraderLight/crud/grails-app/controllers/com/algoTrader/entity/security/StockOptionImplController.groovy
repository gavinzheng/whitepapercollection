package com.algoTrader.entity.security

class StockOptionImplController {

	def scaffold = StockOptionImpl
}
