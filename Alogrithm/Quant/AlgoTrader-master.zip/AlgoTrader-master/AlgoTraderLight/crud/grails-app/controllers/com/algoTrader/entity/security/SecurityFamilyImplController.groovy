package com.algoTrader.entity.security

class SecurityFamilyImplController {

	def scaffold = SecurityFamilyImpl
}
