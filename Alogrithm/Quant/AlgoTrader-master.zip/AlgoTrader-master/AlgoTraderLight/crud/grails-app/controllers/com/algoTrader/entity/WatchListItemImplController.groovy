package com.algoTrader.entity

import com.algoTrader.entity.WatchListItemImpl


class WatchListItemImplController {

	def scaffold = WatchListItemImpl
}
