package com.algoTrader.entity.security

class ForexImplController {

	def scaffold = ForexImpl
}
