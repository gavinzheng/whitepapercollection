package com.algoTrader.entity.security

class FutureImplController {

	def scaffold = FutureImpl
}
