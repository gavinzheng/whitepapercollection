package com.algoTrader.entity.security

class EquityIndexImplController {

	def scaffold = EquityIndexImpl
}
