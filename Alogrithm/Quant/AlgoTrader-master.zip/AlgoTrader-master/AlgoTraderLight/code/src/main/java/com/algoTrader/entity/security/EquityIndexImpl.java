package com.algoTrader.entity.security;

public class EquityIndexImpl extends EquityIndex {

	private static final long serialVersionUID = 4087343403938105040L;
}
