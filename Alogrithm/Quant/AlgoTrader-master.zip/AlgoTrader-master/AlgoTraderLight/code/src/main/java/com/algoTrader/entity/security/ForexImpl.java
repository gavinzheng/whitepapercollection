package com.algoTrader.entity.security;

public class ForexImpl extends Forex {

	private static final long serialVersionUID = 7529229834809415048L;

}
