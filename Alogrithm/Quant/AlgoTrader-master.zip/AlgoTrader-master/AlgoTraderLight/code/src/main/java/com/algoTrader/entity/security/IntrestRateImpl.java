package com.algoTrader.entity.security;

public class IntrestRateImpl extends IntrestRate {

	private static final long serialVersionUID = 7079085409744925449L;

}
