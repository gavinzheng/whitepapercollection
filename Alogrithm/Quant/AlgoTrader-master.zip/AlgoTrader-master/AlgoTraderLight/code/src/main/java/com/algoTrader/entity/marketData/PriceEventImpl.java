package com.algoTrader.entity.marketData;

public abstract class PriceEventImpl extends PriceEvent {

	private static final long serialVersionUID = -1182900322679114232L;
}
