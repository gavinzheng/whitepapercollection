package com.algoTrader.entity.security;

public class ForexDaoImpl extends ForexDaoBase {
}
