package com.algoTrader.esper.annotation;

public @interface Subscriber {

	String className();
}
