package com.algoTrader.entity.security;

public class StockOptionImpl extends StockOption {

	private static final long serialVersionUID = -1988968512244697307L;

}
