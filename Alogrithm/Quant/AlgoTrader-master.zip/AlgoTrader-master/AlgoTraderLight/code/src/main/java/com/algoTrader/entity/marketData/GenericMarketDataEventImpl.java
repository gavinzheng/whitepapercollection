package com.algoTrader.entity.marketData;

public abstract class GenericMarketDataEventImpl extends GenericMarketDataEvent {
    
	private static final long serialVersionUID = 2037089452651669159L;
}