package com.algoTrader.entity.security;

public class FutureDaoImpl extends FutureDaoBase {
}
