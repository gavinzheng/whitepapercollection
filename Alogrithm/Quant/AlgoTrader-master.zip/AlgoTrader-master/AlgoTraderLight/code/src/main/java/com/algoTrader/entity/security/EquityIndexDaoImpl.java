package com.algoTrader.entity.security;

public class EquityIndexDaoImpl extends EquityIndexDaoBase {
}
