package com.algoTrader.esper.annotation;

public @interface Listeners {

	String[] classNames();
}
