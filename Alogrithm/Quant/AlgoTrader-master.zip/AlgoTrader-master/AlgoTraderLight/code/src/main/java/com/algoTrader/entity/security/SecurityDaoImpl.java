package com.algoTrader.entity.security;

public class SecurityDaoImpl extends SecurityDaoBase {

}
