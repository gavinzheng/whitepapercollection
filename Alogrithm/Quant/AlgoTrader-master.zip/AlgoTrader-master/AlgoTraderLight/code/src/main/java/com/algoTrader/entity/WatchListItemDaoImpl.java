package com.algoTrader.entity;

public class WatchListItemDaoImpl extends WatchListItemDaoBase {

}
