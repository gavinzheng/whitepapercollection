package com.algoTrader.entity.security;

public class SecurityFamilyDaoImpl extends SecurityFamilyDaoBase {
}
