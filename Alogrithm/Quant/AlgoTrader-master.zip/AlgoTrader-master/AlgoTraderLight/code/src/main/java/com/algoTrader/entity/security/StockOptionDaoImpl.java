package com.algoTrader.entity.security;

public class StockOptionDaoImpl extends StockOptionDaoBase {
}
