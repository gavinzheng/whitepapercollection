package com.algoTrader.entity.security;

public class StockDaoImpl extends StockDaoBase {
}
