package com.algoTrader.entity.security;

public class StockImpl extends Stock {

	private static final long serialVersionUID = -6169238869632079681L;
}
