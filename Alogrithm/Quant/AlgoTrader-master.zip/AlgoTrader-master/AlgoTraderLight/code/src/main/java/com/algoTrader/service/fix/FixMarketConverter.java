package com.algoTrader.service.fix;

import com.algoTrader.enumeration.Market;

public class FixMarketConverter {

	public static String marketToString(Market market) {

		return market.toString();
	}
}
