package com.algoTrader.entity.security;

public class IntrestRateDaoImpl extends IntrestRateDaoBase {
}
