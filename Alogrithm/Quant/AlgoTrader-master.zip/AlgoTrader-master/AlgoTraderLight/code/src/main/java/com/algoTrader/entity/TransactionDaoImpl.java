package com.algoTrader.entity;

public class TransactionDaoImpl extends TransactionDaoBase {
}
