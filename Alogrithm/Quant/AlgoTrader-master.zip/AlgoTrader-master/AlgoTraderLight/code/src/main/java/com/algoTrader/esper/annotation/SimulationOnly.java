package com.algoTrader.esper.annotation;

public @interface SimulationOnly {

}
