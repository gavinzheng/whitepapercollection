package com.algoTrader.entity.trade;

public class MarketOrderImpl extends MarketOrder {

	private static final long serialVersionUID = -4556198640088062319L;
}
