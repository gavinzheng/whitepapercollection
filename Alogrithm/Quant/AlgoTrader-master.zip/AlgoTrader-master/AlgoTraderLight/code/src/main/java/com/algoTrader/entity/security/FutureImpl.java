package com.algoTrader.entity.security;

public class FutureImpl extends Future {

	private static final long serialVersionUID = -1962539019316570300L;
}
