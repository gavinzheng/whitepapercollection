package com.algoTrader.service.ib;

import com.algoTrader.enumeration.Market;

public class IBMarketConverter {

	public static String marketToString(Market market) {

		return market.toString();
	}
}
