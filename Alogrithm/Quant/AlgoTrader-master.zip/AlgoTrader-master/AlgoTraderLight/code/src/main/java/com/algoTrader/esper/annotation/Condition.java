package com.algoTrader.esper.annotation;

public @interface Condition {

	String key();
}
