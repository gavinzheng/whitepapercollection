package com.algoTrader.entity;

public class PositionDaoImpl extends PositionDaoBase {
}
