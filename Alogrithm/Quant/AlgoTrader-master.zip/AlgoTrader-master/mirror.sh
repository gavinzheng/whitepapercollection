#!/bin/sh
git svn rebase
git push origin master
