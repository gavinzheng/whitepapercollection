# -*- coding: utf-8 -*-


class RiskManager(object):
    def __init__(self):
        pass
    def optimalize(self,candidates,factors):
        raise NotImplementedError()


