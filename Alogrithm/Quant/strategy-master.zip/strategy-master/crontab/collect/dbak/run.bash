cd `dirname $0`
echo `date`
/data/kanghua/Envs/zipline/bin/python tushare_get_all.py
