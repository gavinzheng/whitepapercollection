import easyhistory

easyhistory.update()

