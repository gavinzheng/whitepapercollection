# coding:utf-8
import math


def get_quarter(month):
    return math.ceil(int(month) / 3)
