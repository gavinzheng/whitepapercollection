package vars

import "errors"

var (
	ErrTimeout = errors.New("Request timeout")
)
