# Change Log  

## v2.0  
+ encoding structs as Gob  
+ export all fields of primitive types, such as public keys, private keys and signatures  

## [2017-12-23]  
+ 1st complete LM-OTS with two parameter sets (w=2,4) provided  
