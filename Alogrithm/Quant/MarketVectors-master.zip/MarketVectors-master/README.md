# MarketVectors
Implementations for my blog post [here](https://medium.com/@TalPerry/deep-learning-the-stock-market-df853d139e02#.flflpo3xf) 
