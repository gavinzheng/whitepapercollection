# 1. Create a new API key: https://exchange.gemini.com/settings/api
# 2. Enter API key & secret below
# 3. Optionally add any settings here that you want to override in settings.py

API_KEY = 'gemini_API_KEY_here'
API_SECRET = 'gemini_API_SECRET_here'
