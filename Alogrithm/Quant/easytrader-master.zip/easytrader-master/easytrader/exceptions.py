# coding:utf8

class TradeError(IOError):
    pass
