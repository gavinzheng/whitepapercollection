# Documentation
> Metronome Token Documentation

## Index

1. [FAQ](https://github.com/MetronomeToken/documentation/blob/master/FAQ.md)
1. [Be Good](https://github.com/MetronomeToken/documentation/blob/master/BeGood.md)
