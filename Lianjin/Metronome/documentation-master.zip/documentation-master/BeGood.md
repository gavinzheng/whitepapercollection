# Be Good to Each Other
* Be friendly and patient
* Be welcoming - we want to embrace newcomers, encourage contribution
* Be professional
* [Assume good faith](https://en.wikipedia.org/wiki/Wikipedia:Assume_good_faith)
* Treat others as you would like to be treated

Further reading:   [Open Source Contributor Covenant](http://contributor-covenant.org/version/1/4/)
