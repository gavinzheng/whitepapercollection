from nacl.secret import SecretBox as Cipher  # noqa

# NaCl interface is convenient enough by itself (see tests)
