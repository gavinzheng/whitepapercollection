package com.qdum;

/**
 * Created by datochen on 15/6/9.
 */
public class main {
    public static void main(String[] args) {
        System.out.println("hello world!");
    }
}
