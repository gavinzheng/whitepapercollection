__version__ = '0.6.0dev1'
__short_version__ = '0.6.dev1'
