.. include:: ../README.rst

.. toctree::
    :maxdepth: 1

    installation
    usage
    examples
    libref
    contributing


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

