=======
Credits
=======

Development Lead
----------------

* BigchainDB <dev@bigchaindb.com>

Contributors
------------

None yet. Why not be the first?
