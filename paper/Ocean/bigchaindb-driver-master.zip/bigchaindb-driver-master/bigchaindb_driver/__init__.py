from .driver import BigchainDB   # noqa


__author__ = 'BigchainDB'
__email__ = 'dev@bigchaindb.com'
__version__ = '0.4.0'
