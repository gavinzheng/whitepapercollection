=========
Upgrading
=========

Upgrading Using pip
-------------------

If you installed the BigchainDB Python Driver using ``pip install bigchaindb_driver``, then you can upgrade it to the latest version using:

.. code-block:: bash

    pip install --upgrade bigchaindb_driver

