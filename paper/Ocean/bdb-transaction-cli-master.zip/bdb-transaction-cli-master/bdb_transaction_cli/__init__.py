# -*- coding: utf-8 -*-

__author__ = 'BigchainDB GmbH'
__email__ = 'dev@bigchaindb.com'
__version__ = '0.1.0'
