Welcome to bdb-transaction-cli's documentation!
===============================================

.. include:: ../README.rst
   :start-line: 4


Contents
--------

.. toctree::
   :maxdepth: 2

   usage
   examples
   history

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
