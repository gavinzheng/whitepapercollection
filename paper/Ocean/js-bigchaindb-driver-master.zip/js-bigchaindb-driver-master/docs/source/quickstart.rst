=========================
Quickstart / Installation
=========================

Installation with package manager npm:

.. code-block:: bash

    $ npm install bigchaindb-driver
