package even //<1>

func Even(i int) bool {	//<2>
	return i % 2 == 0
}

func odd(i int) bool {	//<3>
	return i % 2 == 1
}
