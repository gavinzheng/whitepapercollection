package main //<1>

import "fmt" //<2> //// Implements formatted I/O.

/* Print something */ <3>
func main() { //<4>
	fmt.Printf("Hello, world.") //<5>
}
