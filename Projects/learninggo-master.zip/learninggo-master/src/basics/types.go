package main

func main() {
	var a int
	var b int32
	b = a + a
	b = b + 5
}
