&nbsp;      | &nbsp;        | &nbsp;    | &nbsp;     | &nbsp;
------------|---------------|-----------|------------|--------
`break`	    |`default`	    |`func`	    |`interface` |`select`
`case`	    |`defer`	    |`go`	    |`map`       |`struct`
`chan`	    |`else`	        |`goto`	    |`package`   |`switch`
`const`	    |`fallthrough`	|`if`	    |`range`     |`type`
`continue`	|`for`	        |`import`	|`return`    |`var`
Table: Keywords in Go.
