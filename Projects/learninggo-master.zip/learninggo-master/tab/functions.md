&nbsp;   | &nbsp;   | &nbsp;    | &nbsp;
---------|----------|-----------|-------
`close`  | `new`    | `panic`   | `complex`
`delete` | `make`   | `recover` | `real`
`len`    | `append` | `print`   | `imag`
`cap`    | `copy`   | `println` |
Table: Pre-defined functions in Go.
