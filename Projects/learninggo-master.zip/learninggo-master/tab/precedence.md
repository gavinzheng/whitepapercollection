Precedence | Operator(s)
-----------|------------------
Highest    |	`*  /  %  <<  >>  &  &^`
           |	`+  -  | ^`
           |	`==  !=  <  <=  >  >=`
           |	`<-`
           |	`&&`
Lowest     |	\|\|
Table: Operator precedence.
