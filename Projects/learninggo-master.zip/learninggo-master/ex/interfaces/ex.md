{{ex/interfaces/minmax.md}}
{{ex/interfaces/pointers-and-reflect.md}}
