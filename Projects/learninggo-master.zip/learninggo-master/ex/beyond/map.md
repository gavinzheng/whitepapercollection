{.exercise data-difficulty="2"}
### Map function with interfaces
1. Use the answer from the earlier map exercise but now
  make it generic using interfaces. Make it at least work for
  ints and strings.

{.answer}
### Answer
1. 
  <{{ex/beyond/src/map.go}}
