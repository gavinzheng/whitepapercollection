{{ex/basics/for.md}}
{{ex/basics/average-no-func.md}}
{{ex/basics/fizzbuzz.md}}
