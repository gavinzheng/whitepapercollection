{.exercise data-difficulty="1"}
### Var args

1.  Write a function that takes a variable number of ints and print each integer on a separate line.


### Answer
1.  For this we need the `{...}`-syntax to signal we define a
    function that takes an arbitrary number of arguments. 

    <{{ex/functions/src/var-arg.go}}
