{.exercise data-difficulty="0"}
### For-loop II
1. Take what you did in exercise to write the for loop and extend it a bit.
   Put the body of the for loop - the `fmt.Printf` - in a separate function.


{.answer}
### Answer

1.
 <{{ex/functions/src/for-func.go}}
