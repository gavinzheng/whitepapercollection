# TODO
Use `io.Copy` to optimize the program we started this Chapter with.
