{{ex/communication/finger.md}}
{{ex/communication/echo.md}}
{{ex/communication/wordcount.md}}
{{ex/communication/uniq.md}}
{{ex/communication/quine.md}}
{{ex/communication/processes.md}}
{{ex/communication/numbercruncher.md}}
