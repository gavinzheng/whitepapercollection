{.exercise data-difficulty="2"}
### Calculator
1. Create a reverse polish calculator. Use your stack package.


{.answer}
### Answer
1. This is one answer:
 <{{ex/packages/src/calc.go}}
