import pymysql,json
from web3 import Web3, HTTPProvider, IPCProvider,eth
import sys,string



coin_name = sys.argv[1]

database_config = None

with open("database.json",'r') as f:
    database_config = json.load(f)


print(database_config)



connection = pymysql.connect(host=database_config["Host"],
                             user=database_config["UserName"],
                             password=database_config["Password"],
                             db=database_config["DB"],
                             charset='utf8',
                             cursorclass=pymysql.cursors.SSDictCursor)

#连接 以太坊钱包  用户处理分配代币
web3 = Web3(IPCProvider())


coin = None


def addAddress(user_id):
    address = web3.personal.newAccount(password='ceshi123123')
    print("分配的地址 %s" % (address))
    add_sql = "INSERT INTO `address_deposit_%s`(`user_id`,`coin_id`,`address`) VALUES (%s,%s,'%s');" % (coin_name.lower(),user_id, coin['id'], address)
    print(add_sql)
    with connection.cursor() as cursor_insert:
        cursor_insert.execute(add_sql)
        connection.commit()

    cursor_insert.close()
    print(id)


connection.autocommit(True)
try:
    with connection.cursor() as cursor:
        # 获取币的相关信息
        cursor.execute("SELECT * FROM `coins` WHERE name = %s;",(coin_name.lower()))
        coin = cursor.fetchone()

        if coin is None:
            print("%s not exist" % (coin_name))
            exit(1)
        cursor.fetchall()
        #查询哪些用户没有地址
        sql = "SELECT id,name FROM `users` WHERE id NOT IN (SELECT `user_id` FROM `address_deposit` WHERE `coin_id` = {0});".format(coin['id'])

        cursor.execute(sql)

        #循环处理
        while True:
            results = cursor.fetchone()
            if results is None:
                break
            print(results)
            #添加地址在这里处理
            addAddress(id)
            #
        cursor.close()
finally:
    connection.close()
