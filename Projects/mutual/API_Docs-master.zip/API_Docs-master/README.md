火币API文档请参考本项目的 [Wiki](/../../wiki/)

English Documents [click here](/../../../API_Docs_en/wiki/)

