# JSONLD

[![CI Status](http://img.shields.io/travis/Chris Downie/JSONLD.svg?style=flat)](https://travis-ci.org/Chris Downie/JSONLD)
[![Version](https://img.shields.io/cocoapods/v/JSONLD.svg?style=flat)](http://cocoapods.org/pods/JSONLD)
[![License](https://img.shields.io/cocoapods/l/JSONLD.svg?style=flat)](http://cocoapods.org/pods/JSONLD)
[![Platform](https://img.shields.io/cocoapods/p/JSONLD.svg?style=flat)](http://cocoapods.org/pods/JSONLD)

## Example

To run the example project, clone the repo, and run `pod install` from the Example directory first.

## Requirements

## Installation

JSONLD is available through [CocoaPods](http://cocoapods.org). To install
it, simply add the following line to your Podfile:

```ruby
pod "JSONLD"
```

## Author

Chris Downie, cdownie@gmail.com

## License

JSONLD is available under the MIT license. See the LICENSE file for more info.
