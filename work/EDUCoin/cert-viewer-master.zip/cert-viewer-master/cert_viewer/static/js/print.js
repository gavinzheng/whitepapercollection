$(document).ready(function () {
    $("#print-btn").click(function () {
        window.print();
    });
});