""" The PyLD module is used to process JSON-LD. """
from pyld import jsonld

__all__ = ['jsonld']
