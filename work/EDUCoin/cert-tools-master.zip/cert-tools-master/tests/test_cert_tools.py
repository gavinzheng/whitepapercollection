import unittest


class TestCertTools(unittest.TestCase):
    def test_starter(self):
        self.assertTrue(True, 'needs tests!')

if __name__ == '__main__':
    unittest.main()
